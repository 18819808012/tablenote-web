<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">Settings <a class="changeHtml" href="Zn/setting.php">切换</a></span>

    <div class="conHeadLinkBox">
  		<a class="conHeadLink" id="BasicInfoEdit" href="javascript:void(0)">edit</a>
      <a href="javascript:void(0)" class="conHeadLink" id="BasicInfoCancel">cancel</a>
  		<!-- <button id="BasicInfoSava" class="conSave">退出</button> -->
    </div>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 主要内容盒子 -->
<div class="row conBox">

<section class="row ClearLR font0">
  <div class="w24bf  MinH">
      <ul class="nav settingNav" role="tablist">
        <li class="active"><a href="#home" role="tab" data-toggle="tab">Profile</a></li>
        <li><a href="#profile" role="tab" data-toggle="tab">Account status</a></li>
      </ul>
  </div>

  <div class="w75bf tab-content">

    <div role="tabpanel" class="tab-pane font0 active" id="home">
      <div class="w3bf MinH conBg">
      <header class="conHeadTip">Personal information</header>
      <div class="BasicInfoWrap">
        <a class="BasicInfoLink" href="#"><img src="img/userIcon.gif" class="img-circle BasicInfoIcon"></a>
        <p>黄先生</p>
        <p>huangxi@huangxi.com</p>
        <p>职位：采购主管</p>
        <p>固定电话：86-20-80320320</p>
        <p>手机：86-13503820832</p>
      </div>

      <div class="BasicInfoEditWrap">
        <form>
          <div class="RelativeBox">
          <a class="contactsCusAdd mb15" href="javascript:void(0)">Add your photo</a>
          <input type="file" class="BasicInfoEditFI conOpacity">
          </div>
          <div class="RelativeBox BasicInfoEditFile">
            <img src="img/userIcon.gif" class="img-circle BasicInfoEditIcon">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="User Name(required)">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Email(required)">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Password(required)">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Confirm password(required)">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Job title">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Tel">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Cellphone">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Linkedin">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="What's App">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Skype">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Wechat">
          </div>
        </form>
      </div><!-- BasicInfoEditWrap -->

      </div>

      <div class="w3bf MinH conBg">
      <header class="conHeadTip">Company information</header>
      <div class="BasicInfoWrap" id="BasicInfoWrap">
        <a class="BasicInfoLink" href="#"><img src="img/userIcon.gif" class="img-circle BasicInfoIcon"></a>
        <p>黄希进出口有限公司</p>
        <p>Company ID：<span>123456789</span></p>
        <p class="BasicInfoMsg">简介：这里是公司简介内容，这里是公司简介内容，这里是公司简介内容，这里是公司简介内容，这里是公司简介内容，这里是公司简介内容，这里是公司简介内容，这里是公司简介内容，这里是公司简介内容，这里是公司简介内容，</p>
        <div class="exitCompanyBox"><a href="javascript:void(0);" class="exitCompany">Bow out of the company</a></div>
      </div>

      <div class="BasicInfoEditWrap">
        <form>
          <div class="RelativeBox">
          <a class="contactsCusAdd mb15" href="javascript:void(0)">添加公司头像</a>
          <input type="file" class="BasicInfoEditFI conOpacity">
          </div>
          <div class="RelativeBox BasicInfoEditFile">
            <img src="img/userIcon.gif" class="img-circle BasicInfoEditIcon">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Name(required)">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Introduction">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Linkedin">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Address 1">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Address 2">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Address 3">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="Address 4">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="industry">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <input type="text" class="conIn" placeholder="采购产品">
          </div>
          <div class="RelativeBox BasicInfoMsg">
            <textarea class="conTxtArea" rows="6" placeholder="公司简介"></textarea>
          </div>
        </form>
      </div><!-- BasicInfoEditWrap -->

      </div>

      <div class="w3bf MinH conBg">
      <header class="conHeadTip">Submission of quotation</header>
      <div class="BasicInfo3">
        <p>Your supplier can submit quotation to your company by entering your company ID when creating quotation.</p>
        <p>You can also import supplier information and their quotation into the system if you enter your own company ID.</p>
      </div>
      </div>

    </div>

    <div role="tabpanel" class="tab-pane MinH niceScroll conBg" id="profile">
      <p class="seriesTip">Current plan：The standard version</p>
      <p class="seriesTime">Expiry date：2016-12-11</p>
      <div class="font0">
        <div class="w3bf settingMsgBox1">
        <p class="settingMsgH">Free</p>
        <p class="settingFree mb20">现在免费!</p>
        <p>同步所有设备</p>
        <p>产品报价管理</p>
        <p>设置不同报价模板</p>
        <p>条形码/二维码管理产品</p>
        <p>导出产品数据</p>
        <p>会议记录</p>
        <p>导出PDF格式的会议记录</p>
        <p>导出Excel格式的会议记录</p>
        <p>供应商资料管理</p>
        <p>供应商协作</p>
        <p><small class="sMbox1small">*供应商直接提交或者编辑报价</small></p>
        </div>

        <div class="w3bf settingMsgBox1">
          <p class="settingMsgH">Standard</p>
          <p class="settingFree mb20">￥999半年</p>
          <p>同步所有设备</p>
          <p>产品报价管理</p>
          <p>设置不同报价模板</p>
          <p>条形码/二维码管理产品</p>
          <p>导出产品数据</p>
          <p>会议记录</p>
          <p>导出PDF格式的会议记录</p>
          <p>导出Excel格式的会议记录</p>
          <p>供应商资料管理</p>
          <p>供应商协作</p>
          <p><small class="sMbox1small">*供应商直接提交或者编辑报价</small></p>
          <p>销售展示</p>
          <p><small class="sMbox1small">*隐藏供应商信息及采购价格</small></p>
          <p><a class="settingMsgBox1Link" href="#">Renew</a></p>
        </div>

        <div class="w3bf settingMsgBox1">
          <p class="settingMsgH">Pro</p>
          <p class="settingFree mb20">￥1499半年</p>
          <p>同步所有设备</p>
          <p>产品报价管理</p>
          <p>设置不同报价模板</p>
          <p>条形码/二维码管理产品</p>
          <p>导出产品数据</p>
          <p>会议记录</p>
          <p>导出PDF格式的会议记录</p>
          <p>导出Excel格式的会议记录</p>
          <p>供应商资料管理</p>
          <p>供应商协作</p>
          <p><small class="sMbox1small">*供应商直接提交或者编辑报价</small></p>
          <p>销售展示</p>
          <p><small class="sMbox1small">*隐藏供应商信息及采购价格</small></p>
          <p>编辑日志</p>
          <p>不同用户的编辑及修改记录，特别是价格修改记录</p>
          <p>多用户权限管理</p>
          <p><small class="sMbox1small">*按照产品分类设置用户权限，产品数据更安全</small></p>
          <p><a class="settingMsgBox1Link" href="#">Purchase</a></p>
        </div>
      </div>
    </div>
  </div><!-- tab-content -->

</section>

</div>
<!-- 主要内容盒子 -->

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">
// 点击编辑切换
$(document).on("click","#BasicInfoEdit",function(){
    var I = $(this);
    var tar = $(".BasicInfoWrap");
    var editTar = $(".BasicInfoEditWrap");
    var Iname = I.text();
    if (!!I.hasClass("open")) {
      I.removeClass("open");
      I.text("edit");
      editTar.hide();
      tar.show();
    }else{
      I.addClass("open");
      I.text("save");
      tar.hide();
      editTar.show();
    }
})
// 点击编辑切换
</script>
</body>
</html>