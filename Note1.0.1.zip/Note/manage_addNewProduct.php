<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">Create product <a class="changeHtml" href="Zn/manage_addNewProduct.php">切换</a></span>
	</div>
</header>
<!-- 头部固定栏 -->

<div class="row conBox">
<section class="row ClearLR addNewProductBox MinH">
   <div class="differentUserBox">
       <p>Please enter the company ID below</p>
       <p><input type="text" class="differentUser"></p>
       <p><a class="differentUserLink" href="javascript:void:(0)">Confirm</a></p>

       <!-- 只做标识，可删除 -->
       <p><a href="beginCreate.php">根据用户输入id第一种身份跳转页面（只作为提示，可删除）</a></p>
       <p><a href="beginCreate02.php">根据用户输入id第二种身份跳转页面（只作为提示，可删除）</a></p>
       <!-- 只做标识，可删除 -->

   </div>
</section>
</div>

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
</body>
</html>