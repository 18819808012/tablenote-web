<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">contacts setting <a class="changeHtml" href="Zn/contacts.php">切换</a></span>

    <div class="conHeadLinkBox">
  		<a class="conHeadLink" href="#">New company</a>
      <a class="conHeadLink" href="#">Bulk import</a>
      <a class="conHeadLink" href="#">Add contacts</a>
      <a class="conHeadLink" href="#">Save</a>
    </div>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 主要内容盒子 -->
<div class="row conBox">

<section class="row ClearLR contactsBox">
  <div class="w24bf MinH">
    <header class="conHeadTip">Supplier list</header>
    <ul class="contactList niceScroll MinH_h">
      <li>
        <a href="#">
          <p class="contactListH">公司名称</p>
          <p>联系人</p>
          <p>电话</p>
          <p>手机</p>
          <p>邮箱</p>
        </a>
      </li>
      <li>
        <a href="#">
          <p class="contactListH">张小姐有限公司</p>
          <p>张小姐</p>
          <p>8620-83208320</p>
          <p>8620-123456789</p>
          <p>123456789@qq.com</p>
        </a>
      </li>
      <li>
        <a href="#">
          <p class="contactListH">张小姐有限公司</p>
          <p>张小姐</p>
          <p>8620-83208320</p>
          <p>8620-123456789</p>
          <p>123456789@qq.com</p>
        </a>
      </li>
      <li>
        <a href="#">
          <p class="contactListH">张小姐有限公司</p>
          <p>张小姐</p>
          <p>8620-83208320</p>
          <p>8620-123456789</p>
          <p>123456789@qq.com</p>
        </a>
      </li>
      <li>
        <a href="#">
          <p class="contactListH">张小姐有限公司</p>
          <p>张小姐</p>
          <p>8620-83208320</p>
          <p>8620-123456789</p>
          <p>123456789@qq.com</p>
        </a>
      </li>
      <li>
        <a href="#">
          <p class="contactListH">张小姐有限公司</p>
          <p>张小姐</p>
          <p>8620-83208320</p>
          <p>8620-123456789</p>
          <p>123456789@qq.com</p>
        </a>
      </li>
      <li>
        <a href="#">
          <p class="contactListH">张小姐有限公司</p>
          <p>张小姐</p>
          <p>8620-83208320</p>
          <p>8620-123456789</p>
          <p>123456789@qq.com</p>
        </a>
      </li>
    </ul>
  </div>

  <div class="w24bf MinH">
    <header class="conHeadTip">Company information</header>
    <div class="contactsPeopleMsg">
      <a class="contactsCusAdd mb15" href="javascript:void(0)">Delete this company</a>
      <form>
        <!-- <div class="RelativeBox font0 inputBox">
          <span class="inputName">部门</span>
          <div class="customSelect contactSelect">
             <a class="customSelLink contactSelLink" href="javascript:void(0)"><span class="customSelTxt">日用品</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
             <ul class="list-unstyled customSelMsg contactSelUl" style="display: none;">
               <li>部门1</li>
               <li>部门2</li>
               <li>部门3</li>
               <li>部门4</li>
               <li>部门5</li>
               <li>部门6</li>
               <li>部门1</li>
               <li>部门1</li>
               <li>部门1</li>
               <li>部门1</li>
               <li>部门1</li>
             </ul>
          </div>
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">分类</span>
          <div class="customSelect contactSelect">
             <a class="customSelLink contactSelLink" href="javascript:void(0)"><span class="customSelTxt">未分类</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
             <ul class="list-unstyled customSelMsg contactSelUl" style="display: none;">
               <li>部门1</li>
               <li>部门2</li>
               <li>部门3</li>
               <li>部门4</li>
               <li>部门5</li>
               <li>部门6</li>
               <li>部门1</li>
               <li>部门1</li>
               <li>部门1</li>
               <li>部门1</li>
               <li>部门1</li>
             </ul>
          </div>
        </div> -->
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName inputNameA">Supplier number</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName inputNameA">Supplier type</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName inputNameA">Company name</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName inputNameA">Address</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName inputNameA">website</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName inputNameA">Payment term</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName inputNameA">Main products</span>
          <input type="text" class="inputVal">
        </div>
<!--         <div class="RelativeBox font0 inputBox">
          <span class="inputName">银行账户</span>
          <input type="text" class="inputVal">
        </div> -->
      </form>
    </div>
  </div>

  <div class="w24bf MinH">
    <header class="conHeadTip">Contact Information</header>

    <div class="contactsPeopleMsg contactsPeopleMsg02">
      <a class="contactsCusRemove" href="javascript:void(0)"><span class="glyphicon glyphicon-remove"></span></a>
      <form>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">Contact</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">Job title</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">Cell</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">Email</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">Tel</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">Fax</span>
          <input type="text" class="inputVal">
        </div>
      </form>
    </div>

    <div class="contactsPeopleMsg contactsPeopleMsg02">
      <a class="contactsCusRemove" href="javascript:void(0)"><span class="glyphicon glyphicon-remove"></span></a>
      <form>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">Contact</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">Job title</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">Cell</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">Email</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">Tel</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">Fax</span>
          <input type="text" class="inputVal">
        </div>
      </form>
    </div>

  </div>

<!--   <div class="w24bf MinH">
    <header class="conHeadTip">Comment</header>
    <div class="concactsAssessWrap niceScroll">
      <ul class="list-unstyled">
      <li>
        <a class="navMoreLink concactsNavMore" href="javascript:void(0)">Delivery<span class="glyphicon navMoreIcon concactsNavMoreI glyphicon-menu-down" aria-hidden="true"></span></a>
        <div class="navMoreMsg">
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
        </div>
      </li>
      <li>
        <a class="navMoreLink concactsNavMore" href="javascript:void(0)">Communication<span class="glyphicon navMoreIcon concactsNavMoreI glyphicon-menu-down" aria-hidden="true"></span></a>
        <div class="navMoreMsg">
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
        </div>
      </li>
      <li>
        <a class="navMoreLink concactsNavMore" href="javascript:void(0)">Quality<span class="glyphicon navMoreIcon concactsNavMoreI glyphicon-menu-down" aria-hidden="true"></span></a>
        <div class="navMoreMsg">
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
        </div>
      </li>
      <li>
        <a class="navMoreLink concactsNavMore" href="javascript:void(0)">Sampling<span class="glyphicon navMoreIcon concactsNavMoreI glyphicon-menu-down" aria-hidden="true"></span></a>
        <div class="navMoreMsg">
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
        </div>
      </li>
      <li>
        <a class="navMoreLink concactsNavMore" href="javascript:void(0)">Documentation<span class="glyphicon navMoreIcon concactsNavMoreI glyphicon-menu-down" aria-hidden="true"></span></a>
        <div class="navMoreMsg">
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
        </div>
      </li>
    </ul>
    </div>
  </div> -->

</section>

</div>
<!-- 主要内容盒子 -->

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">
$(document).on("click",".contactsCusAdd",function(){
    var I = $(this);
    var Itar = I.parent();
    Itar.remove();
})
</script>
</body>
</html>