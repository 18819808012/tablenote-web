<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">发件箱 <a class="changeHtml" href="Zn/detail.php">切换</a></span>
		<a id="changList" class="changList" href="javascript:void(0);"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span></a>
    
    <div class="conHeadLinkBox">
      <a class="conHeadLink DetailAdd" href="javascript:void(0)">添加到样品单</a>
  		<a class="conHeadLink DetailRecord" href="javascript:void(0)">历史记录</a>
  		<a id="DetailEdit" class="conHeadLink DetailEdit" href="javascript:void(0)">编辑</a>
  		<a class="conHeadLink DetailOut" href="javascript:void(0)">导出</a>
  		<a class="conHeadLink DetailCancel" href="javascript:void(0)">删除</a>
    </div>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 主要内容盒子 -->
<div id="conBoxA" class="row conBox">

<section class="row ClearLR font0">
  <div class="w24bf  MinH">
      <header class="tempH">Quotation information</header>
      <!-- <p class="changePrice"><a id="changePrice" href="javascript:void(0)"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span><span class="changePriceTxt">切换到输入模式</span></a></p> -->
      <div id="PriceShow">
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Created on</span>
      		<p>2016-07-02</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Saved on</span>
      		<p>2016-07-03</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Created by</span>
      		<p>by Huang</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Status</span>
      		<p>Not reviewed yet</p>
      	</div>
      	<div class="RelativeBox">
      		<textarea class="PriceTxt" rows="5"></textarea>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Supplier</span>
      		<p>Ms.zhang Import/Export</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Contact</span>
      		<p>Ms zhang</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Reference</span>
      		<p>QT160700001</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Subject</span>
      		<p>2017 walmart selection</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Quote term</span>
      		<p>FOB</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Payment</span>
      		<p>30% TT in advance</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Loading port</span>
      		<p>shenzhen</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Expiry date</span>
      		<p>2016-09-02</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Delivery time</span>
      		<p>60 days</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Attachment</span>
      		<ul>
      			<li>工厂iso2001证书</li>
      			<li>工厂营业执照</li>
      		</ul>
      	</div>
      </div><!-- PriceShow -->

      <div id="PriceHide" class="PriceHide">
      	<form>
      	    <div class="RelativeBox PriceBox">
	      		<span class="inputName">Created on</span>
	      		<p>2016-07-02</p>
	      	</div>
	      	<div class="RelativeBox PriceBox">
	      		<span class="inputName">Saved on</span>
	      		<p>2016-07-03</p>
	      	</div>
	      	<div class="RelativeBox PriceBox">
	      		<span class="inputName">Created by</span>
	      		<p>by Huang</p>
	      	</div>
	      	<div class="RelativeBox PriceBox">
	      		<span class="inputName">Status</span>
	      		<p>Not reviewed yet</p>
	      	</div>
	      	<div class="RelativeBox">
	      		<textarea class="PriceTxt" rows="5"></textarea>
	      	</div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Supplier</span>
	          <div class="customSelect contactSelect">
	             <a class="customSelLink contactSelLink" href="javascript:void(0)"><span class="customSelTxt">Supplier</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
	             <ul class="list-unstyled customSelMsg contactSelUl" style="display: none;">
	               <li>供应商2</li>
	               <li>供应商3</li>
	               <li>供应商4</li>
	             </ul>
	          </div>
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Supplier</span>
	          <input type="text" class="inputVal">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Contact</span>
	          <input type="text" class="inputVal">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Reference</span>
	          <input type="text" class="inputVal">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Subject</span>
	          <input type="text" class="inputVal">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Quote term</span>
	          <input type="text" class="inputVal">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Payment</span>
	          <input type="text" class="inputVal">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Loading port</span>
	          <input type="text" class="inputVal">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Expiry date</span>
	          <input type="text" class="inputVal">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Delivery time</span>
	          <input type="text" class="inputVal">
	        </div>
	        <div class="RelativeBox font0 inputBox PriceBox">
	          <span class="inputName">Attavhment</span>
	          <ul>
      			<li class="detailZipInn"><a href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>工厂iso2001证书</li>
      			<li class="detailZipInn"><a href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>工厂营业执照</li>
      		</ul>
	        </div>
	      </form>
      </div><!-- PriceHide -->
  </div><!-- w24bf -->

  <div class="w48bf MinH RelativeBox">
      <header class="tempH">Product information</header>
      <div id="ProductDetailWrap" class="ProductDetailWrap">
      	<div class="ProductDetailL">
          <!-- 轮播图 -->
          <div class="ProductDetailImgW">
            <div id="ProductDetailImgB" class="ProductDetailImgB"><img class="img-responsive" src="img/userIcon.gif"></div>
            <ul id="ProductDetailImgInn" class="ProductDetailImgInn">
              <li><img class="img-responsive" src="img/userIcon.gif"></li>
              <li><img class="img-responsive" src="img/userIcon.gif"></li>
              <li><img class="img-responsive" src="img/userIcon.gif"></li>
              <li><img class="img-responsive" src="img/1.png"></li>
            </ul>
          </div>
    		  <!-- 轮播图 -->
          <div class="codeBox">
            <div class="codeBoxInn">
              <p>扫描条形码</p>
              <img src="img/2.png">
            </div>
            <div class="codeBoxInn">
              <p>二维码</p>
              <img src="img/3.png">
            </div>
          </div>

          <div class="detailZipBox">
            <p>附件</p>
            <div>HG003 Test Reports</div>
            <div>HG003 Test Reports</div>
          </div>
    	</div>

  		<div class="ProductDetailR">
        <div class="ProductDetailMsg">
          <div class="ProductDetailBox">
            <p><span>Department</span> Houseware</p>
            <p><span>Category</span> Mugs</p>
          </div>
          <div class="ProductDetailBox">
            <h4>Product detail</h4>
            <p><span>Item#</span> HG0003</p>
            <p><span>Description</span> double wall glass mugdouble wall glass mugdouble wall glass mugdouble wall glass mug</p>
            <p><span>Price</span> $2.60/pc</p>
            <p><span>Unit</span> pc</p>
            <p><span>MOQ</span> 1000</p>
            <p><span>Package</span> Color box</p>
          </div>

          <div class="ProductDetailBox">
            <h4>specification</h4>
            <p><span>Material</span> Borosilicate glass</p>
            <p><span>Size</span> 250ml</p>
          </div>

          <div class="ProductDetailBox">
            <h4>Shipping detail</h4>
            <p><span>QTY/Inner</span> number</p>
            <p><span>Inner/length</span> 24pc</p>
            <p><span>Inner width</span> 24pc</p>
            <p><span>Inner height</span> 24pc</p>
            <p><span>Inner CBM</span> 24pc</p>
            <p><span>QTY/CTN</span> 24pc</p>
            <p><span>CTN/length</span> 24pc</p>
            <p><span>CTN/width</span> 24pc</p>
            <p><span>CTN/height</span> 24pc</p>
            <p><span>CTN CBM</span> 24pc</p>
            <p><span>CTN/NW</span> 24pc</p>
            <p><span>CTN/GW</span> 24pc</p>
            <p><span>Qty/20ft</span> 24pc</p>
            <p><span>Qty/40ft</span> 24pc</p>
            <p><span>Qty/40HQ</span> 24pc</p>
            <!-- <div class="ProductDetailBoxInn">
            <span>loading</span>
            <ul>
              <li>16406/20ft</li>
              <li>16406/20ft</li>
              <li>16406/20ft</li>
            </ul>
            </div> -->

          </div>
        </div>
  		</div>
    </div><!-- ProductDetailWrap -->


    <div id="ProductDetailHide" class="ProductDetailHide">
      <div class="ProductDetailEditImg">

        <div class="ProductDetailImgW">
          <div id="ProDetailImg" class="ProductDetailImgB"><img class="img-responsive" src="img/1.png"><a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a> </div>
          <ul id="ProDetailImgInn" class="ProductDetailImgInn">
            <li><img class="img-responsive" src="img/userIcon.gif"><a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a> </li>
            <li><img class="img-responsive" src="img/1.png"><a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a> </li>
            <li><img class="img-responsive" src="img/1.png"><a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a> </li>
            <li><img class="img-responsive" src="img/1.png"><a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a> </li>
          </ul>
        </div>

        <div class="codeBox">
          <div class="codeBoxInn">
            <p>扫描条形码</p>
            <img src="img/2.png">
          </div>
          <div class="codeBoxInn">
            <p>二维码</p>
            <img src="img/3.png">
          </div>
        </div>
        <div class="detailZipBox">
          <p>附件</p>
          <div class="detailZipInn"><a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a> HG003 Test Reports</div>
          <div class="detailZipInn"><a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a> HG003 Test Reports</div>
        </div>
      </div>
      <div class="ProductDetailEditTxt">
        <div class="ProductDetailEditTxtInn">
        <form>
          <div class="RelativeBox ProductDetailEditBox">
            <span>Department</span>
            <div class="customSelect ProductEditSel">
               <a class="customSelLink ProductEditSelLink" href="javascript:void(0)"><span class="customSelTxt">日用品</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
               <ul class="list-unstyled customSelMsg ProductEditSelMsg">
                 <li>部门1</li>
                 <li>部门2</li>
               </ul>
            </div>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>Category</span>
            <div class="customSelect ProductEditSel">
               <a class="customSelLink ProductEditSelLink" href="javascript:void(0)"><span class="customSelTxt">未分类</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
               <ul class="list-unstyled customSelMsg ProductEditSelMsg">
                 <li>部门1</li>
                 <li>部门2</li>
               </ul>
            </div>
          </div>

          <h4>Product detail</h4>

          <div class="RelativeBox ProductDetailEditBox">
            <span>Item#</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>Description</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>Price</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>Unit</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>MOQ</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>Package</span>
            <input type="text"></input>
          </div>

          <h4>specification</h4>

          <div class="RelativeBox ProductDetailEditBox">
            <span>Material</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>Size</span>
            <input type="text"></input>
          </div>

          <h4>Shipping detail</h4>

          <div class="RelativeBox ProductDetailEditBox">
            <span>QTY/Inner</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>Inner/length</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>Inner width</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>Inner height</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>Inner CBM</span>
            <input type="text"></input>
          </div>


          <div class="RelativeBox ProductDetailEditBox">
            <span>QTY/CTN</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>CTN/length</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>CTN/width</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>CTN/height</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>CTN CBM</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>CTN/NW</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>CTN/GW</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>Qty/20ft</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>Qty/40ft</span>
            <input type="text"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>Qty/40HQ</span>
            <input type="text"></input>
          </div>

        </form>
        </div><!-- ProductDetailEditTxtInn -->

      </div>
    </div>



  </div>

  <div class="w24bf  MinH">
      <header class="tempH">导航栏</header>
      <div id="detailNavWrap" class="detailNavWrap">
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      </div>
  </div>

</section>

</div>
<!-- 主要内容盒子 -->

<!-- 展开列表内容盒子 隐藏-->
<div id="conBoxB" class="row conBox custerHide">
<div class="MinH conBg">
<div id="contableWrapAH" class="contableWrapA niceScroll">
   <table class="table table-bordered contableA">
      <tbody>
        <tr>
          <td>编辑着</td>
          <td>编辑日期</td>
          <td>状态</td>
          <td>标题</td>
          <td>报价序号</td>
          <td>供应商</td>
          <td>联系人</td>
          <td>价格条款</td>
          <td>付款方式</td>
          <td>装运港</td>
          <td>交货时间</td>
          <td>有效期</td>
          <td>附言</td>
          <td>编辑着</td>
          <td>编辑日期</td>
          <td>状态</td>
          <td>标题</td>
          <td>报价序号</td>
          <td>供应商</td>
          <td>联系人</td>
          <td>价格条款</td>
          <td>付款方式</td>
          <td>装运港</td>
          <td>交货时间</td>
          <td>有效期</td>
          <td>附言</td>
        </tr>
        <tr>
          <td>陈先生</td>
          <td>8/9/2016</td>
          <td>通过</td>
          <td>2017春节沃尔玛</td>
          <td>Qtr45465465</td>
          <td>张小姐有限公司</td>
          <td>FRK</td>
          <td>预付30%定金</td>
          <td>广州</td>
          <td></td>
          <td>9/2/2016</td>
          <td>65456+465465</td>
          <td>9+54+946</td>
          <td></td>
          <td>陈先生</td>
          <td>8/9/2016</td>
          <td>通过</td>
          <td>2017春节沃尔玛</td>
          <td>Qtr45465465</td>
          <td>张小姐有限公司</td>
          <td>FRK</td>
          <td>预付30%定金</td>
          <td>广州</td>
          <td></td>
          <td>9/2/2016</td>
          <td>65456+465465</td>
        </tr>
      </tbody>
    </table>
</div>


<div id="contableWrapList" class="contableWrap">
  <table id="table2-1">
    <tr>
        <th rowspan="" colspan=""></th>
    </tr>
  </table>
</div>
</div>


</div>
<!-- 展开列表内容盒子 隐藏-->

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/mmGrid.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">
// 编辑，保存，切换按钮
$(document).on("click","#DetailEdit",function(){
    var I = $(this);
    var PriceShow =$("#PriceShow");
    var PriceHide =$("#PriceHide");
    var ProductDetailWrap = $("#ProductDetailWrap");
    var ProductDetailHide = $("#ProductDetailHide");
    if (!!I.hasClass("active")) {
        I.removeClass("active");
        I.text("编辑");
        PriceShow.show();
        PriceHide.hide();
        ProductDetailHide.hide();
        ProductDetailWrap.show();
    }else{
        I.addClass("active");
        I.text("保存");
        PriceShow.hide();
        PriceHide.show();
        ProductDetailWrap.hide();
        ProductDetailHide.show();
    }
})
// 编辑，保存，切换按钮

// 删除图片
$(document).on("click",".DetailImgInn>a",function(){
    var I = $(this);
    var Ip = I.parent();
    Ip.remove();
})
// 删除图片

// 删除图片
$(document).on("click",".detailZipInn>a",function(){
    var I = $(this);
    var Ip = I.parent();
    Ip.remove();
})
// 删除图片

// 切换图片
$(document).on("click","#ProductDetailImgInn>li>img",function(){
    var I = $(this);
    var Is = I.attr("src");
    var tar = $("#ProductDetailImgB>img");
    var tars = tar.attr("src");
    I.attr("src",tars);
    tar.attr("src",Is);
})
// 切换图片

// 地下四张图片 删除事件
$(document).on("click",".ProductDetailImgInn>li>a",function(){
    var I = $(this);
    var Ip = I.parent();
    Ip.remove();
})
// 地下四张图片 删除事件

// 大图点击删除事件
$(document).on("click","#ProDetailImg>a",function(){
    var I = $(this);
    var Is = I.siblings("img");
    var IsImg = Is.attr("src");
    var tar = $("#ProDetailImgInn li");
    var tarImg = tar.eq(0).children("img").attr("src");
    if (tar.length == "") {
        I.parent().remove();
    }else{
        tar.eq(0).remove();
        Is.attr("src",tarImg);
    }
})
// 大图点击删除事件

// 基本信息编辑
$(document).on("click","#BasicInfoEdit",function(){
  var I = $(this);
  var Itxt = I.text();
    var Tar = $(".BasicInfoWrap");
    var TarS = Tar.siblings(".BasicInfoEditWrap");
    var Bs = $("#BasicInfoSava");
    switch(Itxt){
      case '编辑':
          Tar.hide();
          TarS.fadeIn();
          I.html("保存");
          Bs.hide();
      break;
      case '保存':
          TarS.hide();
          Tar.fadeIn();
          I.html("编辑");
          Bs.show();
      break;
    }
})
$(document).on("click","#BasicInfoCancel",function(){
  var I = $("#BasicInfoEdit");
  var Itxt = I.text();
  var Tar = $(".BasicInfoWrap");
  var TarS = Tar.siblings(".BasicInfoEditWrap");
  var Bs = $("#BasicInfoSava");
  TarS.hide();
  Tar.fadeIn();
  I.html("编辑");
  Bs.show();
})
// 基本信息编辑
</script>
</body>
</html>