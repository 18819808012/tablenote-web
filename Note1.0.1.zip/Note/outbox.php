<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">Outbox <a class="changeHtml" href="Zn/outbox.php">切换</a></span>
        <a id="changList" class="changList" href="javascript:void(0);"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span></a>

        <div class="conHeadLinkBox">
          <a id="showHideLink" class="conHeadLink showHideLink showHideLink01" href="javascript:void(0);">隐藏选项栏</a>
          <a class="conHeadLink outboxHistory" href="javascript:void(0)">History</a>
      		<a class="conHeadLink outboxEdit" href="edit.php">Edit</a>
          <div class="conHeadLink inboxOut inboxOutb">
          <div class="RelativeBox">
            Export
            <div class="OutfileBox OutfileBoxa">
              <a href="javascript:void(0);">Excel</a>
              <a href="javascript:void(0);">PDF</a>
              <a href="javascript:void(0);">二维码</a>
            </div>
          </div>
          </div>
        </div>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 标题，供应商，创建者，时间，菜单栏的列表模式切换 -->
<a id="showHideLink" class="showHideLink" href="javascript:void(0);"><span class="glyphicon glyphicon-chevron-right"></span></a>
<!-- 标题，供应商，创建者，时间，菜单栏的列表模式切换 -->

<!-- 主要内容盒子 -->
<div class="row conBox">

<section class="row ClearLR font0">
  <div class="w24bf MinH2 productCenterL RelativeBox">
    <ul id="productListTitle" class="productListTitle">
		<li class="productBR">Subject</li>
    <li class="productBR">Supplier</li>
    <li class="productBR">Created by</li>
    <li>Time</li>
	</ul>

	<ul id="productListMsgB" class="productListMsg">
	    <li>
			<a href="javascript:void(0)">
				<h4>2017春节沃尔玛</h4>
				<p>张小姐有限公司</p>
				<p>黄希</p>
				<p>2016-07-02</p>
			</a>
		</li>
		<li>
			<a href="javascript:void(0)">
				<h4>2017春节沃尔玛</h4>
				<p>张小姐有限公司</p>
				<p>黄希</p>
				<p>2016-07-02</p>
			</a>
		</li>
		<li>
			<a href="javascript:void(0)">
				<h4>2017春节沃尔玛</h4>
				<p>张小姐有限公司</p>
				<p>黄希</p>
				<p>2016-07-02</p>
			</a>
		</li>
		<li>
			<a href="javascript:void(0)">
				<h4>2017春节沃尔玛</h4>
				<p>张小姐有限公司</p>
				<p>黄希</p>
				<p>2016-07-02</p>
			</a>
		</li>
		<li>
			<a href="javascript:void(0)">
				<h4>2017春节沃尔玛</h4>
				<p>张小姐有限公司</p>
				<p>黄希</p>
				<p>2016-07-02</p>
			</a>
		</li>
		<li>
			<a href="javascript:void(0)">
				<h4>2017春节沃尔玛</h4>
				<p>张小姐有限公司</p>
				<p>黄希</p>
				<p>2016-07-02</p>
			</a>
		</li>
		<li>
			<a href="javascript:void(0)">
				<h4>2017春节沃尔玛</h4>
				<p>张小姐有限公司</p>
				<p>黄希</p>
				<p>2016-07-02</p>
			</a>
		</li>
		<li>
			<a href="javascript:void(0)">
				<h4>2017春节沃尔玛</h4>
				<p>张小姐有限公司</p>
				<p>黄希</p>
				<p>2016-07-02</p>
			</a>
		</li>
		<li>
			<a href="javascript:void(0)">
				<h4>2017春节沃尔玛</h4>
				<p>张小姐有限公司</p>
				<p>黄希</p>
				<p>2016-07-02</p>
			</a>
		</li>
		<li>
			<a href="javascript:void(0)">
				<h4>2017春节沃尔玛</h4>
				<p>张小姐有限公司</p>
				<p>黄希</p>
				<p>2016-07-02</p>
			</a>
		</li>
		<li>
			<a href="javascript:void(0)">
				<h4>2017春节沃尔玛</h4>
				<p>张小姐有限公司</p>
				<p>黄希</p>
				<p>2016-07-02</p>
			</a>
		</li>
		<li>
			<a href="javascript:void(0)">
				<h4>2017春节沃尔玛</h4>
				<p>张小姐有限公司</p>
				<p>黄希</p>
				<p>2016-07-02</p>
			</a>
		</li>
	</ul>
  </div>

  <div id="conBoxA" class="w75bf MinH conBg conProductList productListWrapBox productCenterR">
    <div class="productListBox">
      <a href="detail.php">
        <img src="img/1.png">
        <p>货号 <span class="productPrice">$2.50/只</span></p>
        <p class="productName">双层玻璃马克杯</p>
        <p>玻璃，250毫升（规格尺寸）</p>
      </a>
    </div>
  </div>

    <!-- 展开列表内容盒子 隐藏-->
  <div id="conBoxB" class="w75bf MinH conBg conProductList custerHide">
  <div id="contableWrapAH" class="contableWrapA">
     <table class="table table-bordered contableA">
        <tbody>
          <tr>
            <td>编辑着</td>
            <td>编辑日期</td>
            <td>状态</td>
            <td>标题</td>
            <td>报价序号</td>
            <td>供应商</td>
            <td>联系人</td>
            <td>价格条款</td>
            <td>付款方式</td>
            <td>装运港</td>
            <td>交货时间</td>
            <td>有效期</td>
            <td>附言</td>
            <td>编辑着</td>
            <td>编辑日期</td>
            <td>状态</td>
            <td>标题</td>
            <td>报价序号</td>
            <td>供应商</td>
            <td>联系人</td>
            <td>价格条款</td>
            <td>付款方式</td>
            <td>装运港</td>
            <td>交货时间</td>
            <td>有效期</td>
            <td>附言</td>
          </tr>
          <tr>
            <td>陈先生</td>
            <td>8/9/2016</td>
            <td>通过</td>
            <td>2017春节沃尔玛</td>
            <td>Qtr45465465</td>
            <td>张小姐有限公司</td>
            <td>FRK</td>
            <td>预付30%定金</td>
            <td>广州</td>
            <td></td>
            <td>9/2/2016</td>
            <td>65456+465465</td>
            <td>9+54+946</td>
            <td></td>
            <td>陈先生</td>
            <td>8/9/2016</td>
            <td>通过</td>
            <td>2017春节沃尔玛</td>
            <td>Qtr45465465</td>
            <td>张小姐有限公司</td>
            <td>FRK</td>
            <td>预付30%定金</td>
            <td>广州</td>
            <td></td>
            <td>9/2/2016</td>
            <td>65456+465465</td>
          </tr>
        </tbody>
      </table>
  </div>

  <div id="contableWrapList" class="contableWrap">
    <table id="table2-1">
      <tr>
          <th rowspan="" colspan=""></th>
      </tr>
    </table>
  </div>
  </div>
  <!-- 展开列表内容盒子 隐藏-->


</section>
</div>
<!-- 主要内容盒子 -->


</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/json2.js"></script>
<script src="js/mmGrid.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript"></script>
</body>
</html>
