<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="format-detection" content="telephone=no, email=no"/>
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>demo</title>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/css.css" rel="stylesheet">
<link href="css/index.css" rel="stylesheet">
<!--[if lt IE 9]>
      <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
<div class="container-fluid">
<div class="row">
    
    <!-- 轮播图 -->
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
	  <ol class="carousel-indicators">
	    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
	    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
	  </ol>
	  <div class="carousel-inner" role="listbox">
	    <div class="item active">
	      <img src="img/00.jpg" alt="...">
	      <div class="carousel-caption">
	        123456789
	      </div>
	    </div>
	    <div class="item">
	      <img src="img/00.jpg" alt="...">
	      <div class="carousel-caption">
	        123456789
	      </div>
	    </div>
	  </div>
	  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
	    <span class="glyphicon glyphicon-chevron-left"></span>
	    <span class="sr-only">Previous</span>
	  </a>
	  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
	    <span class="glyphicon glyphicon-chevron-right"></span>
	    <span class="sr-only">Next</span>
	  </a>
	</div>
	<!-- 轮播图 -->

	<nav class="indexNav"> 
	    <span class="indexLogo">Tablenote</span>
		<ul class="indexNavUl">
			<li><a href="#">nav01</a></li>
			<li><a href="#">nav02</a></li>
			<li><a href="#">nav03</a></li>
		</ul>
	</nav>
</div>

<div class="row">
	<h3 class="text-center">YOUR PERSONAL MERCHIANDSE</h3>
	<div class="col-sm-5 col-sm-offset-1 text-center"><img src="img/01.png"></div>
	<div class="col-sm-5 col-sm-offset-1 text-center"><img src="img/01.png"></div>
</div>

<div class="row text-center">
	<h2>Tablenote</h2>
	<div>
		<p>Quotations,samples and orders are always in disorder after exhibition?</p>
		<p>You will get your personal merchandiserl</p>
		<p><a href="#">Learn more ></a></p>
		<p>Take notes with pictures for the products you need develop with your business partners,</p>
		<p>Then Export notes as PDF to share Or get a execl list for following up after meeting.</p>
	</div>
</div>

<div class="row">
	<div class="col-sm-4 downLoadBox">
		<a href="#" class="downloadLink">Down on the App Store</a>
		<a href="#" class="downloadLink">Down on the Android Store</a>
	</div>
	<div class="col-sm-8">
		<img src="img/01.png">
	</div>
</div>

<div class="row text-center">
	<h2>CataX</h2>
	<div>
		<p>Achieve buying goal and present products with a powerful quotation and supplier management app.</p>
		<p>You will get your personal merchandiser!</p>
		<p>Upload your product and supplier information to CataX management system</p>
		<p>All buying professionals can find and view supplier and product information whenever they need.</p>
	</div>
</div>

<div class="row">
	<div class="col-sm-4 downLoadBox">
		<a href="#" class="downloadLink">Down on the App Store</a>
		<a href="#" class="downloadLink">Down on the Android Store</a>
	</div>
	<div class="col-sm-8">
		<img src="img/01.png">
	</div>
</div>

<div class="row">
	<h3 class="contactUsTit">CONTACT US</h3>
	<div class="contactUsLink">
	    <a href="#"><img src="img/facebook.png"></a>
	    <a href="#"><img src="img/twitter.png"></a>
	    <a href="#"><img src="img/facebook.png"></a>
	    <a href="#"><img src="img/twitter.png"></a>
	</div>
	<p class="text-center">You can mail us your ideas by ideas@tablenate.com</p>
</div>

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
</body>
</html>