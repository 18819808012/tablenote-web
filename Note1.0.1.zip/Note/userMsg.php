<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">Member permission <a class="changeHtml" href="Zn/userMsg.php">切换</a></span>
    <div class="conHeadLinkBox">
  		<a class="conHeadLink" href="javascript:void(0);">Save</a>
      <a class="conHeadLink" href="javascript:void(0);">Cancel</a>
    </div>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 主要内容盒子 -->
<div class="row conBox">

<section class="row ClearLR font0">
  <div class="w24bf MinH">
    <div class="userMsg">
      <div class="userIconBox mb10"><div class="userIconInn"><img src="img/userIcon.gif" class="img-circle"></div></div>
      <p class="S_userName">布兰妮</p>
      <p class="S_userEmail">Britney@b.com</p>
      <a class="userLink settingAdmin" id="settingAdmin" href="javascript:void(0);" name="admin">Set this member as administrator</a>
      <p>Member permission：</p>
      <p>Administrator can view products of all categories,create categories and templates,as well as invite and approved members.</p>
      <a class="userLink removeNumbers" href="javascript:void(0);">Remove this member</a>
      <p>The removed members will not be allowed to access the company's data anyway the related data will still be kept in the system.</p>
    </div>
  </div>

  <div class="w24bf MinH">
    <header class="conHeadTip">In charge of</header>
    <div class="userMsgTool"><a id="userToolDelete" href="javascript:void(0);">Remove all</a></div>
    <ul class="userProduct" id="userProduct">
      <li>
        <a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a><span class="userProSpan">餐具</span>
      </li>
      <li>
        <a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a><span class="userProSpan">餐具</span>
      </li>
      <li>
        <a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a><span class="userProSpan">餐具</span>
      </li>
      <li>
        <a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a><span class="userProSpan">餐具</span>
      </li>
    </ul>
  </div>


  <div class="w24bf MinH">
    <header class="conHeadTip">Department</header>
    <div class="userMsgTool"><a class="allChecked" href="javascript:void(0);">Select all</a></div>
    <div class="userDepartment" id="userDepartment">
      <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">日用品</span></a>
      <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">家电</span></a>
      <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">家电</span></a>
      <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">家电</span></a>
    </div>
  </div>

  <div class="w24bf MinH" id="userSortW">
    <header class="conHeadTip">category</header>
    <div class="userMsgTool"><a class="allChecked" href="javascript:void(0);">Select all</a></div>
    <div class="userDepartment" id="userSort">
      <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">日用品</span></a>
      <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">家电</span></a>
      <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">家电</span></a>
      <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">家电</span></a>
    </div>
  </div>

</section>

</div>
<!-- 主要内容盒子 -->

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">
// 全部移除
$(document).on("click","#userToolDelete",function(){
    var I = $(this);
    var tar = $("#userProduct").children();
    tar.remove();
})
// 全选
$(document).on("click",".allChecked",function(){
    var I = $(this);
    var tar = I.parent(".userMsgTool").siblings().children(".customCheck");
    tar.addClass("active");
})
// 设置为管理员
$(document).on("click","#settingAdmin",function(){
    var I = $(this);
    var tar = $("#userSortW");
    var Iv = I.attr("name");
    var iconbox = $(".userIconInn");
    var icon = '<img class="img-circle userI" id="userI" src="img/loading.gif">';
    switch(Iv){
      case 'admin':
          I.attr("name","noadmin");
          I.text("Remove this member's administration");
          iconbox.append(icon);
      break;
      case 'noadmin':
          I.attr("name","admin")
          I.text("Set this member as administrato");
          $("#userI").remove();
      break;
    }
})



</script>
</body>
</html>