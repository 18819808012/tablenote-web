<?php
include_once 'inc/head.php';
?>


<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">历史记录 <a class="changeHtml" href="../history.php">切换</a></span>
		<a class="conHeadLink historyShow" href="javascript:void(0)">显示每次编辑完整内容</a>
		<a class="conHeadLink historyOut" href="javascript:void(0)">退出</a>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 主要内容盒子 -->
<div class="row conBox">
<section class="row ClearLR font0">
    <div id="historyTableWA"><table id="historyTableA"></table></div>
    <div id="historyTableWB"><table id="historyTableB"></table></div>
	<div id="historyTableWC"><table id="historyTableC"></table></div>
    <div class="mb10"><table id="historyTableD"></table></div>
</section>
</div>
<!-- 主要内容盒子 -->

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/json2.js"></script>
<script src="js/mmGrid.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">
</script>
</body>
</html>