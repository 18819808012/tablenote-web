<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="format-detection" content="telephone=no, email=no"/>
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>demo</title>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/css.css" rel="stylesheet">
<link href="css/loginAndRegister.css" rel="stylesheet">
<!--[if lt IE 9]>
      <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
<div class="container-fluid">
<canvas id="Mycanvas" class="Mycanvas"></canvas>

<header class="row loginHead">www.tablenote.com</header>

<div class="row">
  <!-- register -->
  <div id="register" class="registerWrap">
    <h3 class="text-center mb20">还没有TableNote账户？现在注册</h3>
    <form class="form-horizontal" role="form">
      <div class="LoginBox">
        <label class="LoginTxt LoginTxtIcon">添加个人头像</label>
          <div class="LoginFileBox">
            <input type="file" class="conOpacity"></input>
            <img class="img-circle LoginUserIcon" src="img/1.png">
          </div>
      </div>
      <div class="LoginBox">
        <label class="LoginTxt"><span class="mustLogin">*</span> 用户名</label>
        <input type="text" class="LoginIn" placeholder="请输入用户名">
      </div>
      <div class="LoginBox">
        <label class="LoginTxt"><span class="mustLogin">*</span> 邮箱</label>
        <input type="email" class="LoginIn" placeholder="请输入邮箱">
      </div>
      <div class="LoginBox">
        <label class="LoginTxt"><span class="mustLogin">*</span> 密码</label>
        <input type="password" class="LoginIn" placeholder="请输入密码">
      </div>
      <div class="LoginBox">
        <label class="LoginTxt"><span class="mustLogin">*</span> 确认密码</label>
        <input type="password" class="LoginIn" placeholder="请再次输入密码">
      </div>
      <div class="LoginBox">
        <label class="LoginTxt">职位</label>
        <input type="text" class="LoginIn" placeholder="请输入职位">
      </div>
      <div class="LoginBox">
        <label class="LoginTxt">固定电话</label>
        <input type="text" class="LoginIn" placeholder="请输入固定电话">
      </div>
      <div class="LoginBox">
        <label class="LoginTxt">手机</label>
        <input type="text" class="LoginIn" placeholder="请输入手机">
      </div>
      <div class="LoginBox">
        <label class="LoginTxt">领英账号</label>
        <input type="text" class="LoginIn" placeholder="请输入领英账号">
      </div>
      <div class="LoginBox">
        <label class="LoginTxt">What's App账户</label>
        <input type="text" class="LoginIn" placeholder="请输入What's App账户">
      </div>
      <div class="LoginBox">
        <label class="LoginTxt">Skype账号</label>
        <input type="text" class="LoginIn" placeholder="请输入Skype账号">
      </div>
      <div class="LoginBox">
        <label class="LoginTxt">微信账号</label>
        <input type="text" class="LoginIn" placeholder="请输入微信账号">
      </div>
      <div class="RelativeBox agentment">
        <div class="checkWrap mb10"><input type="checkbox" checked> 遵守TableNote.com会员协议,愿意接收相关来自TableNote.com的会员及服务邮件</div>
      </div>
      <div class="RelativeBox mb10">
          <button type="submit" class="LoginBtn">注 册</button>
      </div>
      <p class="text-right"><a id="changeLogin" href="javascript:void(0);">已注册，去登录</a></p>
    </form>
  </div><!-- register -->

  <!-- login -->
  <div id="login" class="loginWrap">
    <h3 class="text-center mb20">请登录您的TableNote账户</h3>
    <form role="form">
    <div class="RelativeBox mb10">
      <input type="email" class="LoginIn" placeholder="Enter email">
    </div>
    <div class="RelativeBox mb10">
      <input type="password" class="LoginIn" placeholder="Password">
    </div>
    <div class="RelativeBox mb10">
      <div class="checkWrap"><input type="checkbox" checked> 记住密码</div>
      <a class="forget" href="javascript:void(0);"> 忘记密码</a>
    </div>
    <button type="button" id="LoginBtn" class="LoginBtn">登 录</button>
    <p class="text-right"><a id="changeRegister" href="javascript:void(0);">还没有TableNote账户？现在注册</a></p>
  </form>
  </div>
  <!-- login -->


  <div id="CreatOrJoin" class="CreatOrJoin">
    <h1>请选择</h1>
    <a href="javascript:void(0);" class="CreateLink" data-toggle="modal" data-target="#CreateLinkM">创建公司</a>
    <span>或者</span>
    <a href="javascript:void(0);" class="joinLink" data-toggle="modal" data-target="#joinLinkM">加入我们的公司</a>
  </div>

</div>

</div><!-- container-fluid -->

<!-- Create a company -->
<div class="modal fade" id="CreateLinkM" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog CreatDialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title text-center" id="myModalLabel">创建公司</h4>
      </div>
      <div class="modal-body">
        <p>提交以下信息，创建贵司资料，即可：</p>
        <p>1，邀请公司成员加入，共同管理供应商及产品</p>
        <p>2，为贵司生成供应商入口，供应商可注册登录，给贵司提交产品及报价信息。</p>
        <form>
          <div class="RelativeBox mb10 CreatFileBox">
            <img src="img/usericon.gif" class="creatUserIcon">
            <input type="file" class="CreatFile conOpacity">
            <a class="CreatFileLink" href="javascript:void(0);">点击添加公司头像</a>
          </div>
          <div class="RelativeBox mb10">
            <input type="text" class="LoginIn" placeholder="公司名称（必填）">
          </div>
          <div class="RelativeBox mb10">
            <input type="text" class="LoginIn" placeholder="公司网址">
          </div>
          <div class="RelativeBox mb10">
            <input type="text" class="LoginIn" placeholder="领英账号">
          </div>
          <div class="RelativeBox mb10">
            <input type="text" class="LoginIn" placeholder="地址">
          </div>
          <div class="RelativeBox mb10">
            <input type="text" class="LoginIn" placeholder="地址二">
          </div>
          <div class="RelativeBox mb10">
            <input type="text" class="LoginIn" placeholder="地址三">
          </div>
          <div class="RelativeBox mb10">
            <input type="text" class="LoginIn" placeholder="地址四">
          </div>
          <div class="RelativeBox mb10">
            <input type="text" class="LoginIn" placeholder="行业">
          </div>
          <div class="RelativeBox mb10">
            <input type="text" class="LoginIn" placeholder="采购产品">
          </div>
          <div class="RelativeBox mb10">
            <textarea class="creatTextArea" placeholder="公司简介" rows="5"></textarea>
          </div>
          <div class="text-center">
            <a class="toCreatC" href="setting.php">立即创建公司</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- Create a company -->

<!-- To join our company -->
<div class="modal fade" id="joinLinkM" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog joinDialog" id="joinDialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title text-center" id="myModalLabel">加入公司</h4>
      </div>
      <div class="modal-body">
        <p>请在下面输入框中填写贵司管理人员提供的公司编号，然后点击申请加入公司。</p>
        <div class="RelativeBox mb10">
          <input type="text" class="LoginIn" placeholder="请在此输入贵司编号">
        </div>
        <div class="applyjoinBox">
          <a class="applyjoin" href="javascript:void(0);">申请加入</a>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- To join our company -->

<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
<script src="js/canvas.js"></script>
<script type="text/javascript">
$(function(){

  $("#login").css("padding-top",(WH - registerH)/2);//登陆高度
  $("#register").css("padding-top",(WH - registerH)/2);//注册高度
  $("#CreatOrJoin").css("padding-top",WH/3); //选择创建or加入公司
  $("#joinDialog").css("margin-top",WH/3); //选择弹出框居中定位

  $(document).on("click","#changeRegister",function(){
    var IL = $("#login");
    var IR = $("#register");
    IL.hide();
    IR.show();
  })
  
  $(document).on("click","#changeLogin",function(){
      var IL = $("#login");
      var IR = $("#register");
      IR.hide();
      IL.show();
  })

  // 点击登录
  $(document).on("click","#LoginBtn",function(){
      var IL = $("#login");
      var CreatOrJoin =$("#CreatOrJoin");
      IL.hide();
      CreatOrJoin.show();
  })
  // 点击登录

})
</script>
</body>
</html>