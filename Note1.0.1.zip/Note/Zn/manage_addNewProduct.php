<?php
include_once 'inc/head.php';
?>


<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">添加产品 <a class="changeHtml" href="../manage_addNewProduct.php">切换</a></span>
	</div>
</header>
<!-- 头部固定栏 -->

<div class="row conBox">
<section class="row ClearLR addNewProductBox MinH">
    <p class="text-center"><strong>第一步：选择报价产品所属的部门</strong></p>
    <p class="text-center">说明：您必须选择部门才可以开始报价</p>
    <div class="mb30 text-center">
	    <div class="customSelect">
	       <a id="selParted" class="customSelLink addNewProductSelLink" href="javascript:void(0)"><span class="customSelTxt">请选择部门</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
	       <ul id="selPart" class="list-unstyled customSelMsg addNewProductSelMsg">
	       </ul>
	    </div>
	</div>
    <div class="mb30 text-center">
	    <div class="customSelect">
	       <a id="selSorted" class="customSelLink addNewProductSelLink" href="javascript:void(0)"><span class="customSelTxt">请选择分类</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
	       <ul id="selSort" class="list-unstyled customSelMsg addNewProductSelMsg">
	       </ul>
	    </div>
	</div>
    <p class="text-center"><strong>第二部：选择报价产品所属的分类</strong></p>
    <p class="addNewProductTet">说明：不同分类的产品可能由不同的人员跟进，所以选择准确的产品分类对我司处理您的报价非常重要。</p>
    <p class="addNewProductTet">如果你不确定产品分类，或者该次提交的产品有多个分类，可以在进入编辑页面后再选择或者不选择。</p>
    <p class="addNewProductTet">请按照要求提供产品报价的详细内容。如果是容器类的产品，在尺寸一栏同时提供产品容量。</p>
    <div class="addNewProductCheck"><label><input type="checkbox"> <span>记住我选择的部门和分类</span></label></div>
    <div class="addNewProductLink"><a id="addDetail" href="javascript:void(0);">逐个添加报价</a></div>
    <div class="addNewProductLink"><a href="#">从Excel批量导入</a></div>
</section>
</div>

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">

$.get('js/data.js', function(data) {
	// console.log(dataC.select_a[0].id);
	$.each(dataC.select_a, function(index, item) {
        // console.log("<div>"+ item.id + "</div>" + "<div>"+ item.Name + "</div><hr/>");
        var selA = '<li id="'+item.id+'">'+ item.Name +'</li>';
        $("#selPart").append(selA);
    });

    $.each(dataC.select_b, function(index, item) {
        // console.log("<div>"+ item.id + "</div>" + "<div>"+ item.Name + "</div><hr/>");
        var selA = '<li id="'+item.id+'">'+ item.Name +'</li>';
        $("#selSort").append(selA);
    });

});

$(document).on("click","#addDetail",function(){
	var I = $(this);
	var selParted = $("#selParted .customSelTxt").attr("id");
	var selSorted = $("#selSorted .customSelTxt").attr("id");
    var url = "addDetail.php" + '?' + selParted + '&' +selSorted;
    console.log(url);
    location.href = "url";
})
</script>
</body>
</html>