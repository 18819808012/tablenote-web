<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">收件箱 <a class="changeHtml" href="../Inbox.php">切换</a></span>
        <a id="changList" class="changList" href="javascript:void(0);"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span></a>
        
        <div class="conHeadLinkBox">
			<a class="conHeadLink" href="javascript:void(0)">添加到样品单</a>
			<a class="conHeadLink" href="history.php">历史记录</a>
			<a class="conHeadLink" data-toggle="modal" data-target="#requestUpdate" href="javascript:void(0)">要求更新</a>
			<a class="conHeadLink" href="edit.php">编辑</a>
			<div class="conHeadLink inboxOut inboxOuta">
			<div class="RelativeBox">
				导出
				<div class="OutfileBox OutfileBoxa">
					<a href="javascript:void(0);">Excel</a>
					<a href="javascript:void(0);">PDF</a>
					<a href="javascript:void(0);">二维码</a>
				</div>
			</div>
			</div>
			<a class="conHeadLink inboxAudit" href="javascript:void(0)">审核</a>
		</div>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 标题，供应商，创建者，时间，菜单栏的列表模式切换 -->
<a id="showHideLink" class="showHideLink" href="javascript:void(0);"><span class="glyphicon glyphicon-chevron-right"></span></a>
<!-- 标题，供应商，创建者，时间，菜单栏的列表模式切换 -->

<!-- 主要内容盒子 -->
<div class="row conBox">

<section class="row ClearLR font0">
  <div class="w24bf MinH2 productCenterL RelativeBox">
    <ul class="nav InboxNav" role="tablist">
		<li class="active"><a href="#details" role="tab" data-toggle="tab">详情</a></li>
		<li><a href="#classify" role="tab" data-toggle="tab">分类</a></li>
	</ul>
	<div class="tab-content">

		<div class="tab-pane active" id="details">
			<ul id="productListTitle" class="productListTitle">
				<li class="productBR">标题</li>
				<li class="productBR">供应商</li>
				<li class="productBR">创建者</li>
				<li>时间</li>
			</ul>
			<ul id="productListMsg" class="productListMsg">
			    <li>
					<a href="javascript:void(0)">
						<h4>2017春节沃尔玛</h4>
						<p>张小姐有限公司</p>
						<p>黄希</p>
						<p>2016-07-02</p>
					</a>
					<span class="Tipdot Tipdot01"></span>
				</li>
				<li>
					<a href="javascript:void(0)">
						<h4>2017春节沃尔玛</h4>
						<p>张小姐有限公司</p>
						<p>黄希</p>
						<p>2016-07-02</p>
					</a>
					<span class="Tipdot Tipdot02"></span>
				</li>
				<li>
					<a href="javascript:void(0)">
						<h4>2017春节沃尔玛</h4>
						<p>张小姐有限公司</p>
						<p>黄希</p>
						<p>2016-07-02</p>
					</a>
					<span class="Tipdot Tipdot03"></span>
				</li>
				<li>
					<a href="javascript:void(0)">
						<h4>2017春节沃尔玛</h4>
						<p>张小姐有限公司</p>
						<p>黄希</p>
						<p>2016-07-02</p>
					</a>
					<span class="Tipdot Tipdot04"></span>
				</li>
				<li>
					<a href="javascript:void(0)">
						<h4>2017春节沃尔玛</h4>
						<p>张小姐有限公司</p>
						<p>黄希</p>
						<p>2016-07-02</p>
					</a>
					<span class="Tipdot Tipdot01"></span>
				</li>
				<li>
					<a href="javascript:void(0)">
						<h4>2017春节沃尔玛</h4>
						<p>张小姐有限公司</p>
						<p>黄希</p>
						<p>2016-07-02</p>
					</a>
					<span class="Tipdot Tipdot01"></span>
				</li>
				<li>
					<a href="javascript:void(0)">
						<h4>2017春节沃尔玛</h4>
						<p>张小姐有限公司</p>
						<p>黄希</p>
						<p>2016-07-02</p>
					</a>
					<span class="Tipdot Tipdot01"></span>
				</li>
				<li>
					<a href="javascript:void(0)">
						<h4>2017春节沃尔玛</h4>
						<p>张小姐有限公司</p>
						<p>黄希</p>
						<p>2016-07-02</p>
					</a>
					<span class="Tipdot Tipdot01"></span>
				</li>
				<li>
					<a href="javascript:void(0)">
						<h4>2017春节沃尔玛</h4>
						<p>张小姐有限公司</p>
						<p>黄希</p>
						<p>2016-07-02</p>
					</a>
					<span class="Tipdot Tipdot01"></span>
				</li>
			</ul>

			<ul id="productListLink" class="productListLink">
				<li class="productBR"><a href="#"><span class="Tipdot Tipdot01"></span>核准</a></li>
				<li class="productBR"><a href="#"><span class="Tipdot Tipdot02"></span>拒绝</a></li>
				<li class="productBR"><a href="#"><span class="Tipdot Tipdot03"></span>待定</a></li>
				<li><a href="#"><span class="Tipdot Tipdot04"></span>未读</a></li>
			</ul>
		</div><!-- details -->

		<div class="tab-pane" id="classify">
		    <ul id="classifyUl" class="classifyUl">
		    	<li>
		    		<h5>产品部门名称</h5>
		    		<div class="classifyInn">
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    		</div>
		    	</li>
		    	<li>
		    		<h5>产品部门名称</h5>
		    		<div class="classifyInn">
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    		</div>
		    	</li>
		    	<li>
		    		<h5>产品部门名称</h5>
		    		<div class="classifyInn">
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    		</div>
		    	</li>
		    	<li>
		    		<h5>产品部门名称</h5>
		    		<div class="classifyInn">
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    		</div>
		    	</li>
		    	<li>
		    		<h5>产品部门名称</h5>
		    		<div class="classifyInn">
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    		</div>
		    	</li>
		    	<li>
		    		<h5>产品部门名称</h5>
		    		<div class="classifyInn">
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    		</div>
		    	</li>
		    	<li>
		    		<h5>产品部门名称</h5>
		    		<div class="classifyInn">
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    		</div>
		    	</li>
		    	<li>
		    		<h5>产品部门名称</h5>
		    		<div class="classifyInn">
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    			<p>产品分类名称</p>
		    		</div>
		    	</li>
		    </ul>
		</div><!-- classify -->

	</div>
  </div>

	<div id="conBoxA" class="w75bf MinH conBg conProductList productListWrapBox productCenterR">
		<div class="productListBox">
			<a href="detail.php">
				<img src="img/1.png">
				<p>货号 <span class="productPrice">$2.50/只</span></p>
				<p class="productName">双层玻璃马克杯</p>
				<p>玻璃，250毫升（规格尺寸）</p>
			</a>
		</div>
	</div>

    <!-- 展开列表内容盒子 隐藏-->
	<div id="conBoxB" class="w75bf MinH conBg conProductList custerHide">
	<div id="contableWrapAH" class="contableWrapA">
	   <table class="table table-bordered contableA">
	      <tbody>
	        <tr>
	          <td>编辑着</td>
	          <td>编辑日期</td>
	          <td>状态</td>
	          <td>标题</td>
	          <td>报价序号</td>
	          <td>供应商</td>
	          <td>联系人</td>
	          <td>价格条款</td>
	          <td>付款方式</td>
	          <td>装运港</td>
	          <td>交货时间</td>
	          <td>有效期</td>
	          <td>附言</td>
	          <td>编辑着</td>
	          <td>编辑日期</td>
	          <td>状态</td>
	          <td>标题</td>
	          <td>报价序号</td>
	          <td>供应商</td>
	          <td>联系人</td>
	          <td>价格条款</td>
	          <td>付款方式</td>
	          <td>装运港</td>
	          <td>交货时间</td>
	          <td>有效期</td>
	          <td>附言</td>
	        </tr>
	        <tr>
	          <td>陈先生</td>
	          <td>8/9/2016</td>
	          <td>通过</td>
	          <td>2017春节沃尔玛</td>
	          <td>Qtr45465465</td>
	          <td>张小姐有限公司</td>
	          <td>FRK</td>
	          <td>预付30%定金</td>
	          <td>广州</td>
	          <td></td>
	          <td>9/2/2016</td>
	          <td>65456+465465</td>
	          <td>9+54+946</td>
	          <td></td>
	          <td>陈先生</td>
	          <td>8/9/2016</td>
	          <td>通过</td>
	          <td>2017春节沃尔玛</td>
	          <td>Qtr45465465</td>
	          <td>张小姐有限公司</td>
	          <td>FRK</td>
	          <td>预付30%定金</td>
	          <td>广州</td>
	          <td></td>
	          <td>9/2/2016</td>
	          <td>65456+465465</td>
	        </tr>
	      </tbody>
	    </table>
	</div>

	<div id="contableWrapList" class="contableWrap">
	  <table id="table2-1">
	    <tr>
	        <th rowspan="" colspan=""></th>
	    </tr>
	  </table>
	</div>
	</div>
	<!-- 展开列表内容盒子 隐藏-->



</section>
</div>
<!-- 主要内容盒子 -->
</div><!-- container-fluid -->


<!-- 要求更新 -->
<div class="modal fade" id="requestUpdate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog requestUpdateDia">
    <div class="modal-content">
      <div class="modal-body">

        <!-- 有供应商的情况显示 -->
        <div class="requestUpdateHas">
        	<p>供应商名称</p>
        	<p>联系人名称</p>
        </div>
        <!-- 有供应商的情况显示 -->

        <!-- 没有供应商的情况显示 -->
        <div class="requestUpdateNull">
        	<div class="customSelect requestUpdateSelWrap">
		       <a id="selParted" class="customSelLink requestUpdateSel" href="javascript:void(0)"><span class="customSelTxt">请选择部门</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
		       <ul id="selPart" class="list-unstyled customSelMsg requestUpdateSelMsg">
		       <li id="aa">部门a</li><li id="bb">部门b</li><li id="cc">部门c</li></ul>
		    </div>
        </div>

        <p><a href="javascript:void(0);" id="quickCreateLink">快速创建新供应商>></a></p>
        <!-- 没有供应商的情况显示 -->

        <p>请按以下要求更新报价：</p>
        <textarea class="requestUpdateTxt" rows="6" placeholder="请在此输入更新报价的要求"></textarea>
        <div class="requestUpdateLink">
        	<a href="javascript:void(0)">发送</a>
        	<a href="javascript:void(0)" class="requestUpdateCancle" data-dismiss="modal">取消</a>
        </div>
        <p>*发送更新要求后，我们会发送一封邮件通知该供应商登录系统（如该供应商未注册，会提示其注册账号登录），然后该供应商即可更新此份报价</p>
      </div>
    </div>
  </div>
</div>
<!-- 要求更新 -->

<!-- 快速创建供应商 -->
<div class="modal fade" id="quickCreate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog requestUpdateDia">
    <div class="modal-content">
      <div class="modal-body">
        <div class="quickCreateBox">
	        <p>供应商名称</p>
	        <input id="quickCreateName" type="text">
	        <p>联系人</p>
	        <input id="quickCreateUser" type="text">
	        <p>邮箱</p>
	        <input id="quickCreateEmail" type="email">
        </div>
        <div class="quickCreateLinkBox">
        	<a href="javascript:void(0)" id="quickCreateOk">确认</a>
        	<a href="javascript:void(0)" class="requestUpdateCancle" data-dismiss="modal">取消</a>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- 快速创建供应商 -->


<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/json2.js"></script>
<script src="js/mmGrid.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">
// 快速新建供应商按钮
$(document).on("click","#quickCreateLink",function(){
    $('#requestUpdate').modal('hide');
    $('#quickCreate').modal('show');
})
// 快速新建供应商按钮

// 快速新建供应商确认按钮
$(document).on("click","#quickCreateOk",function(){
    $('#requestUpdate').modal('show');
    $('#quickCreate').modal('hide');


})
// 快速新建供应商确认按钮
</script>
</body>
</html>
