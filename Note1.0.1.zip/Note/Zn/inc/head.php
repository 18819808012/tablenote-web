<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="format-detection" content="telephone=no, email=no"/>
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>demo</title>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/css.css" rel="stylesheet">
<!--[if lt IE 9]>
      <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
<div class="container-fluid">
<!-- 左侧导航栏  共有部分-->
<div class="AsideNav">
	<a href="#" class="userIcon">
		<img src="img/userIcon.gif" class="img-circle">
		<p class="userName">黄先生</p>
	</a>
	<form>
		<div class="RelativeBox navSearchBox">
			<input type="text" placeholder="搜索" class="navSearch">
			<a class="navSearchIcon" href="javascript:void(0)"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></a>
		</div>
	</form>
	<nav class="navLinkBox">
		<ul class="list-unstyled">
			<li>
				<a class="navMoreLink" href="javascript:void(0)"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>产品中心<span class="glyphicon navMoreIcon glyphicon-menu-down" aria-hidden="true"></span></a>
				<ul class="navMoreMsg">
					<li><a href="Inbox.php">收件箱</a></li>
					<li><a href="outbox.php">发件箱</a></li>
					<li><a href="garbage.php">垃圾箱</a></li>
					<li><a href="drafts.php">草稿箱</a></li>
				</ul>
			</li>
			<li>
			    <a class="navMoreLink" href="javascript:void(0)"><span class="glyphicon glyphicon-th-large" aria-hidden="true"></span>管理<span class="glyphicon navMoreIcon glyphicon-menu-down" aria-hidden="true"></span></a>
        <ul class="navMoreMsg">
					<li><a href="manage_addNewProduct.php">新建产品</a></li>
					<li><a href="manage_massUpload.php">批量添加</a></li>
					<li><a href="manage_contacts.php">联系人管理</a></li>
					<li><a href="manage_categories.php">分类管理</a></li>
					<li><a href="manage_templates.php">模板管理</a></li>
				</ul>
			</li>
			<li><a href="contacts.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>供应商</a></li>
      <li><a href="setting.php"><span class="glyphicon glyphicon-cog" aria-hidden="true"></span>设置</a></li>
			<li><a href="message.php"><span class="glyphicon glyphicon-comment" aria-hidden="true"></span>消息</a></li>
			<li><a href="#"><span class="glyphicon glyphicon-gift" aria-hidden="true"></span>样品管理</a></li>
		</ul>
	</nav>
</div>
<!-- 左侧导航栏  共有部分-->