<?php
include_once 'inc/head.php';
?>


<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">供应商 <a class="changeHtml" href="../contacts.php">切换</a></span>

    <div class="conHeadLinkBox">
  		<a class="conHeadLink" href="#">新建公司</a>
      <a class="conHeadLink" href="#">添加联系人</a>
      <a class="conHeadLink" href="#">批量导入</a>
      <a class="conHeadLink" href="#">保存</a>
    </div>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 主要内容盒子 -->
<div class="row conBox">

<section class="row ClearLR contactsBox">
  <div class="w24bf MinH">
    <header class="conHeadTip">供应商列表</header>
    <ul class="contactList niceScroll MinH_h">
      <li>
        <a href="#">
          <p class="contactListH">公司名称</p>
          <p>联系人</p>
          <p>电话</p>
          <p>手机</p>
          <p>邮箱</p>
        </a>
      </li>
      <li>
        <a href="#">
          <p class="contactListH">张小姐有限公司</p>
          <p>张小姐</p>
          <p>8620-83208320</p>
          <p>8620-123456789</p>
          <p>123456789@qq.com</p>
        </a>
      </li>
      <li>
        <a href="#">
          <p class="contactListH">张小姐有限公司</p>
          <p>张小姐</p>
          <p>8620-83208320</p>
          <p>8620-123456789</p>
          <p>123456789@qq.com</p>
        </a>
      </li>
      <li>
        <a href="#">
          <p class="contactListH">张小姐有限公司</p>
          <p>张小姐</p>
          <p>8620-83208320</p>
          <p>8620-123456789</p>
          <p>123456789@qq.com</p>
        </a>
      </li>
      <li>
        <a href="#">
          <p class="contactListH">张小姐有限公司</p>
          <p>张小姐</p>
          <p>8620-83208320</p>
          <p>8620-123456789</p>
          <p>123456789@qq.com</p>
        </a>
      </li>
      <li>
        <a href="#">
          <p class="contactListH">张小姐有限公司</p>
          <p>张小姐</p>
          <p>8620-83208320</p>
          <p>8620-123456789</p>
          <p>123456789@qq.com</p>
        </a>
      </li>
      <li>
        <a href="#">
          <p class="contactListH">张小姐有限公司</p>
          <p>张小姐</p>
          <p>8620-83208320</p>
          <p>8620-123456789</p>
          <p>123456789@qq.com</p>
        </a>
      </li>
    </ul>
  </div>

  <div class="w24bf MinH">
    <header class="conHeadTip">公司信息</header>
    <div class="contactsPeopleMsg">
      <a class="contactsCusAdd mb15" href="javascript:void(0)">删除此公司</a>
      <form>
<!--         <div class="RelativeBox font0 inputBox">
          <span class="inputName">部门</span>
          <div class="customSelect contactSelect">
             <a class="customSelLink contactSelLink" href="javascript:void(0)"><span class="customSelTxt">日用品</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
             <ul class="list-unstyled customSelMsg contactSelUl" style="display: none;">
               <li>部门1</li>
               <li>部门2</li>
               <li>部门3</li>
               <li>部门4</li>
               <li>部门5</li>
               <li>部门6</li>
               <li>部门1</li>
               <li>部门1</li>
               <li>部门1</li>
               <li>部门1</li>
               <li>部门1</li>
             </ul>
          </div>
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">分类</span>
          <div class="customSelect contactSelect">
             <a class="customSelLink contactSelLink" href="javascript:void(0)"><span class="customSelTxt">未分类</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
             <ul class="list-unstyled customSelMsg contactSelUl" style="display: none;">
               <li>部门1</li>
               <li>部门2</li>
               <li>部门3</li>
               <li>部门4</li>
               <li>部门5</li>
               <li>部门6</li>
               <li>部门1</li>
               <li>部门1</li>
               <li>部门1</li>
               <li>部门1</li>
               <li>部门1</li>
             </ul>
          </div>
        </div> -->
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">供应商编号</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">供应商类型</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">公司名</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">公司地址</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">网址</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">付款方式</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox">
          <span class="inputName">经营产品</span>
          <input type="text" class="inputVal">
        </div>
<!--         <div class="RelativeBox font0 inputBox">
          <span class="inputName">银行账户</span>
          <input type="text" class="inputVal">
        </div> -->
      </form>
    </div>
  </div>

  <div class="w24bf MinH">
    <header class="conHeadTip">联系人信息</header>

    <div class="contactsPeopleMsg contactsPeopleMsg02">
      <a class="contactsCusRemove" href="javascript:void(0)"><span class="glyphicon glyphicon-remove"></span></a>
      <form>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName inputNameA">联系人</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName inputNameA">职位</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName inputNameA">手机</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName inputNameA">邮箱</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName inputNameA">电话</span>
          <input type="text" class="inputVal">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName inputNameA">传真</span>
          <input type="text" class="inputVal">
        </div>
      </form>
    </div>

    <div class="contactsPeopleMsg contactsPeopleMsg02">
      <a class="contactsCusRemove" href="javascript:void(0)"><span class="glyphicon glyphicon-remove"></span></a>
      <form>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName">联系人</span>
          <input type="text" class="inputVal inputNameA">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName">职位</span>
          <input type="text" class="inputVal inputNameA">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName">手机</span>
          <input type="text" class="inputVal inputNameA">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName">邮箱</span>
          <input type="text" class="inputVal inputNameA">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName">电话</span>
          <input type="text" class="inputVal inputNameA">
        </div>
        <div class="RelativeBox font0 inputBox inputBoxA">
          <span class="inputName">传真</span>
          <input type="text" class="inputVal inputNameA">
        </div>
      </form>
    </div>

  </div>

<!--   <div class="w24bf MinH">
    <header class="conHeadTip">供应商评论</header>
    <div class="concactsAssessWrap niceScroll">
      <ul class="list-unstyled">
      <li>
        <a class="navMoreLink concactsNavMore" href="javascript:void(0)">交货情况<span class="glyphicon navMoreIcon concactsNavMoreI glyphicon-menu-down" aria-hidden="true"></span></a>
        <div class="navMoreMsg">
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
        </div>
      </li>
      <li>
        <a class="navMoreLink concactsNavMore" href="javascript:void(0)">沟通情况<span class="glyphicon navMoreIcon concactsNavMoreI glyphicon-menu-down" aria-hidden="true"></span></a>
        <div class="navMoreMsg">
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
        </div>
      </li>
      <li>
        <a class="navMoreLink concactsNavMore" href="javascript:void(0)">质量水平<span class="glyphicon navMoreIcon concactsNavMoreI glyphicon-menu-down" aria-hidden="true"></span></a>
        <div class="navMoreMsg">
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
        </div>
      </li>
      <li>
        <a class="navMoreLink concactsNavMore" href="javascript:void(0)">打样情况<span class="glyphicon navMoreIcon concactsNavMoreI glyphicon-menu-down" aria-hidden="true"></span></a>
        <div class="navMoreMsg">
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
        </div>
      </li>
      <li>
        <a class="navMoreLink concactsNavMore" href="javascript:void(0)">单证质量<span class="glyphicon navMoreIcon concactsNavMoreI glyphicon-menu-down" aria-hidden="true"></span></a>
        <div class="navMoreMsg">
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
          <div class="concactsAssessMsg">
            <p class="RelativeBox concactsAssessP">评估人员 <span>2016-07-02</span></p>
            <textarea class="conTxtArea concactsAssessTextA" rows="6" value="内容内容内容内容内容内容内容内容内容内容"></textarea>
          </div>
        </div>
      </li>
    </ul>
    </div>
  </div> -->

</section>

</div>
<!-- 主要内容盒子 -->

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">
$(document).on("click",".contactsCusAdd",function(){
    var I = $(this);
    var Itar = I.parent();
    Itar.remove();
})
</script>
</body>
</html>