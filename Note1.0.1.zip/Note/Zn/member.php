<?php
include_once 'inc/head.php';
?>


<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">添加产品 <a class="changeHtml" href="../manage_addNewProduct.php">切换</a></span>
	</div>
</header>
<!-- 头部固定栏 -->

<div class="row conBox">
<section class="row ClearLR MinH">
<table class="table memberManage">
        <thead>
          <tr>
            <th class="membercol1">头像</th>
            <th class="membercol2">用户名</th>
            <th>负责的分类</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="membercol1"><a href="userMsg.php"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2"><a href="userMsg.php">布兰妮</a></td>
            <td>陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
          <tr>
            <td class="membercol1"><a href="#"><img src="img/userIcon.gif" class="img-circle memberIcon"></a></td>
            <td class="membercol2">布兰妮</td>
            <td>陶瓷餐具，马克杯</td>
          </tr>
        </tbody>
      </table>
</section>
</div>

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
</body>
</html>