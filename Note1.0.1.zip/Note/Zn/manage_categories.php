<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">分类管理 <a class="changeHtml" href="../manage_categories.php">切换</a></span>
		<button class="conSave">保存</button>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 主要内容盒子 -->
<div class="row conBox">

<section class="row ClearLR contactsBox">
  <div class="w24bf MinH contactsBox1">
  	<p>请从右侧添加产品部门及分类。</p>
  	<p>当你邀请员工加入公司之后，可设置该员工负责的分类。</p>
  	<p>员工/供应商提交产品只归到部门的情况下，则改部门下所有分类的负责人都可以看到，此时所有人都有编辑权限。</p>
  	<p>只有当某个负责人将产品归到自己的部门时，其他分类负责人才不能看到改产品的信息。</p>
  </div>

  <div class="w24bf MinH contactsBox2">
    <div class="contactsBox2H">
		<header>部门列表</header>
		<a class="contactsCusAdd" data-toggle="modal" data-target=".categoriesMa" href="javascript:void(0)">添加部门</a>
  	</div>
  	<div class="contactsMsg niceScroll">
        <ul id="cateUla" class="cateUl">
        	<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><span class="cateLinkTxt">部门</span></li>
        	<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><span class="cateLinkTxt">日用品</span></li>
        	<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><span class="cateLinkTxt">部门</span></li>
        </ul>
  	</div>
  </div>

  <div class="w24bf MinH contactsBox2">
    <div class="contactsBox2H">
		<header>分类列表</header>
		<a class="contactsCusAdd" data-toggle="modal" data-target=".categoriesMb" href="javascript:void(0)">添加分类</a>
  	</div>
  	<div class="contactsMsg niceScroll">
        <ul id="cateUlb" class="cateUl">
        	<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><span class="cateLinkTxt">杯子</span></li>
        	<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><span class="cateLinkTxt">餐具</span></li>
        	<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><span class="cateLinkTxt">炊具</span></li>
        </ul>
  	</div>
  </div>

</section>
</div>
<!-- 主要内容盒子 -->
</div><!-- container-fluid -->

<!-- 新增部门 添加自定义字段 -->
<div class="modal fade categoriesMa" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
        <p class="addModalTxt">输入自定义字段名字</p>
        <input id="categoriesMa" type="text" class="addModalIn"></input>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">取消</button>
        <button id="categoriesMLinka" type="button" class="btn btn-primary">确认</button>
      </div>
    </div>
  </div>
</div>
<!-- 新增部门 添加自定义字段 -->

<!-- 新增分类 添加自定义字段 -->
<div class="modal fade categoriesMb" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
        <p class="addModalTxt">输入自定义字段名字</p>
        <input id="categoriesMb" type="text" class="addModalIn"></input>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">取消</button>
        <button id="categoriesMLinkb" type="button" class="btn btn-primary">确认</button>
      </div>
    </div>
  </div>
</div>
<!-- 新增分类 添加自定义字段 -->

<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">
// 新增部门 添加自定义字段
$(document).on("click","#categoriesMLinka",function(){
    var Iv = $.trim($("#categoriesMa").val());
    var tar = $("#cateUla");
    var tarMsg = '<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><span class="cateLinkTxt">'+ Iv +'</span></li>';
    if (Iv.length=="") {
        show_msg("信息未完善！",3000);
    }else{
        tar.append(tarMsg);
        $('.categoriesMa').modal('hide');
    }
})
// 新增部门 添加自定义字段

// 新增部门 添加自定义字段
$(document).on("click","#categoriesMLinkb",function(){
    var Iv = $.trim($("#categoriesMb").val());
    var tar = $("#cateUlb");
    var tarMsg = '<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><span class="cateLinkTxt">'+ Iv +'</span></li>';
    if (Iv.length=="") {
        show_msg("信息未完善！",3000);
    }else{
        tar.append(tarMsg);
        $('.categoriesMb').modal('hide');
    }
})
// 新增部门 添加自定义字段
</script>
</body>
</html>