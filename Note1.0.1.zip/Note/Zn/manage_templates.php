<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">模板管理 <a class="changeHtml" href="../manage_templates.php">切换</a></span>

    <div class="conHeadLinkBox">
    	<a class="conHeadLink" href="javascript:void(0)">保存</a>
    	<a class="conHeadLink" href="javascript:void(0)">编辑</a>
    	<a class="conHeadLink" href="javascript:void(0)">新建</a>
    	<a class="conHeadLink" href="javascript:void(0)">取消</a>
    </div>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 主要内容盒子 -->
<div class="row conBox">

<section class="row ClearLR font0">
    <div class="w19bf MinH contactsBox2">
        <header class="tempH">模板列表</header>
        <div id="tempBoxWrap" class="tempBoxWrap">
            <ul class="tempBoxUl">
	        	<li>
	        		<a href="#">
	        			<header>通用模板</header>
	        			<p>请提供产品的详细数据，如果有产品相关的测试证书，也请添加到对应的产品中。如果产品有包装，请提供至少一张产品图和包装图。</p>
	        		</a>
	        	</li>
	        	<li>
	        		<a href="#">
	        			<header>日用品报价模板</header>
	        			<p>请提供产品的详细数据，如果有产品相关的测试证书，也请添加到对应的产品中。如果产品有包装，请提供至少一张产品图和包装图。</p>
	        		</a>
	        	</li>
	        	<li>
	        		<a href="#">
	        			<header>日用品报价模板</header>
	        			<p>请提供产品的详细数据，如果有产品相关的测试证书，也请添加到对应的产品中。如果产品有包装，请提供至少一张产品图和包装图。</p>
	        		</a>
	        	</li>
	        	<li>
	        		<a href="#">
	        			<header>日用品报价模板</header>
	        			<p>请提供产品的详细数据，如果有产品相关的测试证书，也请添加到对应的产品中。如果产品有包装，请提供至少一张产品图和包装图。</p>
	        		</a>
	        	</li>
	        	<li>
	        		<a href="#">
	        			<header>日用品报价模板</header>
	        			<p>请提供产品的详细数据，如果有产品相关的测试证书，也请添加到对应的产品中。如果产品有包装，请提供至少一张产品图和包装图。</p>
	        		</a>
	        	</li>
	        	<li>
	        		<a href="#">
	        			<header>日用品报价模板</header>
	        			<p>请提供产品的详细数据，如果有产品相关的测试证书，也请添加到对应的产品中。如果产品有包装，请提供至少一张产品图和包装图。</p>
	        		</a>
	        	</li>
	        	<li>
	        		<a href="#">
	        			<header>日用品报价模板</header>
	        			<p>请提供产品的详细数据，如果有产品相关的测试证书，也请添加到对应的产品中。如果产品有包装，请提供至少一张产品图和包装图。</p>
	        		</a>
	        	</li>
	        	<li>
	        		<a href="#">
	        			<header>日用品报价模板</header>
	        			<p>请提供产品的详细数据，如果有产品相关的测试证书，也请添加到对应的产品中。如果产品有包装，请提供至少一张产品图和包装图。</p>
	        		</a>
	        	</li>
	        	<li>
	        		<a href="#">
	        			<header>日用品报价模板</header>
	        			<p>请提供产品的详细数据，如果有产品相关的测试证书，也请添加到对应的产品中。如果产品有包装，请提供至少一张产品图和包装图。</p>
	        		</a>
	        	</li>
	        	<li>
	        		<a href="#">
	        			<header>日用品报价模板</header>
	        			<p>请提供产品的详细数据，如果有产品相关的测试证书，也请添加到对应的产品中。如果产品有包装，请提供至少一张产品图和包装图。</p>
	        		</a>
	        	</li>
	        	<li>
	        		<a href="#">
	        			<header>日用品报价模板</header>
	        			<p>请提供产品的详细数据，如果有产品相关的测试证书，也请添加到对应的产品中。如果产品有包装，请提供至少一张产品图和包装图。</p>
	        		</a>
	        	</li>
	        	<li>
	        		<a href="#">
	        			<header>日用品报价模板</header>
	        			<p>请提供产品的详细数据，如果有产品相关的测试证书，也请添加到对应的产品中。如果产品有包装，请提供至少一张产品图和包装图。</p>
	        		</a>
	        	</li>
        	</ul>
        </div>
    </div>

    <div class="w19bf  MinH contactsBox2">

      <div class="contactsBox2H">
      <div class="selectMBox">
        <input type="text" placeholder="请在此输入模板名称">
        <textarea rows="5" placeholder="请按照要求提供产品报价的详细内容。如果是容器类的产品，在尺寸一栏同时提供产品容量"></textarea>
      </div>
      <header>选择使用此模板的部门</header>
      <a class="contactsCusAdd" data-toggle="modal" data-target=".addModald" href="javascript:void(0);">添加新部门</a>
      </div>
      <div id="contactsMsgd" class="contactsMsgM">
          <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">部门1</span></a>
          <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">部门1</span></a>
          <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">部门1</span></a>
          <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">部门1</span></a>
          <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">部门1</span></a>
      </div>
    </div>

    <div class="w19bf  MinH contactsBox2">
    <div class="contactsBox2H">
		<header>产品详情</header>
		<a class="contactsCusAdd" data-toggle="modal" data-target=".addModala" href="javascript:void(0);">添加自定义字段</a>
  	</div>
  	<div id="contactsMsga" class="contactsMsg">
        <a class="customCheck" href="javascript:void(0);"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">货号</span></a>
        <a class="customCheck active" href="javascript:void(0);"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">品名</span></a>
        <a class="customCheck RelativeBox" href="javascript:void(0);"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">价格</span>
        <select class="moneyClass">
          <option>$</option>
          <option>￥</option>
          <option>￡</option>
          <option>€</option>
        </select>
        </a>
        <a class="customCheck" href="javascript:void(0);"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">单位</span></a>
        <a class="customCheck" href="javascript:void(0);"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">起订量</span></a>
        <a class="customCheck" href="javascript:void(0);"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">包装</span></a>
        <a class="customCheck" href="javascript:void(0);"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">条形码</span></a>
  	</div>
  </div>

  <div class="w19bf  MinH contactsBox2">
    <div class="contactsBox2H">
		<header>规格详情</header>
		<a class="contactsCusAdd" data-toggle="modal" data-target=".addModalb" href="javascript:void(0);">添加自定义字段</a>
  	</div>
  	<div id="contactsMsgb" class="contactsMsg">
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">尺寸</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">材料</span></a>
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">重量</span></a>
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">质量等级</span></a>
  	</div>
  </div>

  <div class="w19bf  MinH contactsBox2">
    <div class="contactsBox2H">
		<header>物流详情</header>
		<a class="contactsCusAdd" data-toggle="modal" data-target=".addModalc" href="javascript:void(0);">添加自定义字段</a>
  	</div>
  	<div id="contactsMsgc" class="contactsMsg">
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">交货情况</span></a>
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">沟通情况</span></a>
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">质量水平</span></a>
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">打样情况</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">单证质量</span></a>
  	</div>
  </div>

</section>

</div>
<!-- 主要内容盒子 -->
</div><!-- container-fluid -->


<!-- 产品详情 添加自定义字段 -->
<div class="modal fade addModala" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
        <p class="addModalTxt">输入自定义字段名字</p>
        <input id="addModalIna" type="text" class="addModalIn"></input>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button id="addModalSa" type="button" class="btn btn-primary">Sure</button>
      </div>
    </div>
  </div>
</div>
<!-- 产品详情 添加自定义字段 -->

<!-- 规格详情 添加自定义字段 -->
<div class="modal fade addModalb" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
        <p class="addModalTxt">输入自定义字段名字</p>
        <input id="addModalInb" type="text" class="addModalIn"></input>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button id="addModalSb" type="button" class="btn btn-primary">Sure</button>
      </div>
    </div>
  </div>
</div>
<!-- 规格详情 添加自定义字段 -->

<!-- 物流详情 添加自定义字段 -->
<div class="modal fade addModalc" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
        <p class="addModalTxt">输入自定义字段名字</p>
        <input id="addModalInc" type="text" class="addModalIn"></input>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button id="addModalSc" type="button" class="btn btn-primary">Sure</button>
      </div>
    </div>
  </div>
</div>
<!-- 物流详情 添加自定义字段 -->


<!-- 选择部门 -->
<div class="modal fade addModald" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
        <p class="addModalTxt">输入自定义字段名字</p>
        <input id="addModalInd" type="text" class="addModalIn"></input>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button id="addModalSd" type="button" class="btn btn-primary">Sure</button>
      </div>
    </div>
  </div>
</div>
<!-- 选择部门 -->

<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">
$(function(){

// 产品详情 添加自定义字段
$(document).on("click","#addModalSa",function(){
    var Iv = $.trim($("#addModalIna").val());
    var tar = $("#contactsMsga");
    var tarMsg = '<a class="customCheck active" href="javascript:void(0);"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">'+ Iv +'</span></a>';
    if (Iv.length=="") {
        show_msg("信息未完善！",3000);
    }else{
        tar.append(tarMsg);
        $('.addModala').modal('hide');
    }
})
// 产品详情 添加自定义字段

// 规格详情 添加自定义字段
$(document).on("click","#addModalSb",function(){
    var Iv = $.trim($("#addModalInb").val());
    var tar = $("#contactsMsgb");
    var tarMsg = '<a class="customCheck active" href="javascript:void(0);"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">'+ Iv +'</span></a>';
    if (Iv.length=="") {
        show_msg("信息未完善！",3000);
    }else{
        tar.append(tarMsg);
        $('.addModalb').modal('hide');
    }
})
// 规格详情 添加自定义字段

// 物流详情 添加自定义字段
$(document).on("click","#addModalSc",function(){
    var Iv = $.trim($("#addModalInc").val());
    var tar = $("#contactsMsgc");
    var tarMsg = '<a class="customCheck active" href="javascript:void(0);"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">'+ Iv +'</span></a>';
    if (Iv.length=="") {
        show_msg("信息未完善！",3000);
    }else{
        tar.append(tarMsg);
        $('.addModalc').modal('hide');
    }
})
// 物流详情 添加自定义字段

// 物流详情 添加自定义字段
$(document).on("click","#addModalSd",function(){
    var Iv = $.trim($("#addModalInd").val());
    var tar = $("#contactsMsgd");
    var tarMsg = '<a class="customCheck active" href="javascript:void(0);"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">'+ Iv +'</span></a>';
    if (Iv.length=="") {
        show_msg("信息未完善！",3000);
    }else{
        tar.append(tarMsg);
        $('.addModald').modal('hide');
    }
})
// 物流详情 添加自定义字段

});
</script>
</body>
</html>