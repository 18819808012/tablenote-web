<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
    <span class="headMsgTit">逐个添加报价 <a class="changeHtml" href="../addDetail.php">切换</a></span>

    <div class="conHeadLinkBox">
      <a class="conHeadLink" href="javascript:void(0)">批量导入</a>
  		<a class="conHeadLink" href="javascript:void(0)">添加</a>
  		<a class="conHeadLink" href="drafts.php">查看</a>
  		<a id="addDetailSava" class="conHeadLink" href="javascript:void(0)">保存</a>
  		<a class="conHeadLink" href="javascript:void(0)">取消</a>
    </div>

	</div>
</header>
<!-- 头部固定栏 -->

<!-- 主要内容盒子 -->
<div id="conBoxA" class="row conBox">

<section class="row ClearLR font0">
  <div class="w24bf  MinH">
      <header class="tempH">Quotation information</header>
      <!-- <p class="changePrice"><a id="changePrice" href="javascript:void(0)"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span><span class="changePriceTxt">切换到输入模式</span></a></p> -->
      <div id="PriceHide2" class="">
      	<form>
      	    <div class="RelativeBox PriceBox">
	      		<span class="inputName">Created on</span>
	      		<p>2016-07-02</p>
	      	</div>
	      	<div class="RelativeBox PriceBox">
	      		<span class="inputName">Saved on</span>
	      		<p>2016-07-03</p>
	      	</div>
	      	<div class="RelativeBox PriceBox">
	      		<span class="inputName">Created by</span>
	      		<p>by Huang</p>
	      	</div>
	      	<div class="RelativeBox PriceBox">
	      		<span class="inputName">Status</span>
	      		<p>Not reviewed yet</p>
	      	</div>
	      	<div class="RelativeBox">
	      		<textarea class="PriceTxt" rows="5"></textarea>
	      	</div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Supplier</span>
	          <div class="customSelect contactSelect">
	             <a class="customSelLink contactSelLink" href="javascript:void(0)"><span class="customSelTxt">Supplier</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
	             <ul class="list-unstyled customSelMsg contactSelUl" style="display: none;">
	               <li>供应商2</li>
	               <li>供应商3</li>
	               <li>供应商4</li>
	             </ul>
	          </div>
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Supplier</span>
	          <input type="text" class="inputVal" value="101010101">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Contact</span>
	          <input type="text" class="inputVal" value="供应商类型">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Reference</span>
	          <input type="text" class="inputVal" value="公司名">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Subject</span>
	          <input type="text" class="inputVal" value="公司地址">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Quote term</span>
	          <input type="text" class="inputVal" value="www.123.com">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Payment</span>
	          <input type="text" class="inputVal" value="付款方式">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Loading port</span>
	          <input type="text" class="inputVal" value="经营产品">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Expiry date</span>
	          <input type="text" class="inputVal" value="银行账户">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Delivery time</span>
	          <input type="text" class="inputVal" value="银行账户">
	        </div>
	        <div class="RelativeBox font0 inputBox PriceBox">
	          <span class="inputName">Attavhment</span>
	          <ul>
      			<li class="detailZipInn"><a href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>工厂iso2001证书</li>
      			<li class="detailZipInn"><a href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>工厂营业执照</li>
      		</ul>
	        </div>
	      </form>
      </div><!-- PriceHide -->
  </div><!-- w24bf -->

  <div class="w48bf  MinH RelativeBox">
    <header class="tempH">Product information</header>
    <div id="ProductDetailHide" class="addDetailShow">
      <div class="ProductDetailEditImg">
        <div class="ProductDetailImgW">
          <div id="ProductDetailImgB" class="ProductDetailImgB"><img class="img-responsive" src="img/1.png"><a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a></div>
          <ul class="ProductDetailImgInn">../
            <li><img class="img-responsive" src="img/1.png"><a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a></li>
            <li><img class="img-responsive" src="img/1.png"><a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a></li>
            <li><img class="img-responsive" src="img/1.png"><a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a></li>
            <li><img class="img-responsive" src="img/1.png"><a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a></li>
          </ul>
        </div>
        <div class="codeBox">
            <p>扫描条形码</p>
            <img src="img/2.png">
          </div>
          <div class="codeBox">
            <p>二维码</p>
            <img src="img/3.png">
          </div>
          <div class="detailZipBox">
            <p>附件</p>
            <div class="detailZipInn"><a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a> HG003 Test Reports</div>
            <div class="detailZipInn"><a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a> HG003 Test Reports</div>
          </div>
      </div>
      <div class="ProductDetailEditTxt">
        <div class="ProductDetailEditTxtInn">
        <form>
          <div class="RelativeBox ProductDetailEditBox">
            <span>部门</span>
            <div class="customSelect ProductEditSel">
               <a class="customSelLink ProductEditSelLink" href="javascript:void(0)"><span class="customSelTxt">日用品</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
               <ul class="list-unstyled customSelMsg ProductEditSelMsg">
                 <li>部门1</li>
                 <li>部门2</li>
               </ul>
            </div>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>分类</span>
            <div class="customSelect ProductEditSel">
               <a class="customSelLink ProductEditSelLink" href="javascript:void(0)"><span class="customSelTxt">未分类</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
               <ul class="list-unstyled customSelMsg ProductEditSelMsg">
                 <li>部门1</li>
                 <li>部门2</li>
               </ul>
            </div>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>采购员</span>
            <div class="customSelect ProductEditSel">
               <a class="customSelLink ProductEditSelLink" href="javascript:void(0)"><span class="customSelTxt">未选择</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
               <ul class="list-unstyled customSelMsg ProductEditSelMsg">
                 <li>部门1</li>
                 <li>部门2</li>
               </ul>
            </div>
          </div>

          <h4>产品详情</h4>

          <div class="RelativeBox ProductDetailEditBox">
            <span>货号</span>
            <input type="text" value="123"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>品名</span>
            <input type="text" value="123"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>价格</span>
            <input type="text" value="123"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>起订量</span>
            <input type="text" value="123"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>包装</span>
            <input type="text" value="123"></input>
          </div>

          <h4>规格详情</h4>

          <div class="RelativeBox ProductDetailEditBox">
            <span>材料</span>
            <input type="text" value="123"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>尺寸</span>
            <input type="text" value="123"></input>
          </div>

          <h4>物流详情</h4>

          <div class="RelativeBox ProductDetailEditBox">
            <span>外箱装量</span>
            <input type="text" value="123"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>外箱细节</span>
            <input type="text" value="123"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>外箱重量</span>
            <input type="text" value="123"></input>
          </div>

          <div class="RelativeBox ProductDetailEditBox">
            <span>装柜情况</span>
            <input type="text"></input>
            <input type="text"></input>
            <input type="text"></input>
          </div>

        </form>
        </div><!-- ProductDetailEditTxtInn -->
      </div>
    </div>
    <p class="ProductNum">1/12</p>
  </div>

  <div class="w24bf  MinH">
      <header class="tempH">导航栏</header>
      <div id="detailNavWrap" class="detailNavWrap">
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      	<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="img/1.png"></a>
      </div>
  </div>

</section>

</div>
<!-- 主要内容盒子 -->

<!-- 展开列表内容盒子 隐藏-->
<div id="conBoxB" class="row conBox">
<div class="MinH conBg">
<div id="contableWrapAH" class="contableWrapA niceScroll">
   <table class="table table-bordered contableA">
      <tbody>
        <tr>
          <td>编辑着</td>
          <td>编辑日期</td>
          <td>状态</td>
          <td>标题</td>
          <td>报价序号</td>
          <td>供应商</td>
          <td>联系人</td>
          <td>价格条款</td>
          <td>付款方式</td>
          <td>装运港</td>
          <td>交货时间</td>
          <td>有效期</td>
          <td>附言</td>
          <td>编辑着</td>
          <td>编辑日期</td>
          <td>状态</td>
          <td>标题</td>
          <td>报价序号</td>
          <td>供应商</td>
          <td>联系人</td>
          <td>价格条款</td>
          <td>付款方式</td>
          <td>装运港</td>
          <td>交货时间</td>
          <td>有效期</td>
          <td>附言</td>
        </tr>
        <tr>
          <td>陈先生</td>
          <td>8/9/2016</td>
          <td>通过</td>
          <td>2017春节沃尔玛</td>
          <td>Qtr45465465</td>
          <td>张小姐有限公司</td>
          <td>FRK</td>
          <td>预付30%定金</td>
          <td>广州</td>
          <td></td>
          <td>9/2/2016</td>
          <td>65456+465465</td>
          <td>9+54+946</td>
          <td></td>
          <td>陈先生</td>
          <td>8/9/2016</td>
          <td>通过</td>
          <td>2017春节沃尔玛</td>
          <td>Qtr45465465</td>
          <td>张小姐有限公司</td>
          <td>FRK</td>
          <td>预付30%定金</td>
          <td>广州</td>
          <td></td>
          <td>9/2/2016</td>
          <td>65456+465465</td>
        </tr>
      </tbody>
    </table>
</div>


<div id="contableWrapList" class="contableWrap">
  <table id="table2-1">
    <tr>
        <th rowspan="" colspan=""></th>
    </tr>
  </table>
</div>
</div>


</div>
<!-- 展开列表内容盒子 隐藏-->

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/json2.js"></script>
<script src="js/mmGrid.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">
// 编辑，保存，切换按钮
$(document).on("click","#DetailEdit",function(){
    var I = $(this);
    var PriceShow =$("#PriceShow");
    var PriceHide =$("#PriceHide");
    var ProductDetailWrap = $("#ProductDetailWrap");
    var ProductDetailHide = $("#ProductDetailHide");
    if (!!I.hasClass("active")) {
        I.removeClass("active");
        I.text("编辑");
        PriceShow.show();
        PriceHide.hide();
        ProductDetailHide.hide();
        ProductDetailWrap.show();
    }else{
        I.addClass("active");
        I.text("保存");
        PriceShow.hide();
        PriceHide.show();
        ProductDetailWrap.hide();
        ProductDetailHide.show();
    }
})
// 编辑，保存，切换按钮

// 删除图片
$(document).on("click",".DetailImgInn>a",function(){
    var I = $(this);
    var Ip = I.parent();
    Ip.remove();
})
// 删除图片

// 删除图片
$(document).on("click",".detailZipInn>a",function(){
    var I = $(this);
    var Ip = I.parent();
    Ip.remove();
})
// 删除图片

$(document).on("click","#addDetailSava",function(){
    var I = $(this);
    var tar = $("#ProductDetailImgB>img").attr("src");
    var tarBox = $("#detailNavWrap");
    var tarLink = '<a href="javascript:void(0);"><img class="img-responsive img-thumbnail" src="'+ tar +'"></a>';
    tarBox.prepend(tarLink);
    $(".ProductDetailEditBox input").val("");
    
})

</script>
</body>
</html>