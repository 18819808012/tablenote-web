<?php
include_once 'inc/head.php';
?>


<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">联系人设置 <a class="changeHtml" href="../userMsg.php">切换</a></span>
    <div class="conHeadLinkBox">
  		<a class="conHeadLink" href="javascript:void(0);">保存</a>
      <a class="conHeadLink" href="javascript:void(0);">取消</a>
    </div>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 主要内容盒子 -->
<div class="row conBox">

<section class="row ClearLR font0">
  <div class="w24bf MinH">
    <div class="userMsg">
      <div class="userIconBox mb10"><div class="userIconInn"><img src="img/userIcon.gif" class="img-circle"></div></div>
      <p class="S_userName">布兰妮</p>
      <p class="S_userEmail">Britney@b.com</p>
      <a class="userLink settingAdmin" id="settingAdmin" href="javascript:void(0);" name="admin">设置为管理员</a>
      <p>管理员权限：</p>
      <p>浏览所有部门的产品，创建分类及产品模板以及联系人模板，邀请及批准成员加入公司。</p>
      <a class="userLink removeNumbers" href="javascript:void(0);">移除此成员</a>
      <p>被移除成员，将不能再访问公司的所有数据，但与他相关的数据不会被删除。</p>
    </div>
  </div>

  <div class="w24bf MinH">
    <header class="conHeadTip">负责的产品</header>
    <div class="userMsgTool"><a id="userToolDelete" href="javascript:void(0);">全部移除</a></div>
    <ul class="userProduct" id="userProduct">
      <li>
        <a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a><span class="userProSpan">餐具</span>
      </li>
      <li>
        <a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a><span class="userProSpan">餐具</span>
      </li>
      <li>
        <a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a><span class="userProSpan">餐具</span>
      </li>
      <li>
        <a href="javascript:void(0);"><span class="glyphicon glyphicon-trash"></span></a><span class="userProSpan">餐具</span>
      </li>
    </ul>
  </div>


  <div class="w24bf MinH">
    <header class="conHeadTip">部门</header>
    <div class="userMsgTool"><a class="allChecked" href="javascript:void(0);">全选</a></div>
    <div class="userDepartment" id="userDepartment">
      <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">日用品</span></a>
      <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">家电</span></a>
      <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">家电</span></a>
      <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">家电</span></a>
    </div>
  </div>

  <div class="w24bf MinH" id="userSortW">
    <header class="conHeadTip">分类</header>
    <div class="userMsgTool"><a class="allChecked" href="javascript:void(0);">全选</a></div>
    <div class="userDepartment" id="userSort">
      <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">日用品</span></a>
      <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">家电</span></a>
      <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">家电</span></a>
      <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">家电</span></a>
    </div>
  </div>

</section>

</div>
<!-- 主要内容盒子 -->

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">
// 全部移除
$(document).on("click","#userToolDelete",function(){
    var I = $(this);
    var tar = $("#userProduct").children();
    tar.remove();
})
// 全选
$(document).on("click",".allChecked",function(){
    var I = $(this);
    var tar = I.parent(".userMsgTool").siblings().children(".customCheck");
    tar.addClass("active");
})
// 设置为管理员
$(document).on("click","#settingAdmin",function(){
    var I = $(this);
    var tar = $("#userSortW");
    var Iv = I.attr("name");
    var iconbox = $(".userIconInn");
    var icon = '<img class="img-circle userI" id="userI" src="img/loading.gif">';
    switch(Iv){
      case 'admin':
          I.attr("name","noadmin");
          I.text("移除此成员");
          iconbox.append(icon);
      break;
      case 'noadmin':
          I.attr("name","admin")
          I.text("设置为管理员");
          $("#userI").remove();
      break;
    }
})



</script>
</body>
</html>