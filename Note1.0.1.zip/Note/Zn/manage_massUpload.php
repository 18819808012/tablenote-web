<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">批量导入 <a class="changeHtml" href="../manage_massUpload.php">切换</a></span>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 主要内容盒子 -->
<div class="row conBox">
<section class="row ClearLR massUploadBox MinH">
   <ul>
   	<li>1,请把导入的excel工作表命名为Data</li>
   	<li>2,数据导入后请进行数据匹配</li>
   	<li>3,数据保存后请继续添加产品图片和文件</li>
   </ul>
   <p class="text-center"><a class="downloadMb" href="#">下载此模板的excel格式</a></p>
   <div class="text-center"><a class="importExcel" href="#">导入Excel</a></div>
</section>
</div>
<!-- 主要内容盒子 -->

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript"></script>
</body>
</html>