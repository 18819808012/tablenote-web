<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="format-detection" content="telephone=no, email=no"/>
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>demo</title>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/css.css" rel="stylesheet">
<link href="css/index.css" rel="stylesheet">
<!--[if lt IE 9]>
      <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
<div class="container-fluid">
<div class="row">

<p>Email地址验证 - TableNote.com</p>
 

<p>**** 用户，您好。感谢您选择TableNote.com。</p>
 
<p>您只需点击下面的链接即可激活您的帐号：</p>
<p>www.tablenote.com/member..........................</p>
<p>(如果上面不是链接形式，请将该地址手工粘贴到浏览器地址栏再访问)</p>
 
<p>如非您本人操作，请忽略次邮件。</p>
 
<p>**为什么要验证邮箱**</p>
<p>1，可以免费体验TableNote.com的服务；</p>
<p>2，加强账户安全，通过邮箱来找回您的密码；</p>
<p>3，获取来自TableNote.com的通知</p>
<p>-- 通知仅限TableNote提供的服务（比如供应商给您更新了一份报价），或者TableNote.com有重要的功能更新。我们不会给您发送大量的骚扰邮件。</p>
 
<p><a href="#">www.tablenote.com</a></p>

</div>

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
</body>
</html>




