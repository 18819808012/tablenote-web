<?php
include_once 'inc/head.php';
?>


<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">联系人设置 <a class="changeHtml" href="../manage_contacts.php">切换</a></span>

    <div class="conHeadLinkBox">
  		<a class="conHeadLink" href="javascript:void(0);">下载此模板的Excel文件</a>
      <a class="conHeadLink" href="javascript:void(0);">删除此模板</a>
      <a class="conHeadLink" href="javascript:void(0);">开始创建产品</a>
  		<a class="conHeadLink" href="javascript:void(0);">保存</a>
    </div>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 主要内容盒子 -->
<div class="row conBox">

<section class="row ClearLR contactsBox">
  <div class="w24bf  MinH contactsBox1">
  	<p>请从右侧选择供应商及联系人管理的字段，你也可以自定义添加你需要的字段。</p>
  	<p>和产品管理的权限一样，供应商对应的部门/分类，只有该部门/分类的相关人才可以看到该供应商的信息。</p>
  	<p>如果该供应商只归到部门，则该部门下所有分类的负责人都可以看到。</p>
  </div>

  <div class="w24bf  MinH contactsBox2">
    <div class="contactsBox2H">
		<header>公司信息</header>
		<a class="contactsCusAdd" data-toggle="modal" data-target=".addModala" href="javascript:void(0)">添加自定义字段</a>
  	</div>
  	<div id="contactsMsgaa" class="contactsMsg niceScroll">
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">部门</span></a>
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">分类</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">供应商编号</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">公司名</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">公司地址</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">网址</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">付款方式</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">部门</span></a>
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">分类</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">供应商编号</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">公司名</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">公司地址</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">网址</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">付款方式</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">部门</span></a>
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">分类</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">供应商编号</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">公司名</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">公司地址</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">网址</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">付款方式</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">部门</span></a>
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">分类</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">供应商编号</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">公司名</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">公司地址</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">网址</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">付款方式</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">公司地址</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">网址</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">付款方式</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">公司地址</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">网址</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">付款方式</span></a>
  	</div>
  </div>

  <div class="w24bf  MinH contactsBox2">
    <div class="contactsBox2H">
		<header>联系人信息</header>
		<a class="contactsCusAdd" data-toggle="modal" data-target=".addModalb" href="javascript:void(0)">添加自定义字段</a>
  	</div>
  	<div id="contactsMsgbb" class="contactsMsg niceScroll">
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">联系人</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">职位</span></a>
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">手机</span></a>
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">邮箱</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">电话</span></a>
  	</div>
  </div>

  <div class="w24bf  MinH contactsBox2">
    <div class="contactsBox2H">
		<header>供应商评估</header>
		<a class="contactsCusAdd" data-toggle="modal" data-target=".addModalc" href="javascript:void(0)">添加自定义字段</a>
  	</div>
  	<div id="contactsMsgcc" class="contactsMsg niceScroll">
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">交货情况</span></a>
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">沟通情况</span></a>
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">质量水平</span></a>
        <a class="customCheck active" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">打样情况</span></a>
        <a class="customCheck" href="javascript:void(0)"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">单证质量</span></a>
  	</div>
  </div>

</section>

</div>
<!-- 主要内容盒子 -->

</div><!-- container-fluid -->

<!-- 公司信息 添加自定义字段 -->
<div class="modal fade addModala" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
        <p class="addModalTxt">输入自定义字段名字</p>
        <input id="addModalIna" type="text" class="addModalIn"></input>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button id="addModalSa" type="button" class="btn btn-primary">Sure</button>
      </div>
    </div>
  </div>
</div>
<!-- 公司信息 添加自定义字段 -->

<!-- 联系人信息 添加自定义字段 -->
<div class="modal fade addModalb" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
        <p class="addModalTxt">输入自定义字段名字</p>
        <input id="addModalInb" type="text" class="addModalIn"></input>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button id="addModalSb" type="button" class="btn btn-primary">Sure</button>
      </div>
    </div>
  </div>
</div>
<!-- 联系人信息 添加自定义字段 -->

<!-- 供应商评估 添加自定义字段 -->
<div class="modal fade addModalc" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
        <p class="addModalTxt">输入自定义字段名字</p>
        <input id="addModalInc" type="text" class="addModalIn"></input>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button id="addModalSc" type="button" class="btn btn-primary">Sure</button>
      </div>
    </div>
  </div>
</div>
<!-- 供应商评估 添加自定义字段 -->

<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">
// 产品详情 添加自定义字段
$(document).on("click","#addModalSa",function(){
    var Iv = $.trim($("#addModalIna").val());
    var tar = $("#contactsMsgaa");
    var tarMsg = '<a class="customCheck active" href="javascript:void(0);"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">'+ Iv +'</span></a>';
    if (Iv.length=="") {
        show_msg("信息未完善！",3000);
    }else{
        tar.append(tarMsg);
        $('.addModala').modal('hide');
    }
})
// 产品详情 添加自定义字段

// 规格详情 添加自定义字段
$(document).on("click","#addModalSb",function(){
    var Iv = $.trim($("#addModalInb").val());
    var tar = $("#contactsMsgbb");
    var tarMsg = '<a class="customCheck active" href="javascript:void(0);"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">'+ Iv +'</span></a>';
    if (Iv.length=="") {
        show_msg("信息未完善！",3000);
    }else{
        tar.append(tarMsg);
        $('.addModalb').modal('hide');
    }
})
// 规格详情 添加自定义字段

// 物流详情 添加自定义字段
$(document).on("click","#addModalSc",function(){
    var Iv = $.trim($("#addModalInc").val());
    var tar = $("#contactsMsgcc");
    var tarMsg = '<a class="customCheck active" href="javascript:void(0);"><span class="glyphicon glyphicon-ok customCheckIcon" aria-hidden="true"></span><span class="customCheckLabel">'+ Iv +'</span></a>';
    if (Iv.length=="") {
        show_msg("信息未完善！",3000);
    }else{
        tar.append(tarMsg);
        $('.addModalc').modal('hide');
    }
})
// 物流详情 添加自定义字段
</script>
</body>
</html>