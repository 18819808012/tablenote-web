<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">批量导入 <a class="changeHtml" href="Zn/manage_massUpload.php">切换</a></span>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 主要内容盒子 -->
<div class="row conBox">
<section class="row ClearLR massUploadBox MinH">
   <ul>
   	<li>1,Please rename the workbook as DATA;</li>
   	<li>2,Please select the filed of your uploaded data to match the filed of the system</li>
   	<li>3,Please add pictures to product after the data is uploaded</li>
   </ul>
   <p class="text-center"><a class="downloadMb" href="#">Download template of the product data sheet</a></p>
   <div class="text-center"><a class="importExcel" href="#">导入Excel</a></div>
</section>
</div>
<!-- 主要内容盒子 -->

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript"></script>
</body>
</html>