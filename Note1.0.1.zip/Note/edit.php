<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">发件箱 <a class="changeHtml" href="Zn/edit.php">切换</a></span>
        <div class="conHeadLinkBox">
          <div class="conHeadLink inboxOut editAdd">
          <div class="RelativeBox">
            添加
            <div class="OutfileBox OutfileBoxa">
              <a href="javascript:void(0);">产品图片</a>
              <a href="javascript:void(0);">产品附件</a>
              <a href="javascript:void(0);">报价表附件</a>
            </div>
          </div>
          </div>
      		<a class="conHeadLink editNext" href="javascript:void(0)">保存并继续添加下一个</a>
      		<a class="conHeadLink editSave" href="javascript:void(0)">保存</a>
      		<a class="conHeadLink editSumbit" href="javascript:void(0)">提交</a>
      		<a class="conHeadLink editCancel" href="javascript:void(0)">取消</a>
        </div>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 主要内容盒子 -->
<div class="row conBox">

<section class="row ClearLR font0">
  <div class="w24bf  MinH">
      <header class="tempH">Quotation information</header>
      <div id="PriceShow">
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Created on</span>
      		<p>2016-07-02</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Saved on</span>
      		<p>2016-07-03</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Created by</span>
      		<p>by Huang</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Status</span>
      		<p>Not reviewed yet</p>
      	</div>
      	<div class="RelativeBox">
      		<textarea class="PriceTxt" rows="5"></textarea>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Supplier</span>
      		<p>Ms.zhang Import/Export</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Contact</span>
      		<p>Ms zhang</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Reference</span>
      		<p>QT160700001</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Subject</span>
      		<p>2017 walmart selection</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Quote term</span>
      		<p>FOB</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Payment</span>
      		<p>30% TT in advance</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Loading port</span>
      		<p>shenzhen</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Expiry date</span>
      		<p>2016-09-02</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Delivery time</span>
      		<p>60 days</p>
      	</div>
      	<div class="RelativeBox PriceBox">
      		<span class="inputName">Attachment</span>
      		<ul>
      			<li><a href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>工厂iso2001证书</li>
      			<li><a href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>工厂营业执照</li>
      		</ul>
      	</div>
      </div><!-- PriceShow -->

      <div id="PriceHide" class="PriceHide">
      	<form>
      	    <div class="RelativeBox PriceBox">
	      		<span class="inputName">Created on</span>
	      		<p>2016-07-02</p>
	      	</div>
	      	<div class="RelativeBox PriceBox">
	      		<span class="inputName">Saved on</span>
	      		<p>2016-07-03</p>
	      	</div>
	      	<div class="RelativeBox PriceBox">
	      		<span class="inputName">Created by</span>
	      		<p>by Huang</p>
	      	</div>
	      	<div class="RelativeBox PriceBox">
	      		<span class="inputName">Status</span>
	      		<p>Not reviewed yet</p>
	      	</div>
	      	<div class="RelativeBox">
	      		<textarea class="PriceTxt" rows="5"></textarea>
	      	</div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Supplier</span>
	          <div class="customSelect contactSelect">
	             <a class="customSelLink contactSelLink" href="javascript:void(0)"><span class="customSelTxt">Supplier</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
	             <ul class="list-unstyled customSelMsg contactSelUl" style="display: none;">
	               <li>供应商2</li>
	               <li>供应商3</li>
	               <li>供应商4</li>
	             </ul>
	          </div>
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Supplier</span>
	          <input type="text" class="inputVal" value="101010101">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Contact</span>
	          <input type="text" class="inputVal" value="供应商类型">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Reference</span>
	          <input type="text" class="inputVal" value="公司名">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Subject</span>
	          <input type="text" class="inputVal" value="公司地址">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Quote term</span>
	          <input type="text" class="inputVal" value="www.123.com">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Payment</span>
	          <input type="text" class="inputVal" value="付款方式">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Loading port</span>
	          <input type="text" class="inputVal" value="经营产品">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Expiry date</span>
	          <input type="text" class="inputVal" value="银行账户">
	        </div>
	        <div class="RelativeBox font0 inputBox">
	          <span class="inputName">Delivery time</span>
	          <input type="text" class="inputVal" value="银行账户">
	        </div>
	        <div class="RelativeBox font0 inputBox PriceBox">
	          <span class="inputName">Attavhment</span>
	          <ul>
      			<li>工厂iso2001证书</li>
      			<li>工厂营业执照</li>
      		</ul>
	        </div>
	      </form>
      </div><!-- PriceHide -->
  </div><!-- w24bf -->

  <div id="fullscreenWrap" class="w75bf conBg MinH"><!-- w75bf --> 
  	<div class="dragBoxWrap" id="dragBoxWrap">
  	    <p class="mb0"><a id="fullscreen" href="javascript:void(0);"><span class="glyphicon glyphicon-fullscreen"></span></a></p>
  		<p class="PriceH">Please drag the following picture to the relevant product otherwise they will be saved as the quotesheet attachment</p>
  		<div class="dragLink" ondragover="allowDrop(event)">
  			<img src="img/1.png" class="img-responsive" draggable="true" ondragstart="drag(event)" id="drag1">
  			<img src="img/1.png" class="img-responsive" draggable="true" ondragstart="drag(event)" id="drag2">
  			<img src="img/1.png" class="img-responsive" draggable="true" ondragstart="drag(event)" id="drag3">
  		</div>
        <p class="PriceH">Reselect the field to match the template and imported data if they are wrong.You can also edit or add any content if necessary.</p>
  		<div id="dragTableWrap02">
  			<table id="dragTable">
				<tr>
				    <th rowspan="" colspan=""></th>
				</tr>
			</table>
  		</div>
  	</div>
  </div><!-- w75bf --> 

</section>

</div>
<!-- 主要内容盒子 -->

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/json2.js"></script>
<script src="js/mmGrid.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">

function allowDrop(event)
{
    event.preventDefault();
}

function drag(event)
{
    event.dataTransfer.setData("img",event.target.id);
}

function drop(event)
{
    var data=event.dataTransfer.getData("img");
    var tarId = document.getElementById(data);
    var tarClass = event.target.className;  //判断目标事件的class是img-responsive还是dragTar，用于标识处理移动图片在目标盒子还是目标图片上
    var tar = $(event.target).parent(".dragTar");
    var tarOther = $(event.target);

    if ( tarClass=="img-responsive" ) {
        if (tar.children("img").length>=5) {
            alert("超出5个了！");
        }else{
            tar.append(tarId);
        }
    }else if(tarClass=="dragTar"){
       if (tarOther.children("img").length>=5) {
            alert("超出5个了！");
        }else{
            tarOther.append(tarId);
        }
    }
    else{
      return false;
    }
    event.preventDefault();
    return false;
}

// var fileBox = $(".fileLink");
// var ImgBox = $(".dragTar");
// fileBox.addEventListener("change",function(){
// 	var files_array = this.files;
// 	if(files_array[0].type.match(/image/)){
// 		read_image_file(files_array[0]);
// 	}
// },false);

// function read_image_file(file){
// 	var reader = new FileReader();
// 	reader.onload = function(e){
// 		var image_contents = e.target.result;
// 		var img = document.createElement("img");
// 		img.src = image_contents;
// 		ImgBox.innerHTML="";
// 		ImgBox.appendChild(img);
// 	};
// 	reader.readAsDataURL(file);
// }

</script>
</body>
</html>