<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">分类管理 <a class="changeHtml" href="Zn/manage_categories.php">切换</a></span>
		<button class="conSave">保存</button>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- 主要内容盒子 -->
<div class="row conBox">

<section class="row ClearLR contactsBox">
  <div class="w24bf MinH contactsBox1">
  	<p>Please create departments and Categories.</p>
  	<p>When your staff join the company,you can authorize the departments or categories that he or she will handle.</p>
  	<p>When product or quotation is submitted only under a department,all staff under this department can view this product or quotation,until one of them edited the category of the product or quotation.</p>
  	<p></p>
  </div>

  <div class="w24bf MinH contactsBox2">
    <div class="contactsBox2H">
		<header>Departments</header>
		<a class="contactsCusAdd" data-toggle="modal" data-target=".categoriesMa" href="javascript:void(0)">Add department</a>
  	</div>
  	<div class="contactsMsg niceScroll">
        <ul id="cateUla" class="cateUl">
        	<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><a href="javascript:void(0)" class="cateLinkTxt">部门</a></li>
        	<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><a href="javascript:void(0)" class="cateLinkTxt">日用品</a></li>
        	<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><a href="javascript:void(0)" class="cateLinkTxt">部门</a></li>
        </ul>
  	</div>
  </div>

  <div id="contactsBox2" class="w24bf MinH contactsBox2 custerHide">
    <div class="contactsBox2H">
		<header>Categories</header>
		<a class="contactsCusAdd" data-toggle="modal" data-target=".categoriesMb" href="javascript:void(0)">Add category</a>
  	</div>
  	<div class="contactsMsg niceScroll">
        <ul id="cateUlb" class="cateUl">
        	<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><a href="javascript:void(0)" class="cateLinkTxt">杯子</a></li>
        	<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><a href="javascript:void(0)" class="cateLinkTxt">餐具</a></li>
        	<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><a href="javascript:void(0)" class="cateLinkTxt">炊具</a></li>
        </ul>
  	</div>
  </div>

</section>
</div>
<!-- 主要内容盒子 -->
</div><!-- container-fluid -->


<!-- 新增部门 添加自定义字段 -->
<div class="modal fade categoriesMa" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
        <p class="addModalTxt">Please enter the name of the field</p>
        <input id="categoriesMa" type="text" class="addModalIn"></input>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button id="categoriesMLinka" type="button" class="btn btn-primary">Ok</button>
      </div>
    </div>
  </div>
</div>
<!-- 新增部门 添加自定义字段 -->

<!-- 新增分类 添加自定义字段 -->
<div class="modal fade categoriesMb" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
        <p class="addModalTxt">Please enter the name of the field</p>
        <input id="categoriesMb" type="text" class="addModalIn"></input>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button id="categoriesMLinkb" type="button" class="btn btn-primary">Ok</button>
      </div>
    </div>
  </div>
</div>
<!-- 新增分类 添加自定义字段 -->

<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">
// 新增部门 添加自定义字段
$(document).on("click","#categoriesMLinka",function(){
    var Iv = $.trim($("#categoriesMa").val());
    var tar = $("#cateUla");
    var tarMsg = '<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><span class="cateLinkTxt">'+ Iv +'</span></li>';
    if (Iv.length=="") {
        show_msg("信息未完善！",3000);
    }else{
        tar.append(tarMsg);
        $('.categoriesMa').modal('hide');
    }
})
// 新增部门 添加自定义字段

// 新增部门 添加自定义字段
$(document).on("click","#categoriesMLinkb",function(){
    var Iv = $.trim($("#categoriesMb").val());
    var tar = $("#cateUlb");
    var tarMsg = '<li><a class="cateLinkdelete" href="javascript:void(0)"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a><span class="cateLinkTxt">'+ Iv +'</span></li>';
    if (Iv.length=="") {
        show_msg("信息未完善！",3000);
    }else{
        tar.append(tarMsg);
        $('.categoriesMb').modal('hide');
    }
})
// 新增部门 添加自定义字段

// 点击部门 才显示相应部门内容
$(document).on("click",".cateLinkTxt",function(){
    var tar = $("#contactsBox2");
    tar.removeClass("custerHide");
})
// 点击部门 才显示相应部门内容
</script>
</body>
</html>