<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
		<span class="headMsgTit">Message <a class="changeHtml" href="Zn/message.php">切换</a></span>
	</div>
</header>
<!-- 头部固定栏 -->

<div class="row conBox">
<section class="row ClearLR MinH conBg">
    <table class="table table-bordered table-hover messageTable">
      <thead>
        <tr>
          <th>Department</th>
          <th>Category</th>
          <th>Time</th>
          <th>By</th>
          <th>Object</th>
          <th>Action</th>
          <th>Subject</th>
          <th>Content</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>日用品</td>
          <td>杯子</td>
          <td>2016-08-10 15:10</td>
          <td>黄先生</td>
          <td>黄先生有限公司</td>
          <td>要求更新</td>
          <td>2017春节沃尔玛选品</td>
          <td>价格错误，包装尺寸不齐全，请核对后重新提交。</td>
        </tr>
        <tr>
          <td>日用品</td>
          <td>杯子</td>
          <td>2016-08-10 15:10</td>
          <td>黄先生</td>
          <td>黄先生有限公司</td>
          <td>要求更新</td>
          <td>2017春节沃尔玛选品</td>
          <td>价格错误，包装尺寸不齐全，请核对后重新提交。</td>
        </tr>
      </tbody>
    </table>
</section>
</div>

</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">

$.get('js/data.js', function(data) {
	// console.log(dataC.select_a[0].id);
	$.each(dataC.select_a, function(index, item) {
        // console.log("<div>"+ item.id + "</div>" + "<div>"+ item.Name + "</div><hr/>");
        var selA = '<li id="'+item.id+'">'+ item.Name +'</li>';
        $("#selPart").append(selA);
    });

    $.each(dataC.select_b, function(index, item) {
        // console.log("<div>"+ item.id + "</div>" + "<div>"+ item.Name + "</div><hr/>");
        var selA = '<li id="'+item.id+'">'+ item.Name +'</li>';
        $("#selSort").append(selA);
    });

});

$(document).on("click","#addDetail",function(){
	var I = $(this);
	var selParted = $("#selParted .customSelTxt").attr("id");
	var selSorted = $("#selSorted .customSelTxt").attr("id");
    var url = "addDetail.php" + '?' + selParted + '&' +selSorted;
    console.log(url);
    location.href = "url";
})
</script>
</body>
</html>