<?php
include_once 'inc/head.php';
?>

<!-- 头部固定栏 -->
<header class="conHeader">
	<div class="HeadMsg">
    <span class="headMsgTit">添加产品 <a class="changeHtml" href="Zn/beginCreate.php">切换</a></span>
	</div>
</header>
<!-- 头部固定栏 -->

<!-- beginCreate -->
<div class="row  conBox font0">

<div class="beginCreateH beginCreateL">

<div class="row beginCreateImg"><img src="img/01.png"></div>

<div class="row mb20">
	<div class="col-sm-4 text-right">公司名称</div><div class="col-sm-6">黄希采购有限公司</div>
</div>

<div class="row mb20">
	<div class="col-sm-4 text-right">公司简介</div><div class="col-sm-6">我司是英国最大的采购公司，旗下有MLGB,CNM等品牌，畅销英国各大超市</div>
</div>

<div class="row mb20">
	<div class="col-sm-4 text-right">公司网址</div><div class="col-sm-6">www.huangxitrading.com</div>
</div>

<div class="row mb20">
	<div class="col-sm-4 text-right">公司领英账号地址</div><div class="col-sm-6">www.linkedin.com/huangxitrading</div>
</div>

<div class="row mb20">
	<div class="col-sm-4 text-right">地址</div><div class="col-sm-6">英国伦敦MLGB大厦</div>
</div>

<div class="row mb20">
	<div class="col-sm-4 text-right">行业</div><div class="col-sm-6">日用品，电器，玩具</div>
</div>

<div class="row mb20">
	<div class="col-sm-4 text-right">采购产品</div><div class="col-sm-6">餐具，炊具，平板电脑，手机，积木玩具</div>
</div>

</div>
<!-- beginCreateL -->

<!-- beginCreateR -->
<div class="beginCreateH beginCreateR">

	<p class="text-center"><strong>Step one：Select department</strong></p>
    <p class="text-center beginCreateMb">PS:You CANNOT start until you select a department</p>
    <div class="mb30 text-center">
	    <div class="customSelect">
	       <a id="selParted" class="customSelLink addNewProductSelLink" href="javascript:void(0)"><span class="customSelTxt">Please select department</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
	       <ul id="selPart" class="list-unstyled customSelMsg addNewProductSelMsg">
	           <li>2233</li>
	           <li>2233</li>
	           <li>2233</li>
	           <li>2233</li>
	       </ul>
	    </div>
	</div>
    <div class="mb30 text-center">
	    <div class="customSelect">
	       <a id="selSorted" class="customSelLink addNewProductSelLink" href="javascript:void(0)"><span class="customSelTxt">Please select category</span><span class="glyphicon customSelIcon glyphicon-menu-down" aria-hidden="true"></span></a>
	       <ul id="selSort" class="list-unstyled customSelMsg addNewProductSelMsg">
	           <li>2233</li>
	           <li>2233</li>
	           <li>2233</li>
	           <li>2233</li>
	       </ul>
	    </div>
	</div>
    <p class="text-center"><strong>Step two：Select category</strong></p>
    <p class="addNewProductTet beginCreateMb">PS：Different categories maybe handled by different person,so a accurate category is very important for the quotation follow-up.</p>
    <p class="addNewProductTet beginCreateMb">if you are submitting different categories or you are not sure the catgory for the product,you can edit the category later or ignore it.</p>
    <p class="addNewProductTet beginCreateMb">请按照要求提供产品报价的详细内容。如果是容器类的产品，在尺寸一栏同时提供产品容量。</p>
    <div class="addNewProductCheck"><label><input type="checkbox"> <span>Remember the department and category I chose</span></label></div>
    <div class="addNewProductLink"><a id="addDetail" href="javascript:void(0);">Create one by one</a></div>
    <div class="addNewProductLink"><a href="#">Mass upload from Excel</a></div>
</div>
<!-- beginCreateR -->

</div>
<!-- beginCreate -->


</div><!-- container-fluid -->
<script src="js/jquery-2.1.4.min.js"></script>
<!--[if lt IE 9]><script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script><![endif]-->
<script src="js/bootstrap.min.js"></script>
<script src="js/Common.js"></script>
<script type="text/javascript">
$(function(){
	var aa = $(".beginCreateH").css("height",WH);
})
</script>
</body>
</html>