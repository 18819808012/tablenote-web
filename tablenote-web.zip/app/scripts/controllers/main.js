'use strict';

/**
 * @ngdoc function
 * @name tablenoteWebApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the tablenoteWebApp
 */
angular.module('tablenoteWebApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
