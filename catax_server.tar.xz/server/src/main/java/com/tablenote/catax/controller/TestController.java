package com.tablenote.catax.controller;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.tablenote.catax.base.TableName;
import com.tablenote.catax.controller.base.BaseController;
import com.tablenote.catax.service.IBoxService;
import com.tablenote.catax.service.ICompanyService;
import com.tablenote.catax.service.IContactListService;
import com.tablenote.catax.service.IHistoryCollector;
import com.tablenote.catax.service.IQuotationService;
import com.tablenote.catax.service.ITemplateService;
import com.tablenote.catax.service.IUserService;
import com.tablenote.catax.supports.mail.TemplateProvider;
import com.tablenote.catax.supports.push.IMessagePushWorker;
import com.tablenote.catax.supports.service.IEMailService;

@Controller
@RequestMapping(value = "/test")
public class TestController extends BaseController {

	@Resource
	IEMailService eMailService;

	@Resource
	ITemplateService templateService;
	
	@Resource
	ICompanyService companyService;
	
	@Resource
	MongoTemplate mongoTemplate;
	
	@Resource
	IUserService userService;
	
	@Resource
	IBoxService boxService;
	
	@Resource
	IQuotationService quotationService;

	@Resource
	IContactListService contactListService;
	
	@Resource
	IHistoryCollector historyCollector;
	
	@Resource
	IMessagePushWorker messagePushWorker;
	
	ObjectMapper om = new ObjectMapper();

	@RequestMapping(value = "/parse", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public Map<String, Object> parsey(HttpServletRequest request, @RequestParam Map<String, Object> paramsMap) throws Exception {
		System.out.println("=======================>POST+application/json");
		System.out.println(om.writeValueAsString(paramsMap));
		parse(request);
		return paramsMap;
	}

	private void parse(HttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		System.out.println("  =====cookie=====");
		for( Cookie cookie : cookies ) {
			System.out.println(cookie.getName() +":" +cookie.getValue());
		}

		System.out.println("  =====session=====");
		HttpSession session = request.getSession();
		Enumeration<String> attributeNames = session.getAttributeNames();
		while(attributeNames.hasMoreElements()) {
			String nextElement = attributeNames.nextElement();
			System.out.println(nextElement +":" +session.getAttribute(nextElement));
		}
		
	}

	@RequestMapping(value = "/test1")
	@ResponseBody
	public Map<String, Object> test1() {
		return new HashMap<String, Object>();
	}

	@RequestMapping(value = "/test2")
	@ResponseBody
	public Map<String, Object> test2(HttpServletResponse response) {
		HashMap<String, Object> hashMap = new HashMap<String, Object>();

		hashMap.put("name", "鸡巴费");

		Cookie opid = new Cookie("opid", new ObjectId().toHexString());
		opid.setMaxAge(86400);
		opid.setPath("/");
		opid.setDomain(".jiefzz.com");
		response.addCookie(opid);
		return hashMap;
	}

	@RequestMapping(value = "/test3")
	@ResponseBody
	public Map<String, Object> test3() {
		Map<String,Object> rMap = new HashMap<String, Object>();

		//String registerNewUser = userService.registerNewUser("kimffy24@gmail.com", "123456", "Kimffy", null);
		//rMap.put("result", registerNewUser);
		
//		rMap.put("hasSettlement", userService.hasSettlement("5824a79e072a8b25f1b77df6"));
//		rMap.put("getSettlementCompanyId", userService.getSettlementCompanyId("5824a79e072a8b25f1b77df6"));
		
		userService.validEmail("58274805072a8b3fd6b91620", "2cf58");
		
		return rMap;
	}

	@RequestMapping(value = "/test4")
	@ResponseBody
	public Map<String, Object> test4() {
		Map<String,Object> rMap = new HashMap<String, Object>();
		
		//boolean isStaff = companyService.isStaff("5824ab94072a8b29037a0cb2", "582573f66126804d5c614322");		
		//rMap.put("isStaff", isStaff);
		//companyService.createNewCompany(new ObjectId().toHexString(), "鸡巴的公司", null);
		//companyService.makeManager("582483af072a8b0ccf431a1d", "试钟部门", "682e00448d7e5204f6719946");
		//companyService.assignStaff("582483af072a8b0ccf431a1d", null, "792e00448d7e5204f6719957", "试钟部门");
		
//		String companyIdWithCompanyCode = companyService.getCompanyIdWithCompanyCode("7");
//		rMap.put("result", companyIdWithCompanyCode);
		

//		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
//		companyCollection.update(new BasicDBObject("_id", new ObjectId("5824ab94072a8b29037a0cb2")), 
//				new BasicDBObject("$set", new BasicDBObject("staff.5824a79e072a8b25f1b77df6", "")));
		
		////companyService.makeManager("5824ab94072a8b29037a0cb2", "试钟部门", "5824a79e072a8b25f1b77df6");

		companyService.assignStaff("5824ab94072a8b29037a0cb2", "5824a79e072a8b25f1b77df6", "松紧度测试部门", true);
		
		return rMap;
	}


	@RequestMapping(value = "/test5")
	@ResponseBody
	public Map<String, Object> test5() {
		Map<String,Object> rMap = new HashMap<String, Object>();
		
		eMailService.sendEmail("1077101169@qq.com", TemplateProvider.getMailContentEn("123456", "testUserId"));
		
		return rMap;
	}


	@RequestMapping(value = "/test6")
	@ResponseBody
	public Map<String, Object> test6() {
		
		String sendEntranceItem = boxService.sendEntranceItem(new ObjectId().toHexString(), new ObjectId().toHexString());

		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("result", sendEntranceItem);
		return rMap;
	}

	@RequestMapping(value = "/test7")
	@ResponseBody
	public Map<String, Object> test7() {
		
		String quotationId = quotationService.createNewQuotation("583080d8ac552d4dacaf8c16", "583080d8ac552d4dacaf8c15", "神的部门", null, null);

		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("quotationId", quotationId);
		return rMap;
	}
	
	@RequestMapping(value = "/test8")
	@ResponseBody
	public Map<String, Object> test8() {
		
//		String boxItemId = boxService.sendBoxItem("583087ebac552d5666d4fbaf");
//		String boxItemId = boxService.sendUpdateRequest("583086eaac552d55d5f7896d", "");
		String boxItemId = boxService.createNewBoxItem("583086eaac552d55d5f7896d");
		boxService.makeJunk(boxItemId);
		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("boxItemId", boxItemId);
		return rMap;
	}
	
	@RequestMapping(value = "/test9")
	@ResponseBody
	public Map<String, Object> test9() {
		
		Long lastTime = 1481554982391l;
		List<String> newBoxItemIds = boxService.getNewBoxItemIds("5846e7218d7e52683ce080a5", lastTime);
		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("newBoxItemIds", newBoxItemIds);
		return rMap;
	}
	
	@RequestMapping(value = "/test10")
	@ResponseBody
	public Map<String, Object> test10() {
		
		List<String> newBoxItemIds = boxService.getNewBoxItemIds("5846e7218d7e52683ce080a5", "584ea2088d7e52683ce643cd");
		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("newBoxItemIds", newBoxItemIds);
		return rMap;
		
	}

	
	@RequestMapping(value = "/test11")
	@ResponseBody
	public Map<String, Object> test11() {
		
		historyCollector.addQuotationHistoryMark("5846e7218d7e52683ce080a5", "supplier", "鸡巴飞");
		
		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("success", "");
		return rMap;
		
	}
	
	@RequestMapping(value = "/test12")
	@ResponseBody
	public Map<String, Object> test12() {
		
		String createNewBoxItem = boxService.createNewBoxItem("586798218d7e52683c31cacd");
		boxService.sendBoxItem(createNewBoxItem);
		
		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("success", "");
		return rMap;
		
	}
	
	@RequestMapping(value = "/test13")
	@ResponseBody
	public Map<String, Object> test13() {
		
		contactListService.addContactItem("589d7c3e1336a6683c8d568c", "来一发", new HashMap());
		
		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("success", "");
		return rMap;
		
	}
	
	@RequestMapping(value = "/test14")
	@ResponseBody
	public Map<String, Object> test14() {
		
		messagePushWorker.broadcast("这是desc", "这是payload", new HashMap<String, String>(), null);
		
		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("success", "");
		return rMap;
		
	}

	@RequestMapping(value = "/test15")
	@ResponseBody
	public Map<String, Object> test15() {
		
		contactListService.removeContactCompany("58a327e91336a630f5a4e866");
		
		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("success", "");
		return rMap;
		
	}

	@RequestMapping(value = "/test16")
	@ResponseBody
	public Map<String, Object> test16() {
		
		String result = contactListService.createContactCompany(new ObjectId().toHexString(), "测试部门", "测试CompanyName", new HashMap<String, String>());
		
		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("result", result);
		rMap.put("success", "");
		return rMap;
		
	}

	@RequestMapping(value = "/test17")
	@ResponseBody
	public Map<String, Object> test17() {

		Map<String, Object> result = companyService.createNewCompany(new ObjectId().toHexString(), "测试后companyName", new HashMap<String, Object>());
		
		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("result", result);
		rMap.put("success", "");
		return rMap;
		
	}

	@RequestMapping(value = "/test18")
	@ResponseBody
	public Map<String, Object> test18() {

		Map<String, String> extra = new HashMap<String, String>();
		extra.put("手机", "13599998888");
		extra.put("fax", "020-32078817");
		String result = contactListService.addContactItem("58a322281336a630f5a4e853", "测试金飞", extra);
		
		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("result", result);
		rMap.put("success", "");
		return rMap;
		
	}

	@RequestMapping(value = "/test19")
	@ResponseBody
	public Map<String, Object> test19() {

		
		List<Object> baseInfo = new ArrayList<Object>();
		baseInfo.add("这是一个");
		baseInfo.add("list对象");

		Map<String, Object> content = new HashMap<String, Object>();
		content.put("手机", baseInfo);
		content.put("fax", baseInfo);
		
		templateService.updateTemplate("58a55d251336a65cc7bf7aeb", baseInfo, content, null, null);
		Object result = null;
		
		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("result", result);
		rMap.put("success", "");
		return rMap;
		
	}


	@RequestMapping(value = "/test20")
	@ResponseBody
	public Map<String, Object> test20() {

		contactListService.addResource("58a5f1d6298f66c643f62e69", "nmb", "jibafei");
		contactListService.addResource("58a5f1d6298f66c643f62e69", "tian shang fei de", "shi shen me");
		Object result = null;
		
		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("result", result);
		rMap.put("success", "");
		return rMap;
		
	}

	@RequestMapping(value = "/test21")
	@ResponseBody
	public Map<String, Object> test21() {

		contactListService.removeResource("58a5f1d6298f66c643f62e69", "nmb");
		Object result = null;
		
		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("result", result);
		rMap.put("success", "");
		return rMap;
		
	}

	@RequestMapping(value = "/test22")
	@ResponseBody
	public Map<String, Object> test22() {

		companyService.leaveCompany("58a3f7401336a61b2b0141aa", "58a3f8ec1336a61b2b0141ac");
		Object result = null;
		
		Map<String,Object> rMap = new HashMap<String, Object>();
		rMap.put("result", result);
		rMap.put("success", "");
		return rMap;
		
	}
}
