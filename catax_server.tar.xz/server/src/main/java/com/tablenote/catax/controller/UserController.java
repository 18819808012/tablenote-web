package com.tablenote.catax.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.tablenote.catax.base.CommonParameters;
import com.tablenote.catax.controller.base.BaseController;
import com.tablenote.catax.service.IUserService;
import com.tablenote.catax.supports.exception.ParametersException;
import com.tablenote.catax.supports.helper.RequestEnsure;
import com.tablenote.catax.supports.helper.RandomPath;

@Controller
@RequestMapping(value = "/user")
public class UserController extends BaseController {

	@Resource
	IUserService userService;
	
	@RequestMapping(value = "/detail")
	@ResponseBody
	public Map<String, Object> detail(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {
		
		String userId;
		try {
			while(true) {
				try {
					RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
							"userId"
					});
					userId = (String )paramsMap.get("userId");
				} catch (Exception e) {
					RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
							"email",
					});
					String email = (String )paramsMap.get("email");
					userId = userService.getUserIdWithEmail(email);
				}
				break;
			}
		} catch (Exception e) {
			throw new ParametersException("[userId] or [email]");
		}
		
		Map<String, Object> detail = userService.detail(userId);
		detail.remove("password");
		detail.remove("valid");
		detail.remove("_id");
		detail.remove("lastLoginInfo");
		if(detail.containsKey("settlement"))
			detail.put("companyId", ((ObjectId )detail.get("settlement")).toHexString());
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("user", detail);
		return resultMap;
	}

	@RequestMapping(value = "/avatar")
	@ResponseBody
	public Map<String, Object> upload(HttpServletRequest request, HttpServletResponse response, @RequestParam(value = "avatar", required = true) MultipartFile file) {

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		
		String fileChildPath = RandomPath.getRelativePath() +"/" +RandomPath.getNewFileName(file);
		try {
			FileUtils.copyInputStreamToFile(file.getInputStream(), new File(CommonParameters.FILE_STORAGE_TOP_DIRECTORY, fileChildPath));
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
		
		String avatarPath = CommonParameters.FILE_DOWNLOAD_PREFIX +fileChildPath;
		userService.setAvatar(userId, avatarPath);

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("avatar", avatarPath);
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/updateProfile")
	@ResponseBody
	public Map<String, Object> updateProfile(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		
		if(paramsMap.size()>0)
			userService.updateProfile(userId, paramsMap);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}
}
