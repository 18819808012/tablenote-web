package com.tablenote.catax.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.bson.types.ObjectId;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tablenote.catax.base.PasswordUtils;
import com.tablenote.catax.controller.base.BaseController;
import com.tablenote.catax.service.Enum4CompanyEmployeeRole;
import com.tablenote.catax.service.ICompanyService;
import com.tablenote.catax.service.IUserService;
import com.tablenote.catax.supports.exception.NonAcceptRequestException;
import com.tablenote.catax.supports.exception.PromissionDenyException;
import com.tablenote.catax.supports.helper.RequestEnsure;
import com.tablenote.catax.supports.service.IEMailService;

@Controller
@RequestMapping(value = "/auth")
public class AuthController extends BaseController {

	@Resource
	IUserService userService;

	@Resource
	ICompanyService companyService;

	@Resource
	IEMailService eMailService;
	
	@RequestMapping(value = "/register")
	@ResponseBody
	public Map<String, Object> register(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {
		
		String email;
		String password;
		String user;
		String seller;
		
		String[] shouldHas = new String[]{
				"email",
				"password",
				"user",
				// # 17.02.15 更新 加上此字段
				"seller"
		};
		for( String key : shouldHas ){
			if(!paramsMap.containsKey(key))
				throw new NonAcceptRequestException(key);
		}
		
		email = (String )paramsMap.remove("email");
		password = (String )paramsMap.remove("password");
		user = (String )paramsMap.remove("user");
		seller = (String )paramsMap.remove("seller");
		
		String userId = userService.registerNewUser(email, PasswordUtils.makePassword(password), user, seller, paramsMap);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		resultMap.put("userId", userId);
		return resultMap;
	}

	@RequestMapping(value = "/login")
	@ResponseBody
	public Map<String, Object> login(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		Object obj;
		String email;
		String password;
		String deviceId;
		String deviceType;
		String deviceName;
		
		String[] shouldHas = new String[]{
				"email",
				"password",
				"deviceId",
				"deviceType",
				"deviceName"
		};
		for( String key : shouldHas ){
			if(!paramsMap.containsKey(key))
				throw new NonAcceptRequestException(key);
		}
		
		email = (String )paramsMap.remove("email");
		password = (String )paramsMap.remove("password");
		deviceId = (String )paramsMap.remove("deviceId");
		deviceType = (String )paramsMap.remove("deviceType");
		deviceName = (String )paramsMap.remove("deviceName");
		
		Map<String, Object> userInfo = userService.login(email, PasswordUtils.makePassword(password), "", deviceId);
		
		// TODO 未验证拒绝登陆
		Map<String, Object> valid = (Map<String, Object> )userInfo.get("valid");
		if(!((Boolean )valid.get("emailState")))
			throw new PromissionDenyException("Your Email is not valid!!!");
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String userId = (String )userInfo.get("id");

		boolean hasSettlement = null!=(obj = userInfo.get("settlement"));
		String settlement = hasSettlement?((ObjectId )obj).toHexString():null;
		boolean isManager = hasSettlement?companyService.isManager(settlement, userId):false;
		String companyLevel = hasSettlement?companyService.getCompanyLevel(settlement):null;
		
		Map<String, Object> lastLoginInfoList = userService.getLastLoginInfo(userId);
		Map<String, Object> lastLoginInfo = new HashMap<String, Object>();
		lastLoginInfo.put("deviceId", deviceId);
		lastLoginInfo.put("deviceType", deviceType);
		lastLoginInfo.put("deviceName", deviceName);
		
		if ("nil".equals(deviceId)) {
			;
		} else if(null==lastLoginInfoList) {
			userService.addLastLoginInfo(userId, deviceId, lastLoginInfo);
		} else if (lastLoginInfoList.containsKey(deviceId)) {
			;
		} else {
			if(lastLoginInfoList.size()>1) {
				lastLoginInfoList.put("error", "Login Faild!!!");
				return lastLoginInfoList;
			} else {
				userService.addLastLoginInfo(userId, deviceId, lastLoginInfo);
			}
		}

		String companyName = "";
		List<Object> joinDepartments = new ArrayList<Object>();
		if(hasSettlement) {
			Map<String, Object> detail = companyService.detail(settlement);
			companyName = (String )detail.get("componyName");
			Map<String, Object> staff = (Map<String, Object> )detail.get("staff");
			if(null!=staff) {
				Map<String, Object> userDepartmentData = (Map<String, Object> )staff.get(userId);
				if(null!=userDepartmentData) {
					joinDepartments.addAll(userDepartmentData.keySet());
				}
			}
		}
		
		HttpSession session = request.getSession();
		session.setAttribute("userId", userInfo.get("id"));
		session.setAttribute("email", email);
		session.setAttribute("settlement", null==(obj = userInfo.get("settlement"))?null:((ObjectId )obj).toHexString());
		
		resultMap.put("success", "");
		//resultMap.put("user", userId);
		resultMap.put("opid", userId);
		resultMap.put("nextUrl", paramsMap.get("nextUrl"));
		resultMap.put("settlement", settlement);
		resultMap.put("role", isManager?Enum4CompanyEmployeeRole.MANAGER:Enum4CompanyEmployeeRole.STAFF);
		resultMap.put("companyLevel", companyLevel);
		resultMap.put("expiresIn", 10080*60);
		resultMap.put("joinDepartments", joinDepartments);
		resultMap.put("companyName", companyName);
		resultMap.put("user", userInfo.get("user"));
		return resultMap;
	}

	@RequestMapping(value = "/validation", method = RequestMethod.GET)
	@ResponseBody
	public String valid(HttpServletRequest request, HttpServletResponse response, @RequestParam Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"code",
				"userId"
		});
		String code = (String )paramsMap.get("code");
		String userId = (String )paramsMap.get("userId");
		userService.validEmail(userId, code);
		Map<String, Object> detail = userService.detail(userId);
		Map<String, Object> valid = (Map<String, Object> )detail.get("valid");
		boolean result = (Boolean )valid.get("emailState");
		return result?"true":"false";
			
	}

	@RequestMapping(value = "/deregistation")
	@ResponseBody
	public Map<String, Object> logout(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"deviceId"
		});
		String deviceId = (String )paramsMap.remove("deviceId");
		
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(null!=userId && "".equals(userId)) {
			session.removeAttribute("userId");
			session.removeAttribute("email");
			session.removeAttribute("settlement");
			userService.removeLastLoginInfo(userId, deviceId);
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/updatePassword")
	@ResponseBody
	public Map<String, Object> updatePassword(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"password",
				"newPassword"
		});
		String password = (String )paramsMap.remove("password");
		String newPassword = (String )paramsMap.remove("newPassword");

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		
		Map<String, Object> userData = userService.detail(userId);
		
		String encPassword = PasswordUtils.makePassword(password);
		
		if(!encPassword.equals(userData.get("password")))
			throw new PromissionDenyException("Prevous password is no correct");
		
		userService.updatePassword(userId, PasswordUtils.makePassword(newPassword));
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/sendResetToken")
	@ResponseBody
	public Map<String, Object> sendResetToken(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"email"
		});
		String email = (String )paramsMap.remove("email");
		
		String userId = userService.getUserIdWithEmail(email);
		
		if(null==userId)
			throw new RuntimeException(String.format("User[email=%s] is not exist!!!", email));
		
		String token = userService.createResetPasswordToken(userId);
		
		eMailService.sendEmail(email, "www.tablenote.com: Your reset password token is   " +token +"   .");
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/resetPassword")
	@ResponseBody
	public Map<String, Object> resetPassword(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"password",
				"token"
		});
		String password = (String )paramsMap.remove("password");
		String token = (String )paramsMap.remove("token");

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		
		Map<String, Object> userData = userService.detail(userId);
		
		if(!token.equals(userData.get("rpwt")))
			throw new PromissionDenyException("token is no correct");
		Long rpwtime = (Long )userData.get("rpwtime");
		if(System.currentTimeMillis() - rpwtime.longValue()>3600000)
			throw new PromissionDenyException("token is out of date");
		
		userService.updatePassword(userId, PasswordUtils.makePassword(password));
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}
}
