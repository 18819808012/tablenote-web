package com.tablenote.catax.service;

import java.util.Collection;
import java.util.Map;

public interface ICompanyService {

	/**
	 * 创建公司
	 * @param userId 公司属主 
	 * @param companyName 公司名
	 * @param companyExtraInfo 额外提交的公司信息
	 * @return 公司ID
	 */
	public Map<String, Object> createNewCompany(String userId, String companyName, Map<String, Object> companyExtraInfo);
	
	/**
	 * 获取公司等级
	 * @param companyId
	 * @return
	 */
	public String getCompanyLevel(String companyId);
	
	/**
	 * 获取用户所在的公司的level
	 * @param userId
	 * @return
	 */
	public String getUserCompanyLevel(String userId);
	
	/**
	 * 
	 * @param companyId
	 */
	public void updateCompanyLevel(String companyId, String companyLevel);
	
	/**
	 * 获取公司完整数据
	 * @param companyId
	 * @return
	 */
	public Map<String, Object> detail(String companyId);
	
	/**
	 * 确认公司存在
	 * @param companyId
	 */
	public void makeSureCompanyExist(String companyId);
	
	/**
	 * 获取公司的属主
	 * @param companyId
	 * @return
	 */
	public String getOwnerId(String companyId);
	
	/**
	 * 确认是否是公司主人
	 * @param companyId
	 * @param userId
	 * @return true if user is company master, or false if not.
	 */
	public boolean isOwner(String companyId, String userId);
	
	/**
	 * 确认是否是公司员工
	 * @param companyId
	 * @param userId
	 * @return
	 */
	public boolean isStaff(String companyId, String userId);
	
	/**
	 * 确认用户是否为公司的某部门的管理员
	 * @param companyId
	 * @param userId
	 * @param department 指定的部门
	 * @return
	 */
	public boolean isManager(String companyId, String userId, String department);
	
	/**
	 * 确认用户是否为公司的管理员
	 * @param companyId
	 * @param userId
	 * @return
	 */
	public boolean isManager(String companyId, String userId);
	
	/**
	 * 获取公司员工数量
	 * @param companyId
	 * @return
	 */
	public int getStaffCount(String companyId);
	
	/**
	 * 获取用户管理的部门
	 * @param company
	 * @param userId
	 * @return
	 */
	public Collection<String> getUserControlDepartment(String companyId, String userId);
	
	/**
	 * 用companyCode换取companyId
	 * @param companyCode
	 * @return companyId
	 */
	public String getCompanyIdWithCompanyCode(String companyCode);
	
	/**
	 * 制作用户加入企业申请
	 * @param userId
	 * @param companyId
	 * @return 申请号
	 */
	public String makeJoinApplication(String userId, String companyId);
	
	/**
	 * 删除用户的加入申请
	 * @param joinApplicationId
	 */
	public void deleteJoinApplication(String joinApplicationId);
		
	/**
	 * 生成一个用户邀请
	 * @param companyId
	 * @param userId
	 * @return 邀请号
	 */
	public String makeInvitation(String companyId, String userId);
	
	/**
	 * 同意加入公司
	 * @param joinApplicationId 申请号
	 * @param companyId 当前执行的公司
	 */
	public void acceptJoinApplication(String joinApplicationId, String companyId);

	/**
	 * 同意邀请
	 * @param invitationId 邀请号
	 * @param userId 发起当前操作的用户
	 * @deprecated 不用接受邀请
	 */
	public void acceptInvitation(String invitationId, String userId);
	
	/**
	 * 设置用户为部门管理员
	 * @param companyId
	 * @param department
	 * @param userId
	 * @return
	 */
	public void makeManager(String companyId, String department, String userId);
	
	/**
	 * 设置用户为管理员
	 * @param companyId
	 * @param userId
	 * @return
	 */
	public void makeManager(String companyId, String userId);

	/**
	 * 企业主指派员工到部门，并设置是否为管理员
	 * @param managerUserId
	 * @param staffUserId
	 */
	public void assignStaff(String companyId, String staffUserId, String department, boolean makeManager);
	
	/**
	 * 指派员工到部门
	 * @param managerUserId
	 * @param staffUserId
	 */
	public void assignStaff(String companyId, String staffUserId, String department);
	
	/**
	 * 添加分类
	 * @param companyId
	 * @param department
	 * @param category
	 */
	public void addCategory(String companyId, String department, String category);
	
	/**
	 * 查看分类（所有）
	 * @param companyId
	 * @param department
	 * @param category
	 */
	public Map<String, Object> getCategories(String companyId);
	
	/**
	 * 查看分类（指定部门）
	 * @param companyId
	 * @param department
	 * @param category
	 */
	public Collection<Object> getCategories(String companyId, String department);
	
	/**
	 * 移除分类
	 * @param companyId
	 * @param department
	 * @param category
	 */
	public void removeCategory(String companyId, String department, String category);
	
	/**
	 * 移除部门
	 * @param companyId
	 * @param department
	 */
	public void removeDepartment(String companyId, String department);
	
	/**
	 * 反向设置（撤销）管理员
	 * @param companyId
	 * @param userId
	 */
	public void unsetManager(String companyId, String userId);
	
	/**
	 * 员工除名
	 * @param companyId
	 * @param userId
	 */
	public void leaveCompany(String companyId, String userId);
	
	/**
	 * 设置头像
	 * @param userId
	 * @param avatarPath
	 */
	public void setAvatar(String companyId, String avatarPath);
	
	/**
	 * 更新公司额外信息
	 * @param companyId
	 * @param extra
	 */
	public void updateProfile(String companyId, Map<String, Object> extra);
}
