package com.tablenote.catax.bean.base;

import java.io.Serializable;
import java.util.Map;

public class Resource implements Serializable {

	private static final long serialVersionUID = 2894955309103362143L;

	public Resource() {
	}

	public Resource(String uri, String type, int size, Map<String, Object> extraInfo) {
	}
	
	private String uri;
	private String type;
	private int size;
	private Map<String, Object> extraInfo;

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public Map<String, Object> getExtraInfo() {
		return extraInfo;
	}

	public void setExtraInfo(Map<String, Object> extraInfo) {
		this.extraInfo = extraInfo;
	}
}
