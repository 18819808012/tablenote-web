package com.tablenote.catax.supports.exception;

/**
 * 数据结构异常
 * @author kimffy
 *
 */
public class DataStructUncorrectException extends RuntimeException {

	private static final long serialVersionUID = -7849641677469919529L;

	public DataStructUncorrectException(String message) {
		super(String.format("Your request data[%s] has some wrong, please contact the [www.tablenote.com]'s administrator!!!", message));
	}

	public DataStructUncorrectException(String message, Throwable cause) {
		super(String.format("Your request data[%s] has some wrong, please contact the [www.tablenote.com]'s administrator!!!", message), cause);
	}

}
