package com.tablenote.catax.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.tablenote.catax.base.CommonParameters;
import com.tablenote.catax.base.TableName;
import com.tablenote.catax.controller.base.BaseController;
import com.tablenote.catax.service.ICompanyService;
import com.tablenote.catax.service.IContactListService;
import com.tablenote.catax.service.IUserService;
import com.tablenote.catax.supports.exception.PromissionDenyException;
import com.tablenote.catax.supports.helper.RandomPath;
import com.tablenote.catax.supports.helper.RequestEnsure;

@Controller
@RequestMapping(value = "/contact")
public class ContactController extends BaseController {

	@Resource
	IUserService userService;

	@Resource
	ICompanyService companyService;
	
	@Resource
	IContactListService contactListService;
	
	@Resource
	MongoTemplate mongoTemplate;
	
	@RequestMapping(value = "/createContactCompany")
	@ResponseBody
	public Map<String, Object> createCompany(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {
		
		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"companyName",
				// #后期更新 联系公司添加多个字段
				"supplierNumber",
				"supplierType",
				"companyAddress1",
				"companyAddress2",
				"companyAddress3",
				"companyAddress4",
				"website",
				"paymentTerm",
				"products",
		});
		
		String companyName = (String )paramsMap.remove("companyName");
		String department = CommonParameters.DEFAULT_DEPARTMENT;

		// #后期更新 联系公司添加多个字段
		String supplierNumber = (String )paramsMap.remove("supplierNumber");
		String supplierType = (String )paramsMap.remove("supplierType");
		String companyAddress1 = (String )paramsMap.remove("companyAddress1");
		String companyAddress2 = (String )paramsMap.remove("companyAddress2");
		String companyAddress3 = (String )paramsMap.remove("companyAddress3");
		String companyAddress4 = (String )paramsMap.remove("companyAddress4");
		String website = (String )paramsMap.remove("website");
		String paymentTerm = (String )paramsMap.remove("paymentTerm");
		String products = (String )paramsMap.remove("products");
		
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		String companyId = (String )session.getAttribute("settlement");
		
		if(!companyService.isOwner(companyId, userId) && !companyService.isManager(companyId, userId, department))
				throw new PromissionDenyException("Your are not the manager of department[name=" +department +"]");
		
		Map<String, String> extra = new HashMap<String, String>();
		Set<Entry<String,Object>> entrySet = paramsMap.entrySet();
		for( Entry<String,Object> entry:entrySet ) {
			if( String.class.equals(entry.getValue().getClass()) )
				extra.put(entry.getKey(), (String )entry.getValue());
		}
		String contactCompanyItemId = contactListService.createContactCompany(companyId, department, companyName, extra);

		// #后期更新 联系公司添加多个字段
		DBCollection collection = mongoTemplate.getCollection(TableName.CONTACTS);
		collection.update(new BasicDBObject("_id", new ObjectId(contactCompanyItemId)),
				new BasicDBObject("$set", new BasicDBObject()
						.append("supplierNumber", supplierNumber)
						.append("supplierType", supplierType)
						.append("companyAddress1", companyAddress1)
						.append("companyAddress2", companyAddress2)
						.append("companyAddress3", companyAddress3)
						.append("companyAddress4", companyAddress4)
						.append("website", website)
						.append("paymentTerm", paymentTerm)
						.append("products", products)
						)
				);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		resultMap.put("contactCompanyItemId", contactCompanyItemId);
		return resultMap;
	}

	@RequestMapping(value = "/createContactItem")
	@ResponseBody
	public Map<String, Object> createContactItem(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {
		
		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"contactCompanyItemId",
				"name",
				// #后期更新 联系人添加多个字段
				"position",
				"email",
				"tel",
				"cellphone",
				"fax",
		});
		String contactCompanyItemId = (String )paramsMap.remove("contactCompanyItemId");
		String name = (String )paramsMap.remove("name");

		// #后期更新 联系人添加多个字段
		String position = (String )paramsMap.remove("position");
		String email = (String )paramsMap.remove("email");
		String tel = (String )paramsMap.remove("tel");
		String cellphone = (String )paramsMap.remove("cellphone");
		String fax = (String )paramsMap.remove("fax");
		
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		String companyId = (String )session.getAttribute("settlement");
		
		if(!companyService.isOwner(companyId, userId) && !companyService.isManager(companyId, userId))
				throw new PromissionDenyException("Your cannot create new item of contact");
		
		Map<String, String> extra = new HashMap<String, String>();
		Set<Entry<String,Object>> entrySet = paramsMap.entrySet();
		for( Entry<String,Object> entry:entrySet ) {
			if( String.class.equals(entry.getValue().getClass()) )
				extra.put(entry.getKey(), (String )entry.getValue());
		}
		String contactItemId = contactListService.addContactItem(contactCompanyItemId, name, extra);

		// #后期更新 联系公司添加多个字段
		DBCollection collection = mongoTemplate.getCollection(TableName.CONTACTS);
		collection.update(new BasicDBObject("_id", new ObjectId(contactCompanyItemId)),
				new BasicDBObject("$set", new BasicDBObject()
						.append("contactItems." +contactItemId +".position", position)
							.append("contactItems." +contactItemId +".email", email)
							.append("contactItems." +contactItemId +".tel", tel)
							.append("contactItems." +contactItemId +".cellphone", cellphone)
							.append("contactItems." +contactItemId +".fax", fax)
						)
				);
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		resultMap.put("contactItemId", contactItemId);
		return resultMap;
	}

	@RequestMapping(value = "/getContacts")
	@ResponseBody
	public Map<String, Object> getContacts(HttpServletRequest request, HttpServletResponse response/*, @RequestBody Map<String, Object> paramsMap*/) {
		RequestEnsure.ensureIsLoginSession(request);
		//RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
		//		"department",
		//});
		//String department = (String )paramsMap.remove("department");
		String department = CommonParameters.DEFAULT_DEPARTMENT;

		HttpSession session = request.getSession();
		String companyId = (String )session.getAttribute("settlement");
		if(null==companyId || "".equals(companyId))
			throw new PromissionDenyException("Your were never join in any company");
		
		List contacts = contactListService.getContacts(companyId, department);

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("contacts", contacts);
		return resultMap;
		
	}

	@RequestMapping(value = "/deleteContact")
	@ResponseBody
	public Map<String, Object> deleteContact(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {
		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"contactCompanyId",
		});
		String contactCompanyId = (String )paramsMap.remove("contactCompanyId");
		
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		String companyId = (String )session.getAttribute("settlement");
		if(null==companyId || "".equals(companyId))
			throw new PromissionDenyException("Your were never join in any company");

		if(!companyService.isManager(companyId, userId))
			throw new PromissionDenyException("Not premitted");
		
		contactListService.removeContactCompany(contactCompanyId);

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
		
	}

	@RequestMapping(value = "/deleteContactItem")
	@ResponseBody
	public Map<String, Object> deleteContactItem(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {
		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"contactCompanyId",
				"contactItemId"
		});
		String contactCompanyId = (String )paramsMap.remove("contactCompanyId");
		String contactItemId = (String )paramsMap.remove("contactItemId");
		
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		String companyId = (String )session.getAttribute("settlement");
		if(null==companyId || "".equals(companyId))
			throw new PromissionDenyException("Your were never join in any company");
		
		if(!companyService.isManager(companyId, userId))
			throw new PromissionDenyException("Not premitted");
		
		contactListService.removeContactItem(contactCompanyId, contactItemId);

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
		
	}

	@RequestMapping(value = "/addResource")
	@ResponseBody
	public Map<String, Object> addResource(HttpServletRequest request, HttpServletResponse response, @RequestParam Map<String, Object> paramsMap, @RequestParam(value = "file", required = true) MultipartFile file) {
		
		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"contactCompanyId",
				"fileKey"
		});
		String contactCompanyId = (String )paramsMap.remove("contactCompanyId");
		String fileKey = (String )paramsMap.remove("fileKey");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		
		String fileChildPath = RandomPath.getRelativePath() +"/" +RandomPath.getNewFileName(file);
		try {
			FileUtils.copyInputStreamToFile(file.getInputStream(), new File(CommonParameters.FILE_STORAGE_TOP_DIRECTORY, fileChildPath));
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
		
		String resourcePath = CommonParameters.FILE_DOWNLOAD_PREFIX +fileChildPath;
		
		contactListService.addResource(contactCompanyId, fileKey, resourcePath);

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("resourcePath", resourcePath);
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/removeResource")
	@ResponseBody
	public Map<String, Object> removeResource(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {
		
		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"contactCompanyId",
				"fileKey"
		});
		String contactCompanyId = (String )paramsMap.remove("contactCompanyId");
		String fileKey = (String )paramsMap.remove("fileKey");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		
		contactListService.removeResource(contactCompanyId, fileKey);

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/updateContactCompany")
	@ResponseBody
	public Map<String, Object> updateContactCompany(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {
		
		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"contactCompanyId",
		});
		String contactCompanyId = (String )paramsMap.remove("contactCompanyId");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");

		// #后期更新 联系公司添加多个字段
		paramsMap.remove("_id");
		paramsMap.remove("id");
		DBObject update = new BasicDBObject();
		update.putAll(paramsMap);
		DBCollection collection = mongoTemplate.getCollection(TableName.CONTACTS);
		collection.update(new BasicDBObject("_id", new ObjectId(contactCompanyId)),
				new BasicDBObject("$set", update)
				);

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/updateContactCompanyItem")
	@ResponseBody
	public Map<String, Object> updateContactCompanyItem(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {
		
		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"contactCompanyId",
				"contactItemId"
		});
		String contactCompanyId = (String )paramsMap.remove("contactCompanyId");
		String contactItemId = (String )paramsMap.remove("contactItemId");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");

		// #后期更新 联系公司添加多个字段
		paramsMap.remove("_id");
		paramsMap.remove("id");
		DBObject update = new BasicDBObject();
		update.putAll(paramsMap);
		DBCollection collection = mongoTemplate.getCollection(TableName.CONTACTS);
		collection.update(new BasicDBObject("_id", new ObjectId(contactCompanyId)),
				new BasicDBObject("$set", new BasicDBObject("contactItems." +contactItemId, update))
				);

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}
}
