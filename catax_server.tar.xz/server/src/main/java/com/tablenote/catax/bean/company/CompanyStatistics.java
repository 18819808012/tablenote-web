package com.tablenote.catax.bean.company;

import java.io.Serializable;

/**
 * 公司信息计数器
 * @author jiefzz
 *
 */
public class CompanyStatistics implements Serializable {

	public static final long serialVersionUID = 4469367766681459258L;

	private String id = null;
	
	/**
	 * 员工数量
	 */
	private Integer staffAmount = 0;
	
	/**
	 * 部门数量
	 */
	private Integer departmentAmount = 0;
	
	/**
	 * 模板数量
	 */
	private Integer templateAmount = 0;
	
	/**
	 * 产品数量
	 */
	private Integer priductionAmount = 0;
	
	/**
	 * 报价单数量
	 */
	private Integer QuotationAmount = 0;

	public CompanyStatistics() {}
	public CompanyStatistics(String id) { this.id = id; }
	
	public String getId() {
		return id;
	}
	
	/**
	 * 获取员工数量
	 * @return
	 */
	public Integer getStaffAmount() {
		return staffAmount;
	}

	/**
	 * 获取部门数量
	 * @return
	 */
	public Integer getDepartmentAmount() {
		return departmentAmount;
	}

	/**
	 * 获取模板数量
	 * @return
	 */
	public Integer getTemplateAmount() {
		return templateAmount;
	}

	/**
	 * 获取产品数量
	 * @return
	 */
	public Integer getPriductionAmount() {
		return priductionAmount;
	}

	/**
	 * 获取报价单数量
	 * @return
	 */
	public Integer getQuotationAmount() {
		return QuotationAmount;
	}
	
	/**
	 * 新增员工
	 */
	public void addNewStaff(){
		staffAmount++;
	}
}
