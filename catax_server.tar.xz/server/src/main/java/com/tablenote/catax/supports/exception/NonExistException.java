package com.tablenote.catax.supports.exception;

public class NonExistException extends RuntimeException {

	private static final long serialVersionUID = -1577880689896971224L;

	public NonExistException(String message) {
		super(String.format("%s is not found!!!", message));
	}

	public NonExistException(String message, Throwable cause) {
		super(String.format("%s is not found!!!", message), cause);
	}

}
