package com.tablenote.catax.service;

/**
 * 员工类型枚举值
 * @author kimffy
 *
 */
public final class Enum4CompanyEmployeeRole {

	public final static String MANAGER = "manager";
	
	public final static String STAFF = "staff";

}
