package com.tablenote.catax.supports.service;

public interface IExcelResolver {

}
