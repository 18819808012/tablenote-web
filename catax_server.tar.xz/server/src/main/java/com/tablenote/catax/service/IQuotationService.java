package com.tablenote.catax.service;

import java.util.Map;

public interface IQuotationService {

	/**
	 * 创建新的报价单
	 * @param companyId 创建的公司
	 * @param refCompanyId 援引的公司Id
	 * @param refDepartment 援引的部门
	 * @param productionIds 产品信息（可多个）
	 * @return 报价单Id
	 */
	public String createNewQuotation(String companyId, String refCompanyId, String refDepartment, String[] productionIds, Map<String, Object> extra);
	
	/**
	 * 往报价单里面添加新的产品
	 * @param quotationId
	 * @param productionId
	 * @return
	 */
	public void appendNewProduction(String quotationId, String productionId);
	
	/**
	 * 删除报价单里面的某个产品
	 * @param quotationId
	 * @param productionId
	 * @return
	 */
	public String deleteProduction(String quotationId, String productionId);
	
	/**
	 * 逻辑删除报价单
	 * @param quotationId
	 */
	public void deleteQuotation(String quotationId);
	
	/**
	 * 获取单个报价单内容
	 * @param quotationId
	 * @return
	 */
	public Map<String, Object> getQuotation(String quotationId);
	
	/**
	 * 获取报价单状态
	 * @param quotationId
	 * @return
	 */
	public String getQuotationStatus(String quotationId);

	/**
	 * 获取报价单状态
	 * @param quotationId
	 * @return
	 */
	public Boolean compareQuotationStatus(String quotationId, String[] status);
	
	/**
	 * 判断报价单当前是否可写
	 * @param quotationId
	 * @return
	 */
	public Boolean isQuotationWritable(String quotationId);
	
	/**
	 * 更新最后时间
	 * @param quotationId
	 */
	public void updateLastEditTime(String quotationId);
	
	/**
	 * 更新报价单的状态 锁定
	 * @param quotationId
	 */
	public void lockQuotation(String quotationId);
	
	/**
	 * 更新报价单的状态 请求更新
	 * @param quotationId
	 */
	public void unlockQuotation(String quotationId);
	
	public boolean isOwnerCompany(String quotationId, String companyId);
}
