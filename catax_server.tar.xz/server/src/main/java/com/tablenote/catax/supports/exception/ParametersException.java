package com.tablenote.catax.supports.exception;

public class ParametersException extends RuntimeException {

	private static final long serialVersionUID = -4265957861222156324L;

	public ParametersException(String message) {
		super(String.format("Invalid parameter: %s", message));
	}

	public ParametersException(String message, Throwable cause) {
		super(String.format("Invalid parameter: %s", message), cause);
	}

}
