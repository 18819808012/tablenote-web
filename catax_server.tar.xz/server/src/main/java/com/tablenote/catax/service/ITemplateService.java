package com.tablenote.catax.service;

import java.util.List;
import java.util.Map;

public interface ITemplateService {

	/**
	 * 创建新模板
	 * @param companyId
	 * @param department
	 * @param baseInfo
	 * @param content
	 * @return templateId 模板编号
	 */
	public String addNewTemplate(String companyId, List<String> departments, List<Object> baseInfo, Map<String, Object> content, String tmpName, String tmpInfo);
	
	/**
	 * 更新模板
	 * @param tempalteId
	 * @param baseInfo
	 * @param content
	 */
	public void updateTemplate(String tempalteId, List<Object> baseInfo, Map<String, Object> content, String tmpName, String tmpInfo);
	
	/**
	 * 获取某公司某部门下的所有模板
	 * @param companyId
	 * @param department
	 * @return
	 */
	public List getTemplates(String companyId, String department, int pageSize, int pageNumber);
	public List getTemplates(String companyId, String department, int pageSize);
	public List getTemplates(String companyId, String department);

	public List getTemplates(String companyId);
	
	/**
	 * 检查当前那模板是否可用
	 * @param tempalteId
	 * @return
	 */
	public boolean isTemplateAvaliable(String tempalteId);
	
	/**
	 * 删除模板
	 * @param tempalteId
	 */
	public void deleteTemplates(String tempalteId);
	
	/**
	 * 获取模板
	 * @param tempalteId
	 * @return
	 */
	public Map<String, Object> get(String tempalteId);
	
	public void updateTemplateDepartments(String tempalteId, List<String> departments);
	
}
