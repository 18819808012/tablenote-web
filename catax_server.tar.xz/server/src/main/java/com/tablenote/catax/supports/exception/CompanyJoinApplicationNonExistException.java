package com.tablenote.catax.supports.exception;

public class CompanyJoinApplicationNonExistException extends RuntimeException {
	
	private static final long serialVersionUID = 6125927237254581062L;

	public CompanyJoinApplicationNonExistException(String message) {
		super(String.format("Company join application[id=%s] is not exist!!!", message));
	}

	public CompanyJoinApplicationNonExistException(String message, Throwable cause) {
		super(String.format("Company join application[id=%s] is not exist!!!", message), cause);
	}

}
