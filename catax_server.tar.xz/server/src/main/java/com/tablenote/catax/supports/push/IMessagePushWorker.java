package com.tablenote.catax.supports.push;

/**
 * 类说明：为代理接口和服务接口提供相同的实现
 * 创建时间：2016年6月2日 下午9:24:24  <br>
 * @author JiefzzLon
*/
public interface IMessagePushWorker extends IPushWorker {
	
}
