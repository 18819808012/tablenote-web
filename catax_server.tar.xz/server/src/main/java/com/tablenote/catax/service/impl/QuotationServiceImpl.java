package com.tablenote.catax.service.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.tablenote.catax.base.TableName;
import com.tablenote.catax.service.IQuotationService;
import com.tablenote.catax.service.Status4Quotation;
import com.tablenote.catax.supports.exception.NonExistException;
import com.tablenote.catax.supports.exception.PromissionDenyException;

@Service
public class QuotationServiceImpl implements IQuotationService {
	
	@Resource
	MongoTemplate mongoTemplate;

	@Override
	public String createNewQuotation(String companyId, String refCompanyId, String refDepartment, String[] productionIds, Map<String, Object> extra) {
		ObjectId quotationId = new ObjectId();
		BasicDBObject newQuotation = new BasicDBObject("_id", quotationId)
				.append("id", quotationId.toHexString())
		;
		newQuotation.append("companyId", companyId);
		newQuotation.append("refCompanyId", refCompanyId);
		newQuotation.append("refDepartment", refDepartment);
		newQuotation.append("createTime", System.currentTimeMillis());
		newQuotation.append("lastUpdateTime", System.currentTimeMillis());
		newQuotation.append("status", Status4Quotation.NORMAL);
		if(null!=productionIds)
			newQuotation.append("productionIds", productionIds);
		else
			newQuotation.append("productionIds", new BasicDBList());
		newQuotation.append("extra", extra);
		DBCollection collection = mongoTemplate.getCollection(TableName.QUOTATION);
		collection.save(newQuotation);
		return quotationId.toHexString();
		
	}

	@Override
	public void appendNewProduction(String quotationId, String productionId) {
		BasicDBObject quotationCondition = new BasicDBObject("_id", new ObjectId(quotationId));
		DBCollection collection = mongoTemplate.getCollection(TableName.QUOTATION);
		DBObject quotationData = collection.findOne(quotationCondition);
		if(
				!compareStatus(quotationData.toMap(), Status4Quotation.NORMAL)
				&& !compareStatus(quotationData.toMap(), Status4Quotation.REQUIRE_UPDATE)
		)
			throw new PromissionDenyException(String.format("status error, status=%s", getStatus(quotationData.toMap())));
		collection.update(
				quotationCondition,
				new BasicDBObject("$push", new BasicDBObject("productionIds", productionId))
					.append("$set", new BasicDBObject("lastUpdateTime", System.currentTimeMillis()))
		);
		
		updateLastEditTime(quotationId);
		
	}

	@Override
	public String deleteProduction(String quotationId, String productionId) {
		BasicDBObject quotationCondition = new BasicDBObject("_id", new ObjectId(quotationId));	
		DBCollection collection = mongoTemplate.getCollection(TableName.QUOTATION);
		DBObject quotationData = collection.findOne(quotationCondition);
		if(
				!compareStatus(quotationData.toMap(), Status4Quotation.NORMAL)
				&& !compareStatus(quotationData.toMap(), Status4Quotation.REQUIRE_UPDATE)
		)
			throw new PromissionDenyException(String.format("status error, status=%s", getStatus(quotationData.toMap())));
		BasicDBList productionIds = (BasicDBList )quotationData.get("productionIds");
		int indexOf = productionIds.indexOf(productionId);
		if(-1!=indexOf) {
			productionIds.remove(indexOf);
			quotationData.put("lastUpdateTime", System.currentTimeMillis());
			collection.save(quotationData);
		}
		
		return ""+indexOf;
		
	}

	@Override
	public void deleteQuotation(String quotationId) {
		BasicDBObject quotationCondition = new BasicDBObject("_id", new ObjectId(quotationId));	
		DBCollection collection = mongoTemplate.getCollection(TableName.QUOTATION);
		DBObject quotationData = collection.findOne(quotationCondition);
		if(null==quotationData)
			throw new NonExistException(String.format("Quotation[quotationId=%s]", quotationId));
		collection.update(
				quotationCondition,
				new BasicDBObject("$set", new BasicDBObject("status", Status4Quotation.DROP))
					.append("$set", new BasicDBObject("lastUpdateTime", System.currentTimeMillis()))
		);
	}

	@Override
	public Map<String, Object> getQuotation(String quotationId) {
		BasicDBObject quotationCondition = new BasicDBObject("_id", new ObjectId(quotationId));	
		DBCollection collection = mongoTemplate.getCollection(TableName.QUOTATION);
		DBObject quotationData = collection.findOne(quotationCondition);
		if(null==quotationData)
			throw new NonExistException(String.format("Quotation[quotationId=%s]", quotationId));
		return quotationData.toMap();
	}

	
	@Override
	public String getQuotationStatus(String quotationId) {
		Map<String, Object> quotationData = getQuotation(quotationId);
		String status = (String )quotationData.get("status");
		return status;
	}
	

	@Override
	public Boolean compareQuotationStatus(String quotationId, String[] status) {
		BasicDBObject quotationCondition = new BasicDBObject("_id", new ObjectId(quotationId))
				.append("status", new BasicDBObject("$in", status))
		;
		DBCollection collection = mongoTemplate.getCollection(TableName.QUOTATION);
		DBObject quotationData = collection.findOne(quotationCondition);
		return null!=quotationData?true:false;
	}

	@Override
	public Boolean isQuotationWritable(String quotationId) {
		return compareQuotationStatus(quotationId, new String[]{Status4Quotation.NORMAL, Status4Quotation.REQUIRE_UPDATE});
	}

	/**
	 * 比较 报价单信息中的状态 与 给定的状态
	 * @param quotationData
	 * @param status
	 * @return
	 */
	private boolean compareStatus(Map<String, Object> quotationData, String status) {
		String sourceStatus = (String )quotationData.get("status");
		if(null==sourceStatus)
			throw new NonExistException(String.format("status of Quotation[quotationId=%s]", (String )quotationData.get("id")));
		return sourceStatus.equals(status);
	}

	/**
	 * 获取 报价单信息中的状态
	 * @param quotationData
	 * @param status
	 * @return
	 */
	private String getStatus(Map<String, Object> quotationData) {
		String sourceStatus = (String )quotationData.get("status");
		if(null==sourceStatus)
			throw new NonExistException(String.format("status of Quotation[quotationId=%s]", (String )quotationData.get("id")));
		return sourceStatus;
	}

	@Override
	public void updateLastEditTime(String quotationId) {

		BasicDBObject quotationCondition = new BasicDBObject("_id", new ObjectId(quotationId));
		DBCollection collection = mongoTemplate.getCollection(TableName.QUOTATION);
		collection.update(
				quotationCondition,
				new BasicDBObject("$set", new BasicDBObject("lastUpdateTime", System.currentTimeMillis()))
		);
		
	}

	@Override
	public void lockQuotation(String quotationId) {
		BasicDBObject quotationCondition = new BasicDBObject("_id", new ObjectId(quotationId));	
		DBCollection collection = mongoTemplate.getCollection(TableName.QUOTATION);
		DBObject quotationData = collection.findOne(quotationCondition);
		if(null==quotationData)
			throw new NonExistException(String.format("Quotation[quotationId=%s]", quotationId));
		collection.update(
				quotationCondition,
				new BasicDBObject("$set", new BasicDBObject("status", Status4Quotation.SENT))
		);
	}

	@Override
	public void unlockQuotation(String quotationId) {
		BasicDBObject quotationCondition = new BasicDBObject("_id", new ObjectId(quotationId));	
		DBCollection collection = mongoTemplate.getCollection(TableName.QUOTATION);
		DBObject quotationData = collection.findOne(quotationCondition);
		if(null==quotationData)
			throw new NonExistException(String.format("Quotation[quotationId=%s]", quotationId));
		collection.update(
				quotationCondition,
				new BasicDBObject("$set", new BasicDBObject("status", Status4Quotation.REQUIRE_UPDATE))
		);
	}

	@Override
	public boolean isOwnerCompany(String quotationId, String companyId) {

		BasicDBObject quotationCondition = new BasicDBObject("_id", new ObjectId(quotationId))
				.append("companyId", companyId);
		DBCollection collection = mongoTemplate.getCollection(TableName.QUOTATION);
		DBObject prevous = collection.findOne(quotationCondition);
		return null==prevous?false:true;
	}
}
