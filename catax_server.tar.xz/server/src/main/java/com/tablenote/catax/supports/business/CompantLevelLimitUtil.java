package com.tablenote.catax.supports.business;

import java.util.HashMap;
import java.util.Map;

import com.tablenote.catax.service.Enum4CompanyLevel;
import com.tablenote.catax.supports.exception.PromissionDenyException;

public class CompantLevelLimitUtil {

	public final static Map<String, Integer> StaffLimit = new HashMap<String, Integer>();
	static {
		StaffLimit.put(Enum4CompanyLevel.LEVEL1, 2);
		StaffLimit.put(Enum4CompanyLevel.LEVEL2, 10);
		StaffLimit.put(Enum4CompanyLevel.LEVEL3, 50);
	}
	
	/**
	 * 确认是否可加入新员工
	 * @param company
	 */
	public static void ensureCanAddNewStaff(Map<String, Object> company) {
		String level = (String )company.get("level");
		Map<String, Object> staff = (Map<String, Object> )company.get("staff");
		if(null!=staff && staff.size()>StaffLimit.get(level)) {
			throw new PromissionDenyException(String.format("Company level [%s] is not allowed to add more then [%d] member", level, StaffLimit.get(level)));
		}
	}
}
