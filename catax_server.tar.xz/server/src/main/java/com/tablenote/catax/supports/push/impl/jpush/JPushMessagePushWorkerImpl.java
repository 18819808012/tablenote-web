package com.tablenote.catax.supports.push.impl.jpush;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import com.tablenote.catax.supports.push.IMessagePushWorker;
import com.tablenote.catax.supports.push.ResultProcessor;

import cn.jiguang.common.resp.APIConnectionException;
import cn.jiguang.common.resp.APIRequestException;
import cn.jpush.api.JPushClient;
import cn.jpush.api.push.PushResult;
import cn.jpush.api.push.model.Options;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.audience.Audience;
import cn.jpush.api.push.model.notification.AndroidNotification;
import cn.jpush.api.push.model.notification.IosNotification;
import cn.jpush.api.push.model.notification.Notification;

@Service
public class JPushMessagePushWorkerImpl implements IMessagePushWorker {

	private static final String APP_KEP ="27e0b75c302eb2604a6e8eb6";
    private static final String MASTER_SECRET = "53c3eea58f2d68986fd32a4c";
    
    private JPushClient jPushClient = null;
    
    @PostConstruct
    public void init() {
    	jPushClient = new JPushClient(MASTER_SECRET, APP_KEP);
    }
    
	@Override
	public void notifyAlias(String alias, String description, String payload, Map<String, String> extra,
			ResultProcessor resultProcessor) {
		throw new RuntimeException(this.getClass().getName() +"#notifyAlias() is unimplemented!!!");
	}

	@Override
	public void notifyTags(String tags, String description, String payload, Map<String, String> extra,
			ResultProcessor resultProcessor) {

		cn.jpush.api.push.model.notification.IosNotification.Builder iosNotificationBuilder = IosNotification.newBuilder()
		.incrBadge(1).setSound("default").setAlert("CataX Notification");
		cn.jpush.api.push.model.notification.AndroidNotification.Builder androidNotificationBuilder = AndroidNotification.newBuilder()
		.setTitle(description).setAlert("CataX Notification");
		
		if(null != extra) {
			Set<Entry<String,String>> entrySet = extra.entrySet();
			for(Entry<String,String> entry:entrySet) {
				iosNotificationBuilder.addExtra(entry.getKey(), entry.getValue());
				androidNotificationBuilder.addExtra(entry.getKey(), entry.getValue());
			}
		}
		
		IosNotification iosNotification = iosNotificationBuilder.build();
		AndroidNotification androidNotification = androidNotificationBuilder.build();
		
		PushPayload pushPayload = 
				PushPayload.newBuilder()
		        .setPlatform(Platform.android_ios())
		        .setAudience(Audience.tag(tags))
		        .setNotification(
		        		Notification.newBuilder()
		        		.setAlert(payload)
		        		.addPlatformNotification(androidNotification)
		        		.addPlatformNotification(iosNotification)
		        		.build()
		        )
		        .setOptions(Options.newBuilder()  
                        .setApnsProduction(true)  
                        .build()
                )
		        .build();
		
		try {
			PushResult sendPush = jPushClient.sendPush(pushPayload);
			handleResult(resultProcessor, sendPush);
		} catch (APIConnectionException e) {
			e.printStackTrace();
		} catch (APIRequestException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void notifyById(String pushId, String description, String payload, Map<String, String> extra,
			ResultProcessor resultProcessor) {
		throw new RuntimeException(this.getClass().getName() +"#notifyById() is unimplemented!!!");
	}

	@Override
	public void broadcast(String description, String payload, Map<String, String> extra,
			ResultProcessor resultProcessor) {
		try {
			jPushClient.sendNotificationAll("测试：就是个广播通知！！！");
		} catch (APIConnectionException e) {
			e.printStackTrace();
		} catch (APIRequestException e) {
			e.printStackTrace();
		}
		throw new RuntimeException(this.getClass().getName() +"#broadcast() is unimplemented!!!");
	}

	@Override
	public void broadcastIOS(String description, String payload, Map<String, String> extra,
			ResultProcessor resultProcessor) {
		throw new RuntimeException(this.getClass().getName() +"#broadcastIOS() is unimplemented!!!");
	}

	@Override
	public void broadcastAndroid(String description, String payload, Map<String, String> extra,
			ResultProcessor resultProcessor) {
		throw new RuntimeException(this.getClass().getName() +"#broadcastAndroid() is unimplemented!!!");
	}

	private void handleResult(ResultProcessor resultProcessor, Object result) {
		if( null != resultProcessor )
			resultProcessor.process(result);
	}
}
