package com.tablenote.catax.service;

/**
 * 公司加入申请表的状态
 * @author kimffy
 *
 */
public final class Status4JoinApplication {

	/**
	 * 初始生成状态
	 */
	public final static String READY = "ready";
	
	/**
	 * 接受
	 */
	public final static String ACCEPT = "accept";
	
	/**
	 * 拒绝
	 */
	public final static String REJECT = "reject";

}
