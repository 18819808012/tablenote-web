package com.tablenote.catax.service;

import java.util.List;
import java.util.Map;

public interface IContactListService {

	public String createContactCompany(String companyId, String department, String contactCompanyName, Map<String, String> extra);
	
	public String addContactItem(String contactCompanyId, String name, Map<String, String> extraItems);
	
	public List getContacts(String companyId, String department);
	
	public void removeContactItem(String contactCompanyId, String contactItemId);
	
	public void removeContactCompany(String contactCompanyId);
	
	public void addResource(String contactCompanyId, String resourceKey, String resourcePath);
	
	public void removeResource(String contactCompanyId, String resourceKey);
}
