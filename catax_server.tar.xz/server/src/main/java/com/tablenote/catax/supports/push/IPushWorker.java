package com.tablenote.catax.supports.push;

import java.util.Map;

/**
 * 推送工作者接口
 * @author kimffy
 *
 */
public interface IPushWorker {

	/**
	 * 通过 别名 直接通知到用户
	 * @param userId
	 * @param description
	 * @param payload
	 * @param extra
	 */
	public void notifyAlias(String alias, String description, String payload, Map<String, String> extra, ResultProcessor resultProcessor);

	/**
	 * 通过 标签 直接通知到用户
	 * @param userId
	 * @param description
	 * @param payload
	 * @param extra
	 */
	public void notifyTags(String tags, String description, String payload, Map<String, String> extra, ResultProcessor resultProcessor);

	/**
	 * 通过 推送id 直接通知到用户
	 * @param userId
	 * @param description
	 * @param payload
	 * @param extra
	 */
	public void notifyById(String pushId, String description, String payload, Map<String, String> extra, ResultProcessor resultProcessor);
	
	/**
	 * 全面广播
	 * @param description
	 * @param payload
	 * @param extra
	 * @return
	 */
	public void broadcast(String description, String payload, Map<String, String> extra, ResultProcessor resultProcessor);
	
	/**
	 * 向所有IOS广播
	 * @param description
	 * @param payload
	 * @param extra
	 * @return
	 */
	public void broadcastIOS(String description, String payload, Map<String, String> extra, ResultProcessor resultProcessor);
	
	/**
	 * 向所有Android广播
	 * @param description
	 * @param payload
	 * @param extra
	 * @return
	 */
	public void broadcastAndroid(String description, String payload, Map<String, String> extra, ResultProcessor resultProcessor);
	
}
