package com.tablenote.catax.controller.base;

import java.util.Enumeration;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tablenote.catax.service.IUserService;
import com.tablenote.catax.supports.response.Formatter;

public class BaseController {

	@Resource
	IUserService userService;
	
	@ExceptionHandler
	@ResponseBody
    public Map<String, Object> exceptionProcessor(HttpServletRequest request, Exception ex) {
		ex.printStackTrace();
        request.setAttribute("ex", ex);
        return Formatter.format(1l, ex.getMessage(), ex.getClass().getSimpleName());
    }
	
    @ModelAttribute  
    public void checkSession(HttpServletRequest request, HttpServletResponse response) {
    	HttpSession session = request.getSession();
    	
    	Enumeration<String> attributeNames = session.getAttributeNames();
    	while(attributeNames.hasMoreElements()) {
    		String nextElement = attributeNames.nextElement();
    		System.out.println(String.format("Session: %s = %s", nextElement, session.getAttribute(nextElement)));
    	}

		String userId = (String )session.getAttribute("userId");
		if(null!=userId && !"".equals(userId) ) {
	    	Object settlement = session.getAttribute("settlement");
	    	if(null!=settlement && !"".equals(settlement)) {
	    		String companyId = userService.getSettlementCompanyId(userId);
	    		session.setAttribute("settlement", companyId);
	    	}
		}
    }
}
