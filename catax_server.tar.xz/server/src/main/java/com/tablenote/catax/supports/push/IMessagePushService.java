package com.tablenote.catax.supports.push;

/**
 * 推送服务的实现类，如果在异步过程，可以直接执行此类推送消息
 * @author JiefzzLon
 *
 */
public interface IMessagePushService extends IPushWorker {
	
	/**
	 * 取实际工作对象
	 */
	public IPushWorker getActuallyWorker();
	
}
