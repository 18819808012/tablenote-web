package com.tablenote.catax.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.tablenote.catax.service.ICompanyService;
import com.tablenote.catax.service.IProductionService;
import com.tablenote.catax.service.IQuotationService;
import com.tablenote.catax.service.ITemplateService;
import com.tablenote.catax.service.IUserService;
import com.tablenote.catax.supports.exception.PromissionDenyException;
import com.tablenote.catax.supports.helper.RequestEnsure;

@Controller
@RequestMapping(value = "/support")
public class SupportController {

	@Resource
	IUserService userService;

	@Resource
	ICompanyService companyService;

	@Resource
	ITemplateService templateService;

	@Resource
	IQuotationService quotationService;

	@Resource
	IProductionService productionService;

	@RequestMapping(value = "/batchExcel")
	@ResponseBody
	public Map<String, Object> create(HttpServletRequest request, HttpServletResponse response,
			@RequestParam Map<String, Object> paramsMap,
			@RequestParam(value = "file", required = true) MultipartFile file) throws IOException {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] {
				"quotationId"
		});
		String quotationId = (String) paramsMap.remove("quotationId");

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String) session.getAttribute("userId");
		if (!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String) session.getAttribute("settlement");

		if (!quotationService.isOwnerCompany(quotationId, companyId))
			throw new PromissionDenyException("You are not this company's staff");
		if (!quotationService.isQuotationWritable(quotationId))
			throw new PromissionDenyException("Quotation is Sent, can not update now");

		Map<String, Object> quotation = quotationService.getQuotation(quotationId);
		String refCompanyId = (String )quotation.get("refCompanyId");
		String refDepartment = (String )quotation.get("refDepartment");
		List<Map<String, Object>> templates = templateService.getTemplates(refCompanyId, refDepartment);
		// 忘记是什么时候更改的规则，规则更改为一个部门对应一个模板，一个模板对应多个部门
		Map<String, Object> template = templates.get(0);

		String templateId = (String )template.get("id");
		List<String> baseInfo = (List<String> )template.get("baseInfo");
		Map<String, Object> content = (Map<String, Object> )template.get("content");
		
		InputStream inputStream = file.getInputStream();
		String fileName = file.getOriginalFilename();

		// 判断是否是excel2007格式
		boolean isE2007 = false;
		if (fileName.endsWith("xlsx"))
			isE2007 = true;

		// 建立输入流
		//InputStream input = new FileInputStream(fileName);
		InputStream input = inputStream;
		Workbook wb = null;
		// 根据文件格式(2003或者2007)来初始化
		if (isE2007)
			wb = new XSSFWorkbook(input);
		else
			wb = new HSSFWorkbook(input);
		// 获得第一个表单
		Sheet sheet = wb.getSheetAt(0);
		// 获得第一个表单的迭代器
		Iterator<Row> rows = sheet.rowIterator();
		
		// 准备好 excel 的key
		Map<String, Integer> excelKeyset = new HashMap<String, Integer>();
		
		if(rows.hasNext()) {
			Row row = rows.next();
			Iterator<Cell> cells = row.cellIterator();
			
			int i=0;
			while(cells.hasNext()) {
				Cell cell = cells.next();
				if(cell.getCellTypeEnum()!=CellType.STRING)
					throw new RuntimeException("Invalidation excel format!!!");
				excelKeyset.put(cell.getStringCellValue(), i);
				i++;
			}
			
		} else
			throw new RuntimeException("Empty excel!!!");

		while (rows.hasNext()) {
			
			Map<String, Object> productionExtra = new HashMap<String, Object>();
			
			Row row = rows.next();
			Iterator<Cell> cells = row.cellIterator();
			int rowNum = row.getRowNum();

			for(String baseInfoKey:baseInfo) {
				if(!excelKeyset.containsKey(baseInfoKey))
					continue;
				System.out.println(baseInfoKey);
				String cellValueOnRow = getCellValueOnRow(row, excelKeyset.get(baseInfoKey));
				productionExtra.put(baseInfoKey, cellValueOnRow);
			}
			
			Set<Entry<String, Object>> entrySet = content.entrySet();
			for(Entry<String, Object> entry:entrySet) {
				
				List<Object> contentTopList = new ArrayList<Object>();
				
				List<String> contentSet = (List<String> )entry.getValue();
				for(String childKey:contentSet) {
					if(!excelKeyset.containsKey(childKey))
						continue;
					String cellValueOnRow = getCellValueOnRow(row, excelKeyset.get(childKey));
					HashMap<String, Object> contentChildTuple = new HashMap<String, Object>();
					contentChildTuple.put("key", childKey);
					contentChildTuple.put("value", cellValueOnRow);
					System.out.println(String.format("Debug: %s=%s", childKey, cellValueOnRow));
					contentTopList.add(contentChildTuple);
				}
				
				productionExtra.put(entry.getKey(), contentTopList);
			}
			
			String productionId = productionService.createNewProduction(companyId, quotationId, refCompanyId, refDepartment, productionExtra);
			
			quotationService.appendNewProduction(quotationId, productionId);

		}

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("productionId", "");
		resultMap.put("success", "");
		return resultMap;
	}

	private String getCellValueOnRow(Row row, int column) {
		Cell cell = row.getCell(column);
		if (null == cell)
			return "";
		String cellStringValue;
		CellType cellTypeEnum = cell.getCellTypeEnum();
		switch (cellTypeEnum) {
		case STRING:
			cellStringValue = cell.getStringCellValue();
			break;
		case NUMERIC:
			double numericCellValue = cell.getNumericCellValue();
			cellStringValue = "" + numericCellValue;
			break;
		case FORMULA:
			try {
				cellStringValue = String.valueOf(cell.getNumericCellValue());
			} catch (IllegalStateException e) {
				cellStringValue = String.valueOf(cell.getRichStringCellValue());
			}
			break;
		case BLANK:
			cellStringValue = "";
			break;
		default:
			throw new RuntimeException("Invalidation excel format!!! column=" + column);
		}
		return cellStringValue;
	}
}
