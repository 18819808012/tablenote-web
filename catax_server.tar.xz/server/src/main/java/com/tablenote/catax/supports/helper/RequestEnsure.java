package com.tablenote.catax.supports.helper;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.bson.types.ObjectId;

import com.tablenote.catax.service.IUserService;
import com.tablenote.catax.supports.exception.NonAcceptRequestException;
import com.tablenote.catax.supports.exception.PromissionDenyException;
import com.tablenote.catax.supports.exception.SessionTimeoutException;

/**
 * 一些对请求校验的方法
 * @author kimffy
 *
 */
public final class RequestEnsure {
	
	/**
	 * 确定当前会话是个登陆会话
	 * @param request
	 */
	public static void ensureIsLoginSession(HttpServletRequest request) {
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(null==userId || !ObjectId.isValid(userId))
			throw new SessionTimeoutException();
	}
	
	/**
	 * 确定当前请求中有指明需要的字段
	 * @param paramsMap
	 * @param constraintKeys
	 */
	public static void ensureKeysIsProvided(Map<String, Object> paramsMap, String[] constraintKeys) {
		for( String key : constraintKeys ){
			if(!paramsMap.containsKey(key))
				throw new NonAcceptRequestException(key);
		}
	}

	/**
	 * 确定当前会话会话的用户已经有工作公司记录
	 * @param request
	 * @param userService 用户服务类
	 */
	public static void ensureIsSessionUserHasCompany(HttpServletRequest request, IUserService userService) {
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
	}
}
