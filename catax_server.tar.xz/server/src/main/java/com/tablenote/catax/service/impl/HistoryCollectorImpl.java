package com.tablenote.catax.service.impl;

import java.util.Set;

import javax.annotation.Resource;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.tablenote.catax.base.TableName;
import com.tablenote.catax.service.IHistoryCollector;

/**
 * @deprecated
 * @author kimffy
 *
 */
@Service
public class HistoryCollectorImpl implements IHistoryCollector {

	@Resource
	MongoTemplate mongoTemplate;
	
	@Override
	public void addQuotationHistoryMark(String companyId, String target, String key) {
		setHistoryMark(companyId, QUOTATION, target, key);
	}

	@Override
	public void addProductionHistoryMark(String companyId, String target, String key) {
		setHistoryMark(companyId, PRODUCTION, target, key);
	}

	@Override
	public Set<String> getHistoryMark(String companyId, String type, String target) {

		DBCollection collection = mongoTemplate.getCollection(TableName.HISTORY_MARK);
		ObjectId companyObjectId = new ObjectId(companyId);
		DBObject conditions = new BasicDBObject("_id", companyObjectId);
		
		DBObject result = collection.findOne(conditions);
		if(result.containsField(type)) {
			DBObject typeData = (DBObject )result.get(type);
			if(typeData.containsField(target)) {
				DBObject targetData = (DBObject )typeData.get(target);
				Set<String> keySet = targetData.keySet();
				return keySet;
			}
		}
		return null;
	}
	
	private void setHistoryMark(String companyId, String type, String target, String key) {
		DBCollection collection = mongoTemplate.getCollection(TableName.HISTORY_MARK);
		ObjectId companyObjectId = new ObjectId(companyId);
		DBObject conditions = new BasicDBObject("_id", companyObjectId);
		
		DBObject historyData = new BasicDBObject(
						"$set",
						new BasicDBObject("id", companyId)
							.append(type +"." +target +"." +key, Long.valueOf(System.currentTimeMillis()))
				)
		;
		
		collection.update(conditions, historyData, true, false);
	}

}
