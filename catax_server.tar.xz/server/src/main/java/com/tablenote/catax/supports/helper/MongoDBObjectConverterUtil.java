package com.tablenote.catax.supports.helper;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.jiefzz.ejoker.utils.relationship.RelationshipTreeUtil;
import com.jiefzz.ejoker.utils.relationship.RelationshipTreeUtilCallbackInterface;
import com.jiefzz.ejoker.utils.relationship.RevertRelationshipTreeDisassemblyInterface;
import com.jiefzz.ejoker.utils.relationship.RevertRelationshipTreeUitl;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

/**
 * Mongo BDObject 对象与java bean 的转换类
 * @author JiefzzLon
 *
 */
public class MongoDBObjectConverterUtil {
	/**
	 * 把目标对象转换成mongo的BDObject
	 * @param target
	 * @return
	 * do:
	 */
	public static BasicDBObject convert(final Object target){
		return relationshipTreeUtil.getTreeStructureMap(target);
	}

	/**
	 * 给定Mongo的DBObject，生成java对象
	 * @param clazz
	 * @param queryData
	 * @return
	 * do:
	 */
	public static <T> T revert(Class<T> clazz, DBObject queryData) {
		return revertRelationshipTreeUitl.revert(clazz, (BasicDBObject )queryData);
	}

	/**
	 * 结构化构造MongoDocument对象工具
	 */
	private static final RelationshipTreeUtil<BasicDBObject, BasicDBList> relationshipTreeUtil =
			new RelationshipTreeUtil<BasicDBObject, BasicDBList>(new RelationshipTreeUtilCallbackInterface<BasicDBObject, BasicDBList>(){

				@Override
				public BasicDBObject createNode() {
					return new BasicDBObject();
				}

				@Override
				public BasicDBList createValueSet() {
					return new BasicDBList();
				}

				@Override
				public boolean isHas(BasicDBObject targetNode, String key) {
					return targetNode.containsField(key);
				}

				@Override
				public void addToValueSet(BasicDBList valueSet, Object child) {
					valueSet.add(child);
				}

				@Override
				public void addToKeyValueSet(BasicDBObject keyValueSet, Object child, String key) {
					keyValueSet.append(key, child);
				}

				@Override
				public void merge(BasicDBObject targetNode, BasicDBObject tempNode) {
					targetNode.putAll(tempNode.toMap());
				}

				@Override
				public Object getOne(BasicDBObject targetNode, String key) {
					return targetNode.get(key);
				}
				
			});


	private static final RevertRelationshipTreeUitl<BasicDBObject, BasicDBList> revertRelationshipTreeUitl =
			new RevertRelationshipTreeUitl<BasicDBObject, BasicDBList>(new RevertRelationshipTreeDisassemblyInterface<BasicDBObject, BasicDBList>() {

				@Override
				public BasicDBObject getChildKVP(BasicDBObject source, String key) {
					return (BasicDBObject )source.get(key);
				}

				@Override
				public BasicDBObject getChildKVP(BasicDBList source, int index) {
					return (BasicDBObject )source.get(index);
				}

				@Override
				public BasicDBList getChildVP(BasicDBObject source, String key) {
					return (BasicDBList) source.get(key);
				}

				@Override
				public BasicDBList getChildVP(BasicDBList source, int index) {
					return (BasicDBList) source.get(index);
				}

				@Override
				public Object getValue(BasicDBObject source, String key) {
					return source.get(key);
				}

				@Override
				public Object getValue(BasicDBList source, int index) {
					return source.get(index);
				}

				@Override
				public int getVPSize(BasicDBList source) {
					return source.size();
				}

				@Override
				public Map convertNodeAsMap(BasicDBObject source) {
					return (Map )source;
				}

				@Override
				public Set convertNodeAsSet(BasicDBList source) {
					throw new RuntimeException("Unuse!!!");
				}

				@Override
				public List convertNodeAsList(BasicDBList source) {
					return source;
				}
				
			});
	
}