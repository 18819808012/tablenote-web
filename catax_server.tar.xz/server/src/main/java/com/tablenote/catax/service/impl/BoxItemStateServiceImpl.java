package com.tablenote.catax.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.tablenote.catax.base.TableName;
import com.tablenote.catax.service.IBoxItemStateService;

@Service
public class BoxItemStateServiceImpl implements IBoxItemStateService {

	@Resource
	MongoTemplate mongoTemplate;
	
	@Override
	public void markRead(String userId, String boxItemId) {
		ObjectId userObjectId = new ObjectId(userId);
		DBCollection collection = mongoTemplate.getCollection(TableName.READ_STATUS);
		BasicDBObject condition = new BasicDBObject("_id", userObjectId);
		BasicDBObject updateData = new BasicDBObject(
				"$set",
				new BasicDBObject("id", userId)
					.append(TOP_KEY +"." +boxItemId, Long.valueOf(System.currentTimeMillis()))
		);
		collection.update(condition, updateData, true, false);
	}

	@Override
	public List<String> getBoxItemIdsHasBeenRead(String userId) {

		ArrayList<String> al = new ArrayList<String>();
		
		ObjectId userObjectId = new ObjectId(userId);
		DBCollection collection = mongoTemplate.getCollection(TableName.READ_STATUS);
		BasicDBObject condition = new BasicDBObject("_id", userObjectId);
		DBObject result = collection.findOne(condition);
		if(null==result)
			return al;
		DBObject bIds = (DBObject )result.get(TOP_KEY);
		Set<String> keySet = bIds.keySet();
		if(0<keySet.size()){
			al.addAll(keySet);
			return al;
		} else 
			return al;
	}

	@Override
	public boolean isRead(String userId, String boxItemId) {
		DBCollection collection = mongoTemplate.getCollection(TableName.READ_STATUS);
		BasicDBObject condition = new BasicDBObject("_id", new ObjectId(userId))
					.append(TOP_KEY +"." +boxItemId, new BasicDBObject("$exists", true))
		;
		return null==collection.findOne(condition)?false:true;
	}

}
