package com.tablenote.catax.service;

/**
 * quotation的业务关联状态
 * @author kimffy
 *
 */
public final class Status4QuotationExtra {

	/**
	 * 挂起等待
	 */
	public final static String PENDING = "pending";

	/**
	 * 报价单被接受了
	 */
	public final static String APPROVE = "approve";

}
