package com.tablenote.catax.service;

/**
 * 信箱条目的类型
 * @author kimffy
 *
 */
public class Type4BoxItem {

	/**
	 * 入口邀请
	 */
	public final static String ENTRANCE = "entrance";

	/**
	 * 普通条目
	 */
	public final static String NORMAL = "normal";
	
	/**
	 * 请求更新的条目
	 */
	public final static String REQUIRE_UPDATE = "requireUpdate";

	/**
	 * 已更新
	 */
	public final static String UPDATED = "updated";
	
}
