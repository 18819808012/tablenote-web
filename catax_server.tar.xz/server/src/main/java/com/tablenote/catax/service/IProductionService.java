package com.tablenote.catax.service;

import java.util.List;
import java.util.Map;

public interface IProductionService {

	/**
	 * 发布产品
	 * @param companyId
	 * @param quotationId
	 * @param refCompanyId
	 * @param refDepartment
	 * @param extra
	 * @return
	 */
	public String createNewProduction(String companyId, String quotationId, String refCompanyId, String refDepartment, Map<String, Object> extra);
	
	/**
	 * 发布产品 带分类的
	 * @param companyId
	 * @param quotationId
	 * @param refCompanyId
	 * @param refDepartment
	 * @param categories
	 * @param extra
	 * @return
	 */
	public String createNewProduction(String companyId, String quotationId, String refCompanyId, String refDepartment, List<String> categories, Map<String, Object> extra);
	
	/**
	 * 更新单品产品
	 * @param productionId
	 * @param updateExtra
	 */
	public void update(String productionId, Map<String, Object> updateExtra);

	/**
	 * 更新报价类型状态
	 * @param productionId
	 * @param type
	 */
	public void updateType(String productionId, String type);
	
	/**
	 * 删除单品产品
	 * @param productionId
	 */
	public void delete(String productionId);
	
	/**
	 * 获取单品产品
	 * @param productionId
	 */
	public Map<String, Object> get(String productionId);

	/**
	 * 获取一组产品
	 * @param productionId
	 */
	public List<Map<String, Object>> groupGet(String[] productionIds);
	/**
	 * 获取一组产品
	 * @param productionId
	 */
	public List<Map<String, Object>> groupGet(List<String> productionIds);

	/**
	 * 添加图片
	 * @param productionId
	 * @param idx
	 * @param resourceUri
	 */
	public void addImage(String productionId, int idx, String resourceUri);
	
	/**
	 * 删除图片
	 * @param productionId
	 * @param idx
	 */
	public void removeImage(String productionId, int idx);

	/**
	 * 判断产品当前是否可写
	 * @param quotationId
	 * @return
	 */
	public Boolean isProductionWritable(String productionId);
}
