package com.tablenote.catax.service.impl;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.annotation.Resource;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.tablenote.catax.base.PasswordUtils;
import com.tablenote.catax.base.TableName;
import com.tablenote.catax.service.IUserService;
import com.tablenote.catax.supports.exception.AccountAlreadyExistException;
import com.tablenote.catax.supports.exception.AccountAuthenticationFaild;
import com.tablenote.catax.supports.exception.AccountNonExistException;
import com.tablenote.catax.supports.mail.TemplateProvider;
import com.tablenote.catax.supports.service.IEMailService;

@Service
public class UserServiceImpl implements IUserService {

	@Resource
	MongoTemplate mongoTemplate;
	
	@Resource
	IEMailService eMailService;
	
	@Override
	public String registerNewUser(String email, String password, String user, String isSeller, Map<String, Object> extra) {
		
		DBCollection userCollection = mongoTemplate.getCollection(TableName.USER);
		
		DBObject prevous = userCollection.findOne(new BasicDBObject("email", email));
		
		if( null!=prevous )
			throw new AccountAlreadyExistException(email);
		
		ObjectId objectId = new ObjectId();
		BasicDBObject basicDBObject = new BasicDBObject("_id", objectId).append("id", objectId.toHexString());
		
		basicDBObject.append("email", email);
		basicDBObject.append("password", password);
		basicDBObject.append("user", user);
		basicDBObject.append("extra", extra);
		basicDBObject.append("settlement", null);
		basicDBObject.append("seller", isSeller);
		
		String validCodeForEmail = PasswordUtils.makeSHA1(email +objectId.toHexString() +extra.toString()).substring(9, 15);
		basicDBObject.append("valid",
				new BasicDBObject("emailState", false)
				.append("emailCode", validCodeForEmail)
				.append("emailCodeCreateTime", System.currentTimeMillis())
		);
		userCollection.save(basicDBObject);
		
		eMailService.sendEmail(email, TemplateProvider.getMailContentEn(validCodeForEmail, objectId.toHexString()));
		
		return objectId.toHexString();
	}

	@Override
	public void validEmail(String userId, String code) {
		ObjectId userObjectId = new ObjectId(userId);
		DBCollection userCollection = mongoTemplate.getCollection(TableName.USER);
		userCollection.update(
				new BasicDBObject("_id", userObjectId).append("valid.emailCode", code),
				new BasicDBObject("$set", new BasicDBObject("valid.emailState", true))
		);
	}
	
	@Override
	public Map<String, Object> login(String email, String password, String nextUrl, String deviceId) {

		DBCollection userCollection = mongoTemplate.getCollection(TableName.USER);
		DBObject prevous = userCollection.findOne(new BasicDBObject("email", email));
		
		if( null==prevous )
			throw new AccountNonExistException(email);
		
		Object object = prevous.get("password");
		
		if( !password.equals((String )object) )
			throw new AccountAuthenticationFaild(email);
		
		return prevous.toMap();
	}

	@Override
	public String getUserIdWithEmail(String email) {
		DBCollection userCollection = mongoTemplate.getCollection(TableName.USER);
		DBObject userData = userCollection.findOne(new BasicDBObject("email", email));
		if(null==userData)
			return null;
		return (String )userData.get("id");
	}
	
	@Override
	public Map<String, Object> detail(String userId) {
		ObjectId userObjectId = new ObjectId(userId);
		DBCollection userCollection = mongoTemplate.getCollection(TableName.USER);
		DBObject userData = userCollection.findOne(new BasicDBObject("_id", userObjectId));
		if( null==userData )
			throw new AccountNonExistException(userId);
		return userData.toMap();
		
	}

	@Override
	public boolean hasSettlement(String userId) {
		ObjectId userObjectId = new ObjectId(userId);
		DBCollection userCollection = mongoTemplate.getCollection(TableName.USER);
		DBObject userData = userCollection.findOne(new BasicDBObject("_id", userObjectId));
		if( null==userData )
			throw new AccountNonExistException(userId);
		return userData.containsField("settlement") && null!=userData.get("settlement");
	}

	@Override
	public String getSettlementCompanyId(String userId) {
		ObjectId userObjectId = new ObjectId(userId);
		DBCollection userCollection = mongoTemplate.getCollection(TableName.USER);
		DBObject userData = userCollection.findOne(new BasicDBObject("_id", userObjectId));
		if( null==userData )
			throw new AccountNonExistException(userId);
		Object obj;
		if( null==(obj = userData.get("settlement")) )
			return "";
		return ((ObjectId )obj).toHexString();
	}

	@Override
	public void setSettlement(String userId, String companyId) {
		ObjectId userObjectId = new ObjectId(userId);
		ObjectId companyObjectId = new ObjectId(companyId);
		DBCollection userCollection = mongoTemplate.getCollection(TableName.USER);
		userCollection.update(new BasicDBObject("_id", userObjectId), new BasicDBObject("$set", new BasicDBObject("settlement", companyObjectId)));
	}

	@Override
	public Map<String, Object> getLastLoginInfo(String userId) {
		Map<String, Object> detail = detail(userId);
		if(detail.containsKey("lastLoginInfo")) {
			Map<String, Object> lastLoginInfo = (Map<String, Object> )detail.get("lastLoginInfo");
			if(null!=lastLoginInfo)
				return lastLoginInfo;
		}
		return null;
	}

	@Override
	public void addLastLoginInfo(String userId, String deviceId, Map<String, Object> loginDeviceInfo) {
		ObjectId userObjectId = new ObjectId(userId);
		DBCollection userCollection = mongoTemplate.getCollection(TableName.USER);
		userCollection.update(
				new BasicDBObject("_id", userObjectId),
				new BasicDBObject("$set", new BasicDBObject("lastLoginInfo." +deviceId, loginDeviceInfo))
		);
	}

	@Override
	public boolean removeLastLoginInfo(String userId, String deviceId) {
		ObjectId userObjectId = new ObjectId(userId);
		DBCollection userCollection = mongoTemplate.getCollection(TableName.USER);
		DBObject userData = userCollection.findOne(new BasicDBObject("_id", userObjectId));
		DBObject lastLoginInfo = (DBObject )userData.get("lastLoginInfo");
		if(null==lastLoginInfo || !lastLoginInfo.containsField(deviceId))
			return false;
		else {
			lastLoginInfo.removeField(deviceId);
			userCollection.save(userData);
			return true;
		}
	}
	
	@Override
	public void setAvatar(String userId, String avatarPath) {
		ObjectId userObjectId = new ObjectId(userId);
		DBCollection userCollection = mongoTemplate.getCollection(TableName.USER);
		userCollection.update(
				new BasicDBObject("_id", userObjectId),
				new BasicDBObject("$set", new BasicDBObject("avatar", avatarPath))
		);
	}

	@Override
	public void updateProfile(String userId, Map<String, Object> extra) {

		ObjectId userObjectId = new ObjectId(userId);
		DBCollection userCollection = mongoTemplate.getCollection(TableName.USER);
		DBObject userData = userCollection.findOne(new BasicDBObject("_id", userObjectId));
		
		DBObject userExtra = (DBObject )userData.get("extra");
		if(null==userExtra)
			userData.put("extra", extra);
		else {
			Set<Entry<String,Object>> entrySet = extra.entrySet();
			for(Entry<String,Object> entry:entrySet) {
				userExtra.put(entry.getKey(), entry.getValue());
			}
		}

		userCollection.save(userData);
	}

	@Override
	public String createResetPasswordToken(String userId) {
		
		String randomString = PasswordUtils.makeSHA1("" +System.currentTimeMillis() +"what's the fuck? This is a random key here." +userId);
		String token = randomString.substring(2, 8);
		
		ObjectId userObjectId = new ObjectId(userId);
		DBCollection userCollection = mongoTemplate.getCollection(TableName.USER);
		userCollection.update(
				new BasicDBObject("_id", userObjectId),
				new BasicDBObject("$set", new BasicDBObject("rpwt", token).append("rpwtime", Long.valueOf(System.currentTimeMillis())))
		);
		
		return token;
	}

	@Override
	public void updatePassword(String userId, String newPassword) {

		ObjectId userObjectId = new ObjectId(userId);
		DBCollection userCollection = mongoTemplate.getCollection(TableName.USER);
		userCollection.update(
				new BasicDBObject("_id", userObjectId),
				new BasicDBObject("$set", new BasicDBObject("password", newPassword).append("rpwtime", Long.valueOf(1l)))
		);
	}
}
