package com.tablenote.catax.service;

import java.util.Map;

public interface IUserService {

	/**
	 * 注册新用户
	 * @param email
	 * @param password
	 * @param userName
	 * @param extra 可以为null
	 * @return userId
	 */
	public String registerNewUser(String email, String password, String user, String isSeller, Map<String, Object> extra);
	
	/**
	 * 验证用户（邮件）
	 * @param userId
	 * @param code
	 */
	public void validEmail(String userId, String code);
	/**
	 * 用用户email换取userId
	 * @param email
	 * @return
	 */
	public String getUserIdWithEmail(String email);
	
	/**
	 * 登陆
	 * @param email
	 * @param password
	 * @param nextUrl
	 * @param deviceId
	 * @return 用户信息
	 */
	public Map<String, Object> login(String email, String password, String nextUrl, String deviceId);
	
	/**
	 * 取出用户详细资料
	 * @param userId 用户Id
	 * @return
	 */
	public Map<String, Object> detail(String userId);
	
	/**
	 * 检查其是否为一个没有归宿的用户
	 * @return
	 */
	public boolean hasSettlement(String userId);
	
	/**
	 * 获取其归属的公司的companyId
	 * @return
	 */
	public String getSettlementCompanyId(String userId);
	
	/**
	 * 设置归属公司
	 * @param companyId
	 */
	public void setSettlement(String userId, String companyId);
	
	/**
	 * 更新/存储登陆信息
	 * @param loginDeviceInfo
	 */
	public void addLastLoginInfo(String userId, String deviceId, Map<String, Object> loginDeviceInfo);
	
	/**
	 * 获取最近登陆信息
	 * @param userId
	 * @return
	 */
	public Map<String, Object> getLastLoginInfo(String userId);
	
	/**
	 * 移除登陆设备信息
	 * @param userId
	 * @param deviceId
	 * @return
	 */
	public boolean removeLastLoginInfo(String userId, String deviceId);

	/**
	 * 设置头像
	 * @param userId
	 * @param avatarPath
	 */
	public void setAvatar(String userId, String avatarPath);
	
	/**
	 * 更新个人信息
	 * @param userId
	 * @param extra
	 */
	public void updateProfile(String userId, Map<String, Object> extra);

	/**
	 * 更新密码
	 * @param userId
	 * @param newPassword
	 */
	public void updatePassword(String userId, String newPassword);
	
	/**
	 * 创建重置密码的令牌
	 * @param userId
	 * @return
	 */
	public String createResetPasswordToken(String userId);
	
}
