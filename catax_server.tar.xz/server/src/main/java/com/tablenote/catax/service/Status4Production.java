package com.tablenote.catax.service;

/**
 * 产品状态
 * @author kimffy
 *
 */
public final class Status4Production {
	
	/**
	 * 正常填写
	 */
	public final static String NOTMAL = "normal";
	
	/**
	 * 删除
	 */
	public final static String DROP = "drop";
}