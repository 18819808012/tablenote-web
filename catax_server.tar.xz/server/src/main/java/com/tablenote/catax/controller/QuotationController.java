package com.tablenote.catax.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.tablenote.catax.base.TableName;
import com.tablenote.catax.controller.base.BaseController;
import com.tablenote.catax.service.IBoxService;
import com.tablenote.catax.service.ICompanyService;
import com.tablenote.catax.service.IHistoryCollector;
import com.tablenote.catax.service.IQuotationService;
import com.tablenote.catax.service.ITemplateService;
import com.tablenote.catax.service.IUserService;
import com.tablenote.catax.service.Status4BoxItem;
import com.tablenote.catax.service.Status4Production;
import com.tablenote.catax.supports.exception.ParametersException;
import com.tablenote.catax.supports.exception.PromissionDenyException;
import com.tablenote.catax.supports.helper.RequestEnsure;

@Controller
@RequestMapping(value = "/quotation")
public class QuotationController extends BaseController {

	@Resource
	MongoTemplate mongoTemplate;
	
	@Resource
	ICompanyService companyService;

	@Resource
	IUserService userService;

	@Resource
	ITemplateService templateService;
	
	@Resource
	IQuotationService quotationService;

	@Resource
	IBoxService boxService;
	
	@RequestMapping(value = "/create")
	@ResponseBody
	public Map<String, Object> create(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"companyId",
				"department",
		});
		String refCompanyId = (String )paramsMap.remove("companyId");
		String refDepartment = (String )paramsMap.remove("department");
		
		Boolean unCreateDraft = (Boolean )paramsMap.remove("unCreateDraft");
		if(null==unCreateDraft) unCreateDraft = false;
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		String draftBoxItemId=null;
		String quotationId = quotationService.createNewQuotation(companyId, refCompanyId, refDepartment, null, paramsMap);
		if(unCreateDraft==false) {
			draftBoxItemId = boxService.createNewBoxItem(quotationId);
		}

		List templates = templateService.getTemplates(refCompanyId, refDepartment, Integer.MAX_VALUE, 1);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		resultMap.put("quotationId", quotationId);
		resultMap.put("templates", templates);
		resultMap.put("boxItemId", draftBoxItemId);
		return resultMap;
	}

	@RequestMapping(value = "/addProduction")
	@ResponseBody
	public Map<String, Object> addProduction(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"productionId",
				"quotationId",
		});
		String productionId = (String )paramsMap.remove("productionId");
		String quotationId = (String )paramsMap.remove("quotationId");
		
		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureIsSessionUserHasCompany(request, userService);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		String companyId = (String )session.getAttribute("settlement");
		
		Map<String, Object> quotationData = quotationService.getQuotation(quotationId);
		if(!quotationData.get("companyId").equals(companyId))
			throw new PromissionDenyException(String.format("You are not staff of Company[companyId=%s]", (String )quotationData.get("companyId")));
		
		quotationService.appendNewProduction(quotationId, productionId);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/removeProduction")
	@ResponseBody
	public Map<String, Object> removeProduction(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"quotationId",
				"productionId"
		});
		String quotationId = (String )paramsMap.remove("quotationId");
		String productionId = (String )paramsMap.remove("productionId");

		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureIsSessionUserHasCompany(request, userService);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		String companyId = (String )session.getAttribute("settlement");
		
		Map<String, Object> quotationData = quotationService.getQuotation(quotationId);
		if(!quotationData.get("companyId").equals(companyId))
			throw new PromissionDenyException(String.format("You are not staff of Company[companyId=%s]", (String )quotationData.get("companyId")));
		
		quotationService.deleteProduction(quotationId, productionId);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/get")
	@ResponseBody
	public Map<String, Object> get(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"quotationId",
		});
		String quotationId = (String )paramsMap.remove("quotationId");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		Map<String, Object> quotation = quotationService.getQuotation(quotationId);
		
		quotation.remove("_id");
		
		DBCollection productionCollection = mongoTemplate.getCollection(TableName.PRODUCTION);
		
		List<String> productionIds = (List<String> )quotation.get("productionIds");
		BasicDBObject conditions = new BasicDBObject();
		conditions.append("id", new BasicDBObject("$in", productionIds));
		conditions.append("status", Status4Production.NOTMAL);
		DBCursor productionResult = productionCollection.find(conditions);
		quotation.put("productions", productionResult.toArray());
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		resultMap.put("quotation", quotation);
		return resultMap;
	}

	@RequestMapping(value = "/delete")
	@ResponseBody
	public Map<String, Object> delete(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"quotationId",
		});
		String quotationId = (String )paramsMap.remove("quotationId");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		quotationService.deleteQuotation(quotationId);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/search")
	@ResponseBody
	public Map<String, Object> search(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		int pageNumber = 0;
		int pageSize = 0;
		try {
			pageNumber = ((Number )paramsMap.get("pageNumber")).intValue();
			pageSize = ((Number )paramsMap.get("pageSize")).intValue();
		} catch(Throwable x) {}
		
		if(0==pageNumber || 0==pageSize)
			throw new ParametersException("pagination parameters{pageNumber or pageSize}");

		Long saveTime = ((Number )paramsMap.get("saveTime")).longValue();
		String supplier = (String )paramsMap.remove("supplier");
		String extraSubject = (String )paramsMap.remove("subject");
		String extraStatus = (String )paramsMap.remove("status");

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		DBCollection targetCollection = mongoTemplate.getCollection(TableName.QUOTATION);
		
		BasicDBObject conditions = new BasicDBObject("companyId", companyId);
		if(null!=saveTime && 0!=saveTime.longValue())
			 conditions.append("lastUpdateTime", new BasicDBObject("$gt", saveTime));
		if(null!=supplier && !"".equals(supplier))
			 conditions.append("refCompanyId", supplier);
		if(null!=extraSubject && !"".equals(extraSubject))
			 conditions.append("extra.quotInfo.Subject", extraSubject);
		if(null!=extraStatus && !"".equals(extraStatus))
			 conditions.append("extra.quotInfo.Status", extraStatus);
		
		DBCursor quotationResult = targetCollection
				.find(conditions)
				.sort(new BasicDBObject("_id", -1))
				.skip((pageNumber-1)*pageSize)
				.limit(pageSize);
		
		List<DBObject> quotations = quotationResult.toArray();

		DBCollection productionCollection = mongoTemplate.getCollection(TableName.PRODUCTION);
		for(DBObject quotationData:quotations) {

			quotationData.removeField("_id");
			
			List<String> productionIds = (List<String> )quotationData.get("productionIds");
			BasicDBObject productionConditions = new BasicDBObject();
			productionConditions.append("id", new BasicDBObject("$in", productionIds));
			productionConditions.append("status", Status4Production.NOTMAL);
			DBCursor productionResult = productionCollection.find(productionConditions);
			quotationData.put("productions", productionResult.toArray());
		}

		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		resultMap.put("quotations", quotations);
		return resultMap;
	}

	@RequestMapping(value = "/getDraftHistoryMark")
	@ResponseBody
	public Map<String, Object> getHistoryMark(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		RequestEnsure.ensureIsSessionUserHasCompany(request, userService);
		String userId = (String )session.getAttribute("userId");
		String companyId = (String )session.getAttribute("settlement");
		
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				//"type",
				"target"
		});
		//String type = (String )paramsMap.get("type");
		String target = (String )paramsMap.get("target");

		List<Object> historyMark = new ArrayList<Object>();
		BasicDBObject condition = new BasicDBObject("componyId", companyId).append("status", Status4BoxItem.DRAFT);
		DBCollection targetCollection = mongoTemplate.getCollection(TableName.QUOTATION);
		DBCursor cursor = targetCollection.find(condition);
		
		while(cursor.hasNext()) {
			DBObject draftQuotation = cursor.next();
			if("lastUpdateTime".equals(target)) {
				Long lastUpdateTime = (Long )draftQuotation.get("lastUpdateTime");
				historyMark.add(lastUpdateTime.toString());
			} else {
				Map<String, Object> extra = (Map<String, Object> )draftQuotation.get("extra");
				Map<String, Object> quotInfo = (Map<String, Object> )extra.get("quotInfo");
				if("Subject".equals(target)) {
					String subject = (String )quotInfo.get("Subject");
					historyMark.add(subject);
				} else if("Supplier".equals(target)){
					String supplier = (String )quotInfo.get("Supplier");
					historyMark.add(supplier);
				}
			}
			
		}
		

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		resultMap.put("historySet", historyMark);
		return resultMap;
	}
}
