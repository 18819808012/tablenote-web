package com.tablenote.catax.supports.exception;

public class AccountAuthenticationFaild extends RuntimeException {

	private static final long serialVersionUID = -4520840622712227562L;

	public AccountAuthenticationFaild(String accountIdOrName) {
		super(String.format("Account [%s] authentication faild!!!", accountIdOrName));
	}

	public AccountAuthenticationFaild(String accountIdOrName, Throwable cause) {
		super(String.format("Account [%s] authentication faild!!!", accountIdOrName), cause);
	}


}
