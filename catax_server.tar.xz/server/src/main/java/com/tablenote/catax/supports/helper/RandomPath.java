package com.tablenote.catax.supports.helper;

import java.util.Random;
import java.util.UUID;

import org.apache.commons.io.FilenameUtils;
import org.springframework.web.multipart.MultipartFile;

public class RandomPath {

	public static final String getRelativePath(){
		return "/"+getRelativeName()+"/"+getRelativeName(4096);
	}
	private static final String getRelativeName(){
		return getRelativeName(0);
	}
	private static final String getRelativeName(int offset){
        int min=1024+offset;
		int max=min+2999;
        Random random = new Random();
        return Long.toString((random.nextInt(max)%(max-min+1) + min),32);
	}

	private static final String getExtName(MultipartFile file){
		return FilenameUtils.getExtension(file.getOriginalFilename());
	}
	
	
	public static final String getNewFileName(MultipartFile file){
		return  UUID.randomUUID().toString()+"."+getExtName(file);	
	}
}
