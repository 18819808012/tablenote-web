package com.tablenote.catax.supports.exception;

public class AccountAlreadyExistException extends RuntimeException {

	private static final long serialVersionUID = 1626665726048443928L;

	public AccountAlreadyExistException(String accountIdOrName) {
		super(String.format("Account [%s] already exists!!!", accountIdOrName));
	}

	public AccountAlreadyExistException(String accountIdOrName, Throwable cause) {
		super(String.format("Account [%s] already exists!!!", accountIdOrName), cause);
	}

}
