package com.tablenote.catax.supports.service;

public interface IEMailService {

	public void sendEmail(String receiverAddress, String content);
	
}
