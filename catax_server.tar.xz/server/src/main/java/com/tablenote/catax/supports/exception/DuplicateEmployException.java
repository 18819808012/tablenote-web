package com.tablenote.catax.supports.exception;

public class DuplicateEmployException extends RuntimeException {

	private static final long serialVersionUID = -4605540585514197873L;

	public DuplicateEmployException(String message) {
		super(String.format("User[%s] has been in another company!!!", message));
	}

	public DuplicateEmployException(String message, Throwable cause) {
		super(String.format("User[%s] has been in another company!!!", message), cause);
	}
}
