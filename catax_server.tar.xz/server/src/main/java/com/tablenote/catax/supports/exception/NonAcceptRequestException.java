package com.tablenote.catax.supports.exception;

public class NonAcceptRequestException extends RuntimeException {

	private static final long serialVersionUID = -8049217947825126128L;

	public NonAcceptRequestException(String key) {
		super(String.format("The value of key[%s] is not accepted or not provided!!!", key));
	}

	public NonAcceptRequestException(String key, Throwable cause) {
		super(String.format("The value of key[%s] is not accepted or not provided!!!", key), cause);
	}
}
