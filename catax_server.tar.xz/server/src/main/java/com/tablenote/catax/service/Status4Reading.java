package com.tablenote.catax.service;

/**
 * 信箱条目对个人的状态
 * @author kimffy
 *
 */
public final class Status4Reading {

	public final static String SENT = "sent";

	public final static String UNREAD = "unread";
	
	public final static String READ = "read";
	
}