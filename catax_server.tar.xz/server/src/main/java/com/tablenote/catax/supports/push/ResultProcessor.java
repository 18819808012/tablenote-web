package com.tablenote.catax.supports.push;

/**
 * 推送结果处理器接口
 * @author kimffy
 *
 */
public interface ResultProcessor {

	/**
	 * 结果处理函数
	 * @param result
	 */
	public void process(Object result);
	
}
