package com.tablenote.catax.supports.business;

public final class ExcelResolveUtil {
	
	public final static int defaultRowIndex = 0;

	public final static String getValue(String rowIndex, String columnName) {
		return null;
	}
	
}
