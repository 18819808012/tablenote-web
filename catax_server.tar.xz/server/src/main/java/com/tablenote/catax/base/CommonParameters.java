package com.tablenote.catax.base;

import com.tablenote.catax.service.Enum4CompanyLevel;

/**
 * 封装公共参数
 * @author jiefzz
 *
 */
public final class CommonParameters {

	/**
	 * 默认的分页大小
	 */
	public final static int PAGE_SIZE_DEFAULT = Integer.MAX_VALUE;
	
	/**
	 * 默认的分页开始页码
	 */
	public final static int PAGE_NUMBER_DEFAULT = 1;
	
	/**
	 * 当没有提交部门时，默认的部门
	 */
	public final static String DEFAULT_DEPARTMENT = "Administration";
	
	/**
	 * 默认的公司等级
	 */
	public final static String DEFAULT_COMPANY_LEVEL = Enum4CompanyLevel.LEVEL1;
	
	/**
	 * 文件存储的顶级目录
	 */
	public final static String FILE_STORAGE_TOP_DIRECTORY = "/server/web/www.tablenote.com/files";
	
	/**
	 * 文件下载的顶级路径
	 */
	public final static String FILE_DOWNLOAD_PREFIX = "/files";
}
