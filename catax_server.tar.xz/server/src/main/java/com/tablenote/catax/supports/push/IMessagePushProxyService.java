package com.tablenote.catax.supports.push;
/**
 * 类说明：代理执行推送服务，通过消息队列调用真正的推送服务
 * 创建时间：2016年6月2日 下午9:11:09  <br>
 * @author JiefzzLon
*/
public interface IMessagePushProxyService extends IPushWorker {

}
