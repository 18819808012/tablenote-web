package com.tablenote.catax.supports.exception;

public class CompanyNonExistException extends NonExistException {

	private static final long serialVersionUID = 3153339916036855506L;

	public CompanyNonExistException(String message) {
		super(String.format("Compant[%s]", message));
	}
	
	public CompanyNonExistException(String message, Throwable cause) {
		super(String.format("Compant[%s]", message), cause);
	}
}
