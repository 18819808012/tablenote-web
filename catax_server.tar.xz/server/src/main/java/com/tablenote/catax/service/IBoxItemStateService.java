package com.tablenote.catax.service;

import java.util.List;

/**
 * 用户读取状态服务提供者
 * @author kimffy
 *
 */
public interface IBoxItemStateService {

	/**
	 * 标记用户已读
	 * @param userId
	 * @param boxItemId
	 */
	public void markRead(String userId, String boxItemId);
	
	/**
	 * 获取已读的条目的id
	 * @param userId
	 * @return
	 */
	public List<String> getBoxItemIdsHasBeenRead(String userId);
	
	/**
	 * 判断用户当前是否已读此条目
	 * @param userId
	 * @param boxItemId
	 * @return
	 */
	public boolean isRead(String userId, String boxItemId);
	
	final static String TOP_KEY = "bIds";
}
