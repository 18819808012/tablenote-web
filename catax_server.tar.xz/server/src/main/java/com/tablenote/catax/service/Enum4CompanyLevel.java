package com.tablenote.catax.service;

/**
 * 公司登记枚举值
 * @author kimffy
 *
 */
public final class Enum4CompanyLevel {

	public final static String LEVEL1 = "lv1";
	
	public final static String LEVEL2 = "lv2";
	
	public final static String LEVEL3 = "lv3";
	
	/**
	 * 验证给定参数是个合法的公司登记
	 * @param level
	 * @return
	 */
	public static boolean isValidLevel(String level){
		if(LEVEL1.equals(level) || LEVEL2.equals(level) || LEVEL3.equals(level))
			return true;
		return false;
	}
}
