package com.tablenote.catax.supports.push.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.tablenote.catax.supports.push.IMessagePushService;
import com.tablenote.catax.supports.push.IMessagePushWorker;
import com.tablenote.catax.supports.push.ResultProcessor;

@Service
public class MessagePushService implements IMessagePushService {

	@Resource
	IMessagePushWorker messagePushWorker;
	
	@Override
	public void notifyAlias(String alias, String description, String payload, Map<String, String> extra,
			ResultProcessor resultProcessor) {
		messagePushWorker.notifyAlias(alias, description, payload, extra, resultProcessor);
	}

	@Override
	public void notifyTags(String tags, String description, String payload, Map<String, String> extra,
			ResultProcessor resultProcessor) {
		messagePushWorker.notifyTags(tags, description, payload, extra, resultProcessor);
	}

	@Override
	public void notifyById(String pushId, String description, String payload, Map<String, String> extra,
			ResultProcessor resultProcessor) {
		messagePushWorker.notifyById(pushId, description, payload, extra, resultProcessor);
	}

	@Override
	public void broadcast(String description, String payload, Map<String, String> extra,
			ResultProcessor resultProcessor) {
		messagePushWorker.broadcast(description, payload, extra, resultProcessor);
	}

	@Override
	public void broadcastIOS(String description, String payload, Map<String, String> extra,
			ResultProcessor resultProcessor) {
		messagePushWorker.broadcastIOS(description, payload, extra, resultProcessor);
	}

	@Override
	public void broadcastAndroid(String description, String payload, Map<String, String> extra,
			ResultProcessor resultProcessor) {
		messagePushWorker.broadcastAndroid(description, payload, extra, resultProcessor);
	}

	@Override
	public IMessagePushWorker getActuallyWorker() {
		return messagePushWorker;
	}

}
