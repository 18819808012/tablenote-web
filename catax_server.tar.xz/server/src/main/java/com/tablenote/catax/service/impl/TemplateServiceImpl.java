package com.tablenote.catax.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.annotation.Resource;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.tablenote.catax.base.CommonParameters;
import com.tablenote.catax.base.TableName;
import com.tablenote.catax.service.ITemplateService;
import com.tablenote.catax.supports.exception.NonExistException;

@Service
public class TemplateServiceImpl implements ITemplateService {

	@Resource
	MongoTemplate mongoTemplate;
	
	@Override
	public String addNewTemplate(String companyId, List<String> departments, List<Object> baseInfo, Map<String, Object> content, String tmpName, String tmpInfo) {
		ObjectId templateId = new ObjectId();
		DBCollection collection = mongoTemplate.getCollection(TableName.TEMPLATE);
		BasicDBObject template = new BasicDBObject("_id", templateId).append("id", templateId.toHexString());
		template.append("companyOid", new ObjectId(companyId));
		template.append("companyId", companyId);
		template.append("departments", departments);
		template.append("baseInfo", baseInfo);
		template.append("content", content);
		template.append("isDelete", false);
		template.append("tmpName", tmpName);
		template.append("tmpInfo", tmpInfo);
		template.append("createTime", System.currentTimeMillis());
		collection.save(template);
		return templateId.toHexString();
	}

	@Override
	public void updateTemplate(String templateId, List<Object> baseInfo, Map<String, Object> content, String tmpName, String tmpInfo) {
		ObjectId templateOId = new ObjectId(templateId);
		BasicDBObject templateCondition = new BasicDBObject("_id", templateOId);
		templateCondition.append("isDelete", false);
		DBCollection collection = mongoTemplate.getCollection(TableName.TEMPLATE);
		DBObject templateData = collection.findOne(templateCondition);
		if(null==templateData)
			throw new NonExistException(String.format("Template[templateId=%s]", templateId));
		
		
		templateData.put("baseInfo", baseInfo);

		Object object = templateData.get("content");
		if(null==content) {
			;
		} else if(null==object)
			templateData.put("content", content);
		else {
			templateData.removeField("content");
			templateData.put("content", content);
//			Map<String, Object> prevousContent = (Map<String, Object> )object;
//			Set<Entry<String,Object>> entrySet = content.entrySet();
//			for(Entry<String,Object> entry:entrySet) {
//				prevousContent.put(entry.getKey(), entry.getValue());
//			}
		}
		
		if(null!=tmpName)
			templateData.put("tmpName", tmpName);
		if(null!=tmpInfo)
			templateData.put("tmpInfo", tmpInfo);
		
		collection.save(templateData);
	}

	@Override
	public List getTemplates(String companyId, String department, int pageSize, int pageNumber) {
		ArrayList<String> departmentCondition = new ArrayList<String>();
		departmentCondition.add(department);
		BasicDBObject templateCondition = new BasicDBObject();
		templateCondition.append("companyId", companyId);
		templateCondition.append("departments", new BasicDBObject("$in", departmentCondition));
		templateCondition.append("isDelete", false);
		DBCollection collection = mongoTemplate.getCollection(TableName.TEMPLATE);
		DBCursor result = collection.find(templateCondition).skip((pageNumber-1)*pageSize).limit(pageSize);
		if(null==result) return new ArrayList<Object>();
		return result.toArray();
	}
	@Override
	public List getTemplates(String companyId, String department, int pageSize) {
		return getTemplates(companyId, department, pageSize, CommonParameters.PAGE_NUMBER_DEFAULT);
	}
	@Override
	public List getTemplates(String companyId, String department) {
		return getTemplates(companyId, department, CommonParameters.PAGE_SIZE_DEFAULT, CommonParameters.PAGE_NUMBER_DEFAULT);
	}

	@Override
	public List getTemplates(String companyId) {
		BasicDBObject templateCondition = new BasicDBObject();
		templateCondition.append("companyId", companyId);
		templateCondition.append("isDelete", false);
		DBCollection collection = mongoTemplate.getCollection(TableName.TEMPLATE);
		DBCursor result = collection.find(templateCondition);
		return result.toArray();
	}

	@Override
	public void deleteTemplates(String templateId) {

		ObjectId templateOId = new ObjectId(templateId);
		DBCollection collection = mongoTemplate.getCollection(TableName.TEMPLATE);
		BasicDBObject templateCondition = new BasicDBObject("_id", templateOId);
		collection.update(
				templateCondition,
				new BasicDBObject("$set", new BasicDBObject("isDelete", true))
		);
		
	}


	@Override
	public boolean isTemplateAvaliable(String templateId) {
		
		ObjectId templateOId = new ObjectId(templateId);
		BasicDBObject templateCondition = new BasicDBObject("_id", templateOId);
		templateCondition.append("isDelete", false);
		DBCollection collection = mongoTemplate.getCollection(TableName.TEMPLATE);
		DBObject result = collection.findOne(templateCondition);
		if(null==result) return false;
		Map<String, Object> templateDepartments = (Map<String, Object> )result.get("departments");
		if(null==templateDepartments || 0==templateDepartments.size())
			return false;
		return true;
		
	}

	@Override
	public Map<String, Object> get(String templateId) {
		ObjectId templateOId = new ObjectId(templateId);
		BasicDBObject templateCondition = new BasicDBObject("_id", templateOId);
		templateCondition.append("isDelete", false);
		DBCollection collection = mongoTemplate.getCollection(TableName.TEMPLATE);
		DBObject templateData = collection.findOne(templateCondition);
		if(null==templateData)
			throw new NonExistException(String.format("Template[templateId=%s]", templateId));
		return templateData.toMap();
	}

	@Override
	public void updateTemplateDepartments(String tempalteId, List<String> departments) {
		
		ObjectId templateOId = new ObjectId(tempalteId);
		BasicDBObject templateCondition = new BasicDBObject("_id", templateOId);
		
		DBCollection collection = mongoTemplate.getCollection(TableName.TEMPLATE);
		
		collection.update(
				templateCondition,
				new BasicDBObject("$set", new BasicDBObject("departments",departments))
		);
		
	}

}
