package com.tablenote.catax.supports.exception;

public class SessionTimeoutException extends RuntimeException {

	private static final long serialVersionUID = -3927000581944455611L;

	public SessionTimeoutException() {
		super("Your session is out of date!!!");
	}

	public SessionTimeoutException(Throwable cause) {
		super("Your session is out of date!!!", cause);
	}

}
