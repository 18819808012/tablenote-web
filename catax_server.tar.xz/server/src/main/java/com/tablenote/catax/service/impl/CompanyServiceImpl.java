package com.tablenote.catax.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.annotation.Resource;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.tablenote.catax.base.CommonParameters;
import com.tablenote.catax.base.TableName;
import com.tablenote.catax.service.Enum4CompanyLevel;
import com.tablenote.catax.service.ICompanyService;
import com.tablenote.catax.service.IUserService;
import com.tablenote.catax.service.Status4JoinApplication;
import com.tablenote.catax.supports.exception.AccountNonExistException;
import com.tablenote.catax.supports.exception.CompanyJoinApplicationNonExistException;
import com.tablenote.catax.supports.exception.CompanyNonExistException;
import com.tablenote.catax.supports.exception.DuplicateEmployException;
import com.tablenote.catax.supports.exception.PromissionDenyException;

@Service
public class CompanyServiceImpl implements ICompanyService {

	private Lock locl4IncCompanyCode = new ReentrantLock();
	
	@Resource
	MongoTemplate mongoTemplate;
	
	@Resource
	IUserService userService;

	@Override
	public Map<String, Object> createNewCompany(String userId, String companyName, Map<String, Object> companyExtraInfo) {
		
		int companyCode = incCompanyCode();
		
		ObjectId userObjectId = new ObjectId(userId);
		ObjectId companyObjectId = new ObjectId();
		
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		
		BasicDBObject companyData = new BasicDBObject("_id", companyObjectId).append("id", companyObjectId.toHexString());

		companyData.append("componyCode", "" +companyCode);
		companyData.append("componyName", companyName);
		companyData.append("ownerUid", userId);
		companyData.append("ownerOid", userObjectId);
		companyData.append("level", Enum4CompanyLevel.LEVEL1);
		
		companyData.append("extra", companyExtraInfo);
		
		companyData.append("staff", new BasicDBObject(userId, new BasicDBObject("Administration", "manager")));
		companyData.append("department", new BasicDBObject("Administration", new BasicDBObject(userId, "manager")));
		
		companyCollection.save(companyData);
		
		Map<String, Object> rMap = new HashMap<String, Object>();
		rMap.put("companyCode", companyCode);
		rMap.put("companyId", companyObjectId.toHexString());
		return rMap;
	}

	@Override
	public String getCompanyLevel(String companyId) {
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		DBObject companyData = companyCollection.findOne(new BasicDBObject("id", companyId));
		if(null==companyData)
			throw new CompanyNonExistException("companyId=" +companyId);
		return (String )companyData.get("level");
	}

	@Override
	public String getUserCompanyLevel(String userId) {
		Map<String, Object> detail = userService.detail(userId);
		String settlement = (String )detail.get("settlement");
		if(null==settlement || "".equals(settlement))
			return CommonParameters.DEFAULT_COMPANY_LEVEL;
		return getCompanyLevel(settlement);
	}
	
	@Override
	public void updateCompanyLevel(String companyId, String companyLevel) {
		
		if(!Enum4CompanyLevel.isValidLevel(companyLevel))
			throw new RuntimeException("request update level is not valid!!!");
		
		ObjectId companyObjectId = new ObjectId(companyId);
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		companyCollection.update(new BasicDBObject("_id", companyObjectId),
				new BasicDBObject("$set", 
						new BasicDBObject("level", companyLevel)
				)
		);
		
	}


	@Override
	public Map<String, Object> detail(String companyId) {
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		DBObject companyData = companyCollection.findOne(new BasicDBObject("id", companyId));
		if(null==companyData)
			throw new CompanyNonExistException("companyId=" +companyId);
		return companyData.toMap();
	}
	
	@Override
	public void makeSureCompanyExist(String companyId) {
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		DBObject companyData = companyCollection.findOne(new BasicDBObject("_id", companyId));
		if(null==companyData)
			throw new CompanyNonExistException("companyId=" +companyId);
	}

	@Override
	public String getOwnerId(String companyId) {

		ObjectId companyObjectId = new ObjectId(companyId);
		BasicDBObject companyIdentification = new BasicDBObject("_id", companyObjectId);
		
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		
		DBObject companyData = companyCollection.findOne(companyIdentification);
		return (String )companyData.get("ownerUid");
	}

	@Override
	public boolean isOwner(String companyId, String userId) {
		ObjectId companyObjectId = new ObjectId(companyId);
		ObjectId userObjectId = new ObjectId(userId);
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		DBObject companyData = companyCollection.findOne(new BasicDBObject("_id", companyObjectId).append("ownerOid", userObjectId));
		return null==companyData?false:true;
	}
	
	@Override
	public boolean isStaff(String companyId, String userId) {
		ObjectId companyObjectId = new ObjectId(companyId);
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		DBObject result = companyCollection.findOne(
				new BasicDBObject("_id", companyObjectId)
				.append("staff." +userId, new BasicDBObject("$exists", true))
		);
		return null==result?false:true;
	}
	
	@Override
	public boolean isManager(String companyId, String userId, String department) {
		ObjectId companyObjectId = new ObjectId(companyId);
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		DBObject result = companyCollection.findOne(
				new BasicDBObject("_id", companyObjectId)
				.append("staff." +userId +"." +department, "manager")
		);
		return null==result?false:true;
	}

	@Override
	public boolean isManager(String companyId, String userId) {
		ObjectId companyObjectId = new ObjectId(companyId);
		ObjectId userObjectId = new ObjectId(userId);
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		DBObject result = companyCollection.findOne(
				new BasicDBObject("_id", companyObjectId)
		);
		if(null==result)
			throw new CompanyNonExistException("companyId=" +companyId);
		Map<String, Object> staff = (Map<String, Object> )result.get("staff");
		if(Map.class.isAssignableFrom(staff.get(userId).getClass())) {
			Map<String, Object> userStaffInfo = (Map<String, Object> )staff.get(userId);
			return userStaffInfo.containsValue("manager");
		} else 
			return false;
	}

	@Override
	public Collection<String> getUserControlDepartment(String companyId, String userId) {
		ObjectId companyObjectId = new ObjectId(companyId);
		ObjectId userObjectId = new ObjectId(userId);
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		DBObject result = companyCollection.findOne(
				new BasicDBObject("_id", companyObjectId)
		);
		if(null==result)
			throw new CompanyNonExistException("companyId=" +companyId);
		Map<String, Object> staff = (Map<String, Object> )result.get("staff");
		List<String> resultList = new ArrayList<String>();
		if(Map.class.isAssignableFrom(staff.get(userId).getClass())) {
			Map<String, Object> userStaffInfo = (Map<String, Object> )staff.get(userId);
			Set<Entry<String,Object>> entrySet = userStaffInfo.entrySet();
			for(Entry<String,Object> entry:entrySet)
				if("manager".equals(entry.getValue()))
					resultList.add(entry.getKey());
		}
		return resultList;
	}
	
	@Override
	public String getCompanyIdWithCompanyCode(String companyCode) {
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		DBObject companyData = companyCollection.findOne(new BasicDBObject("componyCode", companyCode));
		if(null==companyData)
			throw new CompanyNonExistException("companyCode=" +companyCode);
		return ((ObjectId )companyData.get("_id")).toHexString();
	}

	@Override
	public String makeJoinApplication(String userId, String companyId) {
		ObjectId joinApplicationObjectId = new ObjectId();
		ObjectId companyObjectId = new ObjectId(companyId);
		ObjectId userObjectId = new ObjectId(userId);
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY_JOIN_APPLICATION);
		companyCollection.save(
				new BasicDBObject("_id", joinApplicationObjectId)
					.append("id", joinApplicationObjectId.toHexString())
					.append("companyId", companyObjectId)
					.append("userId", userObjectId)
					.append("state", Status4JoinApplication.READY)
					.append("createTime", System.currentTimeMillis())
		);
		return joinApplicationObjectId.toHexString();
	}

	/**
	 * 如果用户不存在，则通过邮件邀请注册。如果用户没有加入公司，则直接加入该公司，否则给出不能再加入的错误。
	 */
	@Override
	public String makeInvitation(String companyId, String userId) {
		Object obj;
		try {
			Map<String, Object> detail = userService.detail(userId);
			if (null != (obj = detail.get("settlement"))) {
				throw new DuplicateEmployException("userId=" + userId);
			} else {
				becomeStaff(new ObjectId(companyId), new ObjectId(userId));
			}
		} catch (AccountNonExistException e) {
			// TODO 发送邮件邀请注册
		}
		return null;
	}

	@Override
	public void acceptJoinApplication(String joinApplicationId, String companyId) {
		
		ObjectId joinApplicationObjectId = new ObjectId(joinApplicationId);
		ObjectId companyObjectId = new ObjectId(companyId);
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY_JOIN_APPLICATION);
		DBObject joinApplication = companyCollection.findOne(new BasicDBObject("_id", joinApplicationObjectId));
		if(null==joinApplication)
			throw new CompanyJoinApplicationNonExistException(joinApplicationId);
		if(0!=companyObjectId.compareTo((ObjectId )joinApplication.get("companyId")))
			throw new PromissionDenyException(String.format("You cannot control company[companyId=], it is not your company!!!", companyId));
		becomeStaff(companyObjectId, (ObjectId )joinApplication.get("userId"));
		
		// # 16.12.29 新要求，公司接受申请后删除记录
		//companyCollection.update(
		//		new BasicDBObject("_id", joinApplicationObjectId),
		//		new BasicDBObject("$set", new BasicDBObject("state", Status4JoinApplication.ACCEPT))
		//);
		companyCollection.remove(new BasicDBObject("_id", joinApplicationObjectId));
		
	}

	@Override
	public void acceptInvitation(String invitationId, String userId) {
		// 不用接受邀请
	}

	@Override
	public void makeManager(String companyId, String department, String userId) {
		assignStaff(companyId, userId, department, true);
	}

	@Override
	public void makeManager(String companyId, String userId){
		assignStaff(companyId, userId, "Administration", true);
	}

	
	@Override
	public void assignStaff(String companyId, String staffUserId, String department, boolean makeManager) {
		
		String tag=makeManager?"manager":"";
		ObjectId companyObjectId = new ObjectId(companyId);
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		companyCollection.update(new BasicDBObject("_id", companyObjectId),
				new BasicDBObject("$set", 
						new BasicDBObject("department." +department +"." +staffUserId, tag)
						.append("staff." +staffUserId +"." +department, tag)
				)
		);
	}

	@Override
	public void assignStaff(String companyId, String staffUserId, String department) {
		assignStaff(companyId, staffUserId, department, false);
	}
	
	private void becomeStaff(ObjectId companyObjectId, ObjectId userObjectId) {
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		companyCollection.update(new BasicDBObject("_id", companyObjectId), 
				new BasicDBObject("$set", new BasicDBObject("staff." +userObjectId.toHexString(), new BasicDBObject())));
		userService.setSettlement(userObjectId.toHexString(), companyObjectId.toHexString());
	}
	
	private int incCompanyCode(){
		locl4IncCompanyCode.lock();
		try {
			DBCollection collection = mongoTemplate.getCollection(TableName.COMPANY_STATE);
			DBObject result = collection.findOne(TableName.COMPANY_STATE_KEY);
			Number num;
			if(null==result) {
				collection.save(TableName.COMPANY_STATE_KEY);
				collection.update(TableName.COMPANY_STATE_KEY, new BasicDBObject("newCompanyCode", 20000l));
				num = 20000l;
			} else
				num = (Number )result.get("newCompanyCode");
			collection.update(TableName.COMPANY_STATE_KEY, incCompanyCodeCondition);
			return num.intValue();
		} finally {
			locl4IncCompanyCode.unlock();
		}
	}
	
	private final static BasicDBObject incCompanyCodeCondition = new BasicDBObject("$inc", new BasicDBObject("newCompanyCode", 1));

	@Override
	public int getStaffCount(String companyId) {
		Map<String, Object> companyDetail = detail(companyId);
		List<Object> staffList = (List<Object> )companyDetail.get("staff");
		return null==staffList?0:staffList.size();
	}

	@Override
	public void deleteJoinApplication(String joinApplicationId) {
		ObjectId joinApplicationObjectId = new ObjectId(joinApplicationId);
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY_JOIN_APPLICATION);
		companyCollection.remove(new BasicDBObject("_id", joinApplicationObjectId));
	}

	@Override
	public void addCategory(String companyId, String department, String category) {
		ObjectId companyObjectId = new ObjectId(companyId);
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		companyCollection.update(new BasicDBObject("_id", companyObjectId),
				new BasicDBObject("$push", 
						new BasicDBObject("categories." +department, category)
				)
		);
	}

	@Override
	public Map<String, Object> getCategories(String companyId) {
		Map<String, Object> companyDetail = detail(companyId);
		Map<String, Object> categories = (Map<String, Object> )companyDetail.get("categories");
		return null!=categories?categories:new HashMap<String, Object>();
	}

	@Override
	public Collection<Object> getCategories(String companyId, String department) {
		Map<String, Object> categories = getCategories(companyId);
		Collection<Object> departmentCategories = (Collection<Object> )categories.get(department);
		return null==departmentCategories?new ArrayList<Object>():departmentCategories;
	}

	@Override
	public void removeCategory(String companyId, String department, String category) {
		ObjectId companyObjectId = new ObjectId(companyId);
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		BasicDBObject companyCondition = new BasicDBObject("_id", companyObjectId);
		DBObject companyData = companyCollection.findOne(companyCondition);
		DBObject categories = (DBObject )companyData.get("categories");
		if(null==categories)
			return;
		BasicDBList departmentCategories = (BasicDBList )categories.get(department);
		if(null==departmentCategories)
			return;
		departmentCategories.remove(category);
		companyCollection.save(companyData);
	}

	@Override
	public void removeDepartment(String companyId, String department) {
		ObjectId companyObjectId = new ObjectId(companyId);
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		BasicDBObject companyCondition = new BasicDBObject("_id", companyObjectId);
		DBObject companyData = companyCollection.findOne(companyCondition);
		DBObject staff = (DBObject )companyData.get("staff");
		if(staff!=null) {
			Set<String> staffIds = staff.keySet();
			for(String staffId:staffIds) {
				DBObject staffDepartmentInfo = (DBObject )staff.get(staffId);
				if(null==staffDepartmentInfo) continue;
				Set<String> departments = staffDepartmentInfo.keySet();
				if(departments.contains(department))
					staffDepartmentInfo.removeField(department);
			}
		}
		
		DBObject departments = (DBObject )companyData.get("department");
		if(departments.containsField(department))
			departments.removeField(department);
		companyCollection.save(companyData);
	}

	@Override
	public void unsetManager(String companyId, String userId) {
		ObjectId companyObjectId = new ObjectId(companyId);
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		BasicDBObject companyCondition = new BasicDBObject("_id", companyObjectId);
		DBObject companyData = companyCollection.findOne(companyCondition);
		DBObject staff = (DBObject )companyData.get("staff");
		if(staff!=null) {
			DBObject staffDepartmentInfo = (DBObject )staff.get(userId);
			Set<String> staffDepartmentInfoKey = staffDepartmentInfo.keySet();
			for(String staffDepartment:staffDepartmentInfoKey) {
				staffDepartmentInfo.put(staffDepartment, "");
			}
		}
		companyCollection.save(companyData);
	}

	@Override
	public void leaveCompany(String companyId, String userId) {
		ObjectId companyObjectId = new ObjectId(companyId);
		DBCollection companyCollection = mongoTemplate.getCollection(TableName.COMPANY);
		BasicDBObject companyCondition = new BasicDBObject("_id", companyObjectId);
		DBObject companyData = companyCollection.findOne(companyCondition);
		DBObject departments = (DBObject )companyData.get("department");
		if(departments!=null) {
			Set<String> departmentKeys = departments.keySet();
			for(String department:departmentKeys) {
				DBObject departmentStaffInfo = (DBObject )departments.get(department);
				if(null==departmentStaffInfo) continue;
				Set<String> staffIds = departmentStaffInfo.keySet();
				if(staffIds.contains(userId))
					departmentStaffInfo.removeField(userId);
			}
		}
		
		DBObject staffs = (DBObject )companyData.get("staff");
		if(staffs.containsField(userId))
			staffs.removeField(userId);
		companyCollection.save(companyData);
	}
	
	@Override
	public void setAvatar(String companyId, String avatarPath) {
		ObjectId companyObjectId = new ObjectId(companyId);
		DBCollection targetCollection = mongoTemplate.getCollection(TableName.COMPANY);
		targetCollection.update(
				new BasicDBObject("_id", companyObjectId),
				new BasicDBObject("$set", new BasicDBObject("avatar", avatarPath))
		);
	}


	@Override
	public void updateProfile(String companyId, Map<String, Object> extra) {

		ObjectId targetObjectId = new ObjectId(companyId);
		DBCollection targetCollection = mongoTemplate.getCollection(TableName.COMPANY);
		DBObject targetData = targetCollection.findOne(new BasicDBObject("_id", targetObjectId));
		
		DBObject targetExtra = (DBObject )targetData.get("extra");
		if(null==targetExtra)
			targetExtra.put("extra", extra);
		else {
			Set<Entry<String,Object>> entrySet = extra.entrySet();
			for(Entry<String,Object> entry:entrySet) {
				targetExtra.put(entry.getKey(), entry.getValue());
			}
		}

		targetCollection.save(targetData);
	}
}
