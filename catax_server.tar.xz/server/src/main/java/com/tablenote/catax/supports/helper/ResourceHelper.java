package com.tablenote.catax.supports.helper;

public final class ResourceHelper {

	/**
	 * 清除图片后的程序物理路径处理
	 * @param webPath
	 */
	public final static void deleteFile(String webPath) {
		if(null==webPath || "".equals(webPath))
			return;
	}
}
