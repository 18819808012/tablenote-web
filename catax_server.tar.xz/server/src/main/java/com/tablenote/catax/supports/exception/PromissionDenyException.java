package com.tablenote.catax.supports.exception;

public class PromissionDenyException extends RuntimeException {

	private static final long serialVersionUID = -183603686376227140L;

	public PromissionDenyException(String message) {
		super(String.format("Deny: %s!!!", message));
	}

	public PromissionDenyException(String message, Throwable cause) {
		super(String.format("Deny: %s!!!", message), cause);
	}
	
	public final static String I_NO_LOGIN = "this session is not a login session";
}
