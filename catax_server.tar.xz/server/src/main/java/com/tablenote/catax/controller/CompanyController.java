package com.tablenote.catax.controller;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.tablenote.catax.base.CommonParameters;
import com.tablenote.catax.base.TableName;
import com.tablenote.catax.controller.base.BaseController;
import com.tablenote.catax.service.Enum4CompanyLevel;
import com.tablenote.catax.service.ICompanyService;
import com.tablenote.catax.service.IHistoryCollector;
import com.tablenote.catax.service.IUserService;
import com.tablenote.catax.supports.business.CompantLevelLimitUtil;
import com.tablenote.catax.supports.exception.DataStructUncorrectException;
import com.tablenote.catax.supports.exception.NonExistException;
import com.tablenote.catax.supports.exception.ParametersException;
import com.tablenote.catax.supports.exception.PromissionDenyException;
import com.tablenote.catax.supports.helper.RequestEnsure;
import com.tablenote.catax.supports.helper.RandomPath;

@Controller
@RequestMapping(value = "/company")
public class CompanyController extends BaseController {

	@Resource
	ICompanyService companyService;

	@Resource
	IUserService userService;

	@Resource
	MongoTemplate mongoTemplate;

	@Resource
	IHistoryCollector historyCollector;

	/**
	 * 创建公司
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/create")
	@ResponseBody
	public Map<String, Object> create(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "companyName", });
		String companyName = (String) paramsMap.remove("companyName");

		HttpSession session = request.getSession();
		String userId = (String) session.getAttribute("userId");
		if (userService.hasSettlement(userId))
			throw new PromissionDenyException(String.format("User[userId=%s] has created another company!!!", userId));

		Map<String, Object> createNewCompany = companyService.createNewCompany(userId, companyName, paramsMap);
		userService.setSettlement(userId, (String) createNewCompany.get("companyId"));

		session.setAttribute("companyId", createNewCompany.get("companyId"));
		session.setAttribute("settlement", createNewCompany.get("companyId"));

		return createNewCompany;
	}

	/**
	 * 获取公司详细资料
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/detail")
	@ResponseBody
	public Map<String, Object> detail(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		String companyId;
		try {
			while (true) {
				try {
					RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "companyId" });
					companyId = (String) paramsMap.get("companyId");
				} catch (Exception e) {
					RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "companyCode", });
					String companyCode = (String) paramsMap.get("companyCode");
					companyId = companyService.getCompanyIdWithCompanyCode(companyCode);
				}
				break;
			}
		} catch (Exception e) {
			throw new ParametersException("[companyId] or [companyCode]");
		}
		Map<String, Object> detail = companyService.detail(companyId);
		detail.remove("staff");
		detail.remove("department");

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("company", detail);
		return resultMap;
	}

	/**
	 * 获取申请加入请求列表
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/getApplicationList")
	@ResponseBody
	public Map<String, Object> getApplicationList(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		int pageNumber = CommonParameters.PAGE_NUMBER_DEFAULT;
		int pageSize = CommonParameters.PAGE_SIZE_DEFAULT;
		try {
			pageNumber = ((Number) paramsMap.get("pageNumber")).intValue();
			pageSize = ((Number) paramsMap.get("pageSize")).intValue();
		} catch (Throwable x) {
		}

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		// String userId = (String )session.getAttribute("userId");
		String companyId = (String) session.getAttribute("settlement");

		DBCollection collection = mongoTemplate.getCollection(TableName.COMPANY_JOIN_APPLICATION);
		DBCursor cursor = collection.find(new BasicDBObject("companyId", new ObjectId(companyId)));
		int total = cursor.count();
		cursor.skip(pageSize * (pageNumber - 1)).limit(pageSize);
		List<DBObject> applications = cursor.toArray();
		for (DBObject application : applications) {
			application.removeField("_id");
			String userId = ((ObjectId) application.get("userId")).toHexString();
			application.put("companyId", companyId);
			application.put("userId", userId);
			// application.put("id",
			// ((ObjectId)application.get("_id")).toHexString());
			Map<String, Object> detail = userService.detail(userId);
			detail.remove("_id");
			detail.remove("lastLoginInfo");
			detail.remove("password");
			detail.remove("valid");
			application.put("userInfo", detail);
		}

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("pageCount", ((Number) (total / pageSize)).intValue() + (total % pageSize > 0 ? 1 : 0));
		resultMap.put("applications", applications);
		return resultMap;
	}

	/**
	 * 生成加入申请
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/tryJoin")
	@ResponseBody
	public Map<String, Object> makeJoinApplication(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "companyCode", });

		String companyCode = (String) paramsMap.remove("companyCode");

		HttpSession session = request.getSession();
		String userId = (String) session.getAttribute("userId");

		if (userService.hasSettlement(userId))
			throw new PromissionDenyException("You could not participate more than one company!!!");

		String companyId = companyService.getCompanyIdWithCompanyCode(companyCode);
		String companyLevel = companyService.getCompanyLevel(companyId);
		// if(Enum4CompanyLevel.LEVEL1.equals(companyLevel))
		// throw new PromissionDenyException(String.format("Since the company
		// level is %s, you could not send join application to this company!!!",
		// Enum4CompanyLevel.LEVEL1));
		String joinApplicationId = companyService.makeJoinApplication(userId, companyId);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		resultMap.put("joinApplicationId", joinApplicationId);
		return resultMap;
	}

	/**
	 * 接受加入申请
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/acceptJoin")
	@ResponseBody
	public Map<String, Object> acceptJoinApplication(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "joinApplicationId", });
		String joinApplicationId = (String) paramsMap.get("joinApplicationId");
		HttpSession session = request.getSession();

		String companyId = (String) session.getAttribute("settlement");
		String executeUserId = (String) session.getAttribute("userId");

		if (!companyService.isOwner(companyId, executeUserId))
			throw new PromissionDenyException("Not premitted");

		CompantLevelLimitUtil.ensureCanAddNewStaff(companyService.detail(companyId));

		companyService.acceptJoinApplication(joinApplicationId, companyId);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	/**
	 * 删除用户的加入申请
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/deleteJoin")
	public Map<String, Object> deleteJoinApplication(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "joinApplicationId", });
		String joinApplicationId = (String) paramsMap.get("joinApplicationId");
		HttpSession session = request.getSession();

		String companyId = (String) session.getAttribute("settlement");
		String executeUserId = (String) session.getAttribute("userId");

		if (!companyService.isOwner(companyId, executeUserId))
			throw new PromissionDenyException("Not premitted!!!");

		companyService.deleteJoinApplication(joinApplicationId);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	/**
	 * 获取加入申请详细
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/joinApplicationDetail")
	@ResponseBody
	public Map<String, Object> joinApplicationDetail(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "joinApplicationId", });
		String joinApplicationId = (String) paramsMap.get("joinApplicationId");
		if (!ObjectId.isValid(joinApplicationId))
			throw new ParametersException("joinApplicationId");
		HttpSession session = request.getSession();

		String companyId = (String) session.getAttribute("settlement");
		String executeUserId = (String) session.getAttribute("userId");

		DBCollection collection = mongoTemplate.getCollection(TableName.COMPANY_JOIN_APPLICATION);
		DBObject joinApplication = collection.findOne(new BasicDBObject("_id", new ObjectId(joinApplicationId)));
		if (!((ObjectId) joinApplication.get("companyId")).toHexString().equals(companyId)
				&& !((ObjectId) joinApplication.get("userId")).toHexString().equals(executeUserId))
			throw new PromissionDenyException("You cannot get this application!!!");

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("joinApplicationId", joinApplicationId);
		resultMap.put("companyId", companyId);
		resultMap.put("userId", ((ObjectId) joinApplication.get("userId")).toHexString());
		resultMap.put("state", joinApplication.get("state"));
		resultMap.put("createTime", joinApplication.get("createTime"));
		return resultMap;

	}

	/**
	 * 邀请加入公司
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/invite")
	@ResponseBody
	public Map<String, Object> invite(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		String userId = null;
		try {
			String email = null;
			try {
				RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "userId" });
				userId = (String) paramsMap.get("userId");
			} catch (Exception e) {
				RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "email", });
				email = (String) paramsMap.get("email");
			}
			if (null == userId && null == email)
				throw new Exception();
			userId = userService.getUserIdWithEmail(email);
		} catch (Exception e) {
			throw new ParametersException("[userId] or [email]");
		}

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String companyId = (String) session.getAttribute("settlement");
		String executeUserId = (String) session.getAttribute("userId");
		if (!companyService.isOwner(companyId, executeUserId))
			throw new PromissionDenyException("Not premitted");

		CompantLevelLimitUtil.ensureCanAddNewStaff(companyService.detail(companyId));

		companyService.makeInvitation(companyId, userId);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;

	}

	/**
	 * 分配员工到部门
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/assignStaff")
	@ResponseBody
	public Map<String, Object> assignStaffToDepartment(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		String userId;
		String department;
		Boolean makeManager = false;
		try {
			while (true) {
				try {
					RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "userId" });
					userId = (String) paramsMap.get("userId");
				} catch (Exception e) {
					RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "email", });
					String email = (String) paramsMap.get("email");
					userId = userService.getUserIdWithEmail(email);
				}
				break;
			}
		} catch (Exception e) {
			throw new ParametersException("[userId] or [email]");
		}
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "department" });
		department = (String) paramsMap.get("department");
		try {
			RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "makeManager" });
			makeManager = (Boolean) paramsMap.get("makeManager");
		} catch (Exception e) {
		}

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String executeUserId = (String) session.getAttribute("userId");
		String companyId = (String) session.getAttribute("settlement");
		if (companyService.isOwner(companyId, executeUserId)) {

		} else if (makeManager) {
			throw new PromissionDenyException("You are not the company onwner!!!");
		} else {
			Collection<String> departments = companyService.getUserControlDepartment(companyId, executeUserId);
			if (!departments.contains(department))
				throw new PromissionDenyException(
						String.format("You are not the department[%s] manager!!!", department));
		}
		if (!companyService.isStaff(companyId, userId))
			throw new PromissionDenyException(String.format("User[userId=%s] is not your staff!!!", userId));

		companyService.assignStaff(companyId, userId, department, makeManager);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	/**
	 * 创建部门
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/createDepartments")
	@ResponseBody
	public Map<String, Object> createDepartment(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureIsLoginSession(request);
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "department" });
		String department = (String) paramsMap.get("department");

		HttpSession session = request.getSession();
		String companyId = (String) session.getAttribute("settlement");
		String executeUserId = (String) session.getAttribute("userId");

		// if(!companyService.isOwner(companyId, executeUserId))
		// throw new PromissionDenyException("Not premitted");
		if (!companyService.isManager(companyId, executeUserId))
			throw new PromissionDenyException("Not premitted");

		companyService.makeManager(companyId, department, executeUserId);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	/**
	 * 获取所有部门
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/allDepartments")
	@ResponseBody
	public Map<String, Object> allDepartments(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		String companyId;
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "companyId" });
		companyId = (String) paramsMap.get("companyId");

		Map<String, Object> detail = companyService.detail(companyId);
		Map<String, Object> departments = (Map<String, Object>) detail.get("department");

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("departments", departments.keySet());
		return resultMap;
	}

	/**
	 * 获取当前登陆账号所管理的部门
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/myManageDepartment")
	@ResponseBody
	public Map<String, Object> getMyManageDepartment(HttpServletRequest request, HttpServletResponse response) {

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String executeUserId = (String) session.getAttribute("userId");
		String companyId = (String) session.getAttribute("settlement");
		if (!userService.hasSettlement(executeUserId))
			throw new PromissionDenyException("You have never join any company before!!!");
		Collection<String> departments = companyService.getUserControlDepartment(companyId, executeUserId);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		// resultMap.put("success", "");
		resultMap.put("departments", departments);
		return resultMap;
	}

	/**
	 * 获取分类
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/getCategories")
	@ResponseBody
	public Map<String, Object> getCategories(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "companyId", "department" });
		String companyId = (String) paramsMap.get("companyId");

		List<String> departments = (List<String>) paramsMap.get("department");

		Map<String, Object> detail = companyService.detail(companyId);
		Map<String, Object> companyAllDepartments = (Map<String, Object>) detail.get("department");

		Map<String, Object> containerMap = new HashMap<String, Object>();
		for (String department : departments) {
			if (!companyAllDepartments.containsKey(department))
				throw new NonExistException(String.format("Department[departmentName=\"%s\"]", department));
			Collection<Object> categories = companyService.getCategories(companyId, department);
			containerMap.put(department, categories);
		}

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("categories", containerMap);
		return resultMap;
	}

	/**
	 * 增加分类
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/addCategory")
	@ResponseBody
	public Map<String, Object> addCategory(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "category" });
		String category = (String) paramsMap.get("category");

		String department = paramsMap.containsKey("department") ? (String) paramsMap.get("department")
				: CommonParameters.DEFAULT_DEPARTMENT;

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String executeUserId = (String) session.getAttribute("userId");
		String companyId = (String) session.getAttribute("settlement");

		if (!companyService.isManager(companyId, executeUserId))
			throw new PromissionDenyException("You are not the manager of this company!!!");

		Map<String, Object> detail = companyService.detail(companyId);
		Map<String, Object> departments = (Map<String, Object>) detail.get("department");
		if (!departments.containsKey(department))
			throw new NonExistException(String.format("Department[departmentName=\"%s\"]", department));

		companyService.addCategory(companyId, department, category);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	/**
	 * 删除分类
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/removeCategory")
	@ResponseBody
	public Map<String, Object> removeCategory(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "category" });
		String category = (String) paramsMap.get("category");

		String department = paramsMap.containsKey("department") ? (String) paramsMap.get("department")
				: CommonParameters.DEFAULT_DEPARTMENT;

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String executeUserId = (String) session.getAttribute("userId");
		String companyId = (String) session.getAttribute("settlement");

		if (!companyService.isManager(companyId, executeUserId))
			throw new PromissionDenyException("You are not the manager of this company!!!");

		companyService.removeCategory(companyId, department, category);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	/**
	 * 查看所有员工
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/getAllStaffs")
	@ResponseBody
	public Map<String, Object> getAllStaffs(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String executeUserId = (String) session.getAttribute("userId");
		String companyId = (String) session.getAttribute("settlement");

		Map<String, Object> companyData = companyService.detail(companyId);
		Map<String, Object> staffData = (Map<String, Object>) companyData.get("staff");
		if (null == staffData)
			throw new DataStructUncorrectException(String.format("staff of Company[companyId=%s]"));
		Set<String> staffUserIds = staffData.keySet();

		DBCollection userCollection = mongoTemplate.getCollection(TableName.USER);
		DBCursor cursor = userCollection.find(new BasicDBObject("id", new BasicDBObject("$in", staffUserIds)));
		List<DBObject> results = cursor.toArray();
		for (DBObject userData : results) {
			userData.removeField("_id");
			userData.removeField("lastLoginInfo");
			userData.removeField("password");
			userData.removeField("valid");
		}

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		resultMap.put("staffs", results);
		return resultMap;

	}

	/**
	 * 设置为管理员
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/makeManager")
	@ResponseBody
	public Map<String, Object> makeManager(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "staffId" });
		String staffId = (String) paramsMap.get("staffId");

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String executeUserId = (String) session.getAttribute("userId");
		String companyId = (String) session.getAttribute("settlement");

		if (!companyService.isOwner(companyId, executeUserId))
			throw new PromissionDenyException("You are not the owner of the company!");

		if (!companyService.isStaff(companyId, staffId))
			throw new PromissionDenyException(String.format("User[userId=%s] is not your staff!!!", staffId));

		companyService.makeManager(companyId, staffId);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	/**
	 * 撤除管理员
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/unsetManager")
	@ResponseBody
	public Map<String, Object> unsetManager(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "staffId" });
		String staffId = (String) paramsMap.get("staffId");

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String executeUserId = (String) session.getAttribute("userId");
		String companyId = (String) session.getAttribute("settlement");

		if (!companyService.isOwner(companyId, executeUserId))
			throw new PromissionDenyException("You are not the owner of the company!");

		if (!companyService.isManager(companyId, staffId))
			throw new PromissionDenyException(String.format("User[userId=%s] is not your manager!!!", staffId));

		companyService.unsetManager(companyId, staffId);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	/**
	 * 删除部门
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/removeDepartment")
	@ResponseBody
	public Map<String, Object> removeDepartment(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "department" });
		String department = (String) paramsMap.get("department");

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String executeUserId = (String) session.getAttribute("userId");
		String companyId = (String) session.getAttribute("settlement");

		// if(!companyService.isOwner(companyId, executeUserId))
		// throw new PromissionDenyException("You are not the owner of the
		// company!");

		if (!companyService.isManager(companyId, executeUserId))
			throw new PromissionDenyException(String.format("User[userId=%s] is not a manager!!!", executeUserId));

		companyService.removeDepartment(companyId, department);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	/**
	 * 撤除员工
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/fireStaff")
	@ResponseBody
	public Map<String, Object> fireStaff(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "staffId" });
		String staffId = (String) paramsMap.get("staffId");

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String executeUserId = (String) session.getAttribute("userId");
		String companyId = (String) session.getAttribute("settlement");

		if (!companyService.isOwner(companyId, executeUserId))
			throw new PromissionDenyException("You are not the owner of the company!");

		if (!companyService.isStaff(companyId, staffId))
			throw new PromissionDenyException(String.format("User[userId=%s] is not your staff!!!", staffId));

		companyService.leaveCompany(companyId, staffId);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	/**
	 * 员工退出公司
	 * 
	 * @param request
	 * @param response
	 * @param paramsMap
	 * @return
	 */
	@RequestMapping(value = "/fireMyself")
	@ResponseBody
	public Map<String, Object> fireMyself(HttpServletRequest request, HttpServletResponse response) {

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String executeUserId = (String) session.getAttribute("userId");
		String companyId = (String) session.getAttribute("settlement");

		if (null == companyId)
			throw new PromissionDenyException("You should be in a company first");

		if (!companyService.isStaff(companyId, executeUserId))
			throw new PromissionDenyException(
					String.format("User[userId=%s] is not Company[companyId=%s]'s staff!!!", executeUserId, companyId));

		companyService.leaveCompany(companyId, executeUserId);

		session.removeAttribute("userId");
		session.removeAttribute("email");
		session.removeAttribute("email");

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/avatar")
	@ResponseBody
	public Map<String, Object> upload(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value = "avatar", required = true) MultipartFile file) {

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String) session.getAttribute("userId");
		String companyId = (String) session.getAttribute("settlement");

		if (!companyService.isOwner(companyId, userId))
			throw new PromissionDenyException("You are not the owner of the company!");

		String fileChildPath = RandomPath.getRelativePath() + "/" + RandomPath.getNewFileName(file);
		try {
			FileUtils.copyInputStreamToFile(file.getInputStream(),
					new File(CommonParameters.FILE_STORAGE_TOP_DIRECTORY, fileChildPath));
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

		String avatarPath = CommonParameters.FILE_DOWNLOAD_PREFIX + fileChildPath;
		companyService.setAvatar(companyId, avatarPath);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("avatar", avatarPath);
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/updateProfile")
	@ResponseBody
	public Map<String, Object> updateProfile(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		RequestEnsure.ensureIsSessionUserHasCompany(request, userService);
		String userId = (String) session.getAttribute("userId");
		String companyId = (String) session.getAttribute("settlement");

		if (!companyService.isOwner(companyId, userId))
			throw new PromissionDenyException("You are not the owner of the company!");

		if (paramsMap.size() > 0)
			companyService.updateProfile(companyId, paramsMap);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/setCompanyCode")
	@ResponseBody
	public Map<String, Object> setCompanyCode(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "companyCode" });
		String companyCode = (String) paramsMap.get("companyCode");

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		RequestEnsure.ensureIsSessionUserHasCompany(request, userService);
		String userId = (String) session.getAttribute("userId");
		String companyId = (String) session.getAttribute("settlement");

		if (!companyService.isOwner(companyId, userId))
			throw new PromissionDenyException("You are not the owner of the company!");

		DBCollection targetCollection = mongoTemplate.getCollection(TableName.COMPANY);
		DBObject prevous = targetCollection.findOne(new BasicDBObject("componyCode", companyCode));
		if (null != prevous)
			throw new PromissionDenyException(String.format("Duplicate companyCode[%s]", companyCode));

		ObjectId targetObjectId = new ObjectId(companyId);
		targetCollection.update(new BasicDBObject("_id", targetObjectId),
				new BasicDBObject("$set", new BasicDBObject("componyCode", companyCode)));

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/departmentJoined")
	@ResponseBody
	public Map<String, Object> departmentJoined(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "userId" });
		String userId = (String) paramsMap.get("userId");
		
		Map<String, Object> detail = userService.detail(userId);
		Object settlement = detail.get("settlement");
		
		Map<String, Object> companyDetail = companyService.detail(((ObjectId )settlement).toHexString());
		Object object = companyDetail.get("staff");
		Object userDepartmentInfo;
		if(null!=object) {
			userDepartmentInfo = ((Map<String, Object> )object).get(userId);
		} else
			userDepartmentInfo = new HashMap<String, Object>();
		
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("departmentJoined", userDepartmentInfo);
		return resultMap;
	}
	
	@RequestMapping(value = "/getHistoryMark")
	@ResponseBody
	public Map<String, Object> getHistoryMark(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		RequestEnsure.ensureIsSessionUserHasCompany(request, userService);
		String userId = (String) session.getAttribute("userId");
		String companyId = (String) session.getAttribute("settlement");

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "type", "target" });
		String type = (String) paramsMap.get("type");
		String target = (String) paramsMap.get("target");

		Set<String> historyMark = historyCollector.getHistoryMark(companyId, type, target);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		resultMap.put("historySet", historyMark);
		return resultMap;
	}

	@RequestMapping(value = "/updateLevel")
	@ResponseBody
	public Map<String, Object> updateLevel(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[] { "level", "companyId" });
		String companyId = (String) paramsMap.get("companyId");
		String level = (String) paramsMap.get("level");

		companyService.updateCompanyLevel(companyId, level);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}
}