package com.tablenote.catax.service;

/**
 * 报价单状态
 * @author kimffy
 *
 */
public final class Status4Quotation {

	/**
	 * 正常的报价单
	 */
	public final static String NORMAL = "normal";

	/**
	 * 送出提交到采购商
	 */
	public final static String SENT = "locked";
	
	/**
	 * 请求更新
	 */
	public final static String REQUIRE_UPDATE = "requireUpdate";

	/**
	 * 标记状态为逻辑删除
	 */
	public final static String DROP = "drop";
	
}
