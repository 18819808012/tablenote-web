package com.tablenote.catax.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.tablenote.catax.base.CommonParameters;
import com.tablenote.catax.base.TableName;
import com.tablenote.catax.controller.base.BaseController;
import com.tablenote.catax.service.IProductionService;
import com.tablenote.catax.service.IQuotationService;
import com.tablenote.catax.service.ITemplateService;
import com.tablenote.catax.service.IUserService;
import com.tablenote.catax.supports.exception.ParametersException;
import com.tablenote.catax.supports.exception.PromissionDenyException;
import com.tablenote.catax.supports.helper.RequestEnsure;
import com.tablenote.catax.supports.helper.RandomPath;

@Controller
@RequestMapping(value = "/production")
public class ProductionController extends BaseController {

	@Resource
	IUserService userService;
	
	@Resource
	MongoTemplate mongoTemplate;
	
	@Resource
	IProductionService productionService;
	
	@Resource
	ITemplateService templateService;
	
	@Resource
	IQuotationService quotationService;
	
	@RequestMapping(value = "/create")
	@ResponseBody
	public Map<String, Object> create(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"quotationId",
				"extra"
		});
		String quotationId = (String )paramsMap.remove("quotationId");
		Map<String, Object> extra = (Map<String, Object> )paramsMap.remove("extra");
		List<String> categories = (List<String> )paramsMap.remove("categories");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		Map<String, Object> quotationData = quotationService.getQuotation(quotationId);
		String refCompanyId = (String )quotationData.get("refCompanyId");
		String refDepartment = (String )quotationData.get("refDepartment");
		
		
		String productionId;
		if(null==categories)
			productionId = productionService.createNewProduction(companyId, quotationId, refCompanyId, refDepartment, extra);
		else 
			productionId = productionService.createNewProduction(companyId, quotationId, refCompanyId, refDepartment, categories, extra);
		quotationService.appendNewProduction(quotationId, productionId);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("productionId", productionId);
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/update")
	@ResponseBody
	public Map<String, Object> update(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {
		
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"productionId",
				"updateExtra"
		});
		String productionId = (String )paramsMap.remove("productionId");
		Map<String, Object> updateExtra = (Map<String, Object> )paramsMap.remove("updateExtra");

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		if(productionService.isProductionWritable(productionId))
			productionService.update(productionId, updateExtra);
		else
			throw new PromissionDenyException("Target production is already locked!");
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
		
	}

	@RequestMapping(value = "/delete")
	@ResponseBody
	public Map<String, Object> delete(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {
		
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"productionId",
		});
		String productionId = (String )paramsMap.remove("productionId");

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");

		if(productionService.isProductionWritable(productionId))
			productionService.delete(productionId);
		else
			throw new PromissionDenyException("Target production is already locked!");

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
		
	}

	@RequestMapping(value = "/get")
	@ResponseBody
	public Map<String, Object> get(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {
		
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"productionId",
		});
		String productionId = (String )paramsMap.remove("productionId");

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		Map<String, Object> production = productionService.get(productionId);
		production.remove("_id");

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		resultMap.put("production", production);
		return resultMap;
		
	}

	@RequestMapping(value = "/search")
	@ResponseBody
	public Map<String, Object> search(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		int pageNumber = CommonParameters.PAGE_NUMBER_DEFAULT;
		int pageSize = CommonParameters.PAGE_SIZE_DEFAULT;
		try {
			pageNumber = ((Number )paramsMap.get("pageNumber")).intValue();
			pageSize = ((Number )paramsMap.get("pageSize")).intValue();
		} catch(Throwable x) {}
		
		List<String> categories = (List<String> )paramsMap.remove("categories");
		String refDepartment = (String )paramsMap.remove("department");
		String refCompanyId = (String )paramsMap.remove("companyId");

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		BasicDBObject condition = new BasicDBObject("companyId", companyId);
		if(null!=categories)
			condition.append("categories", new BasicDBObject("$all", categories));
		if(null!=refDepartment)
			condition.append("refDepartment", refDepartment);
		if(null!=refCompanyId)
			condition.append("refCompanyId", refCompanyId);
		DBCollection productionCollection = mongoTemplate.getCollection(TableName.PRODUCTION);
		DBCursor result = productionCollection.find(condition)
				.sort(new BasicDBObject("_id", -1));
		int total = result.count();
		if(pageNumber!=0 && pageSize!=0)
			result.skip(pageSize*(pageNumber-1)).limit(pageSize);
		List<DBObject> resultProductions = result.toArray();
		
		for(DBObject productionData:resultProductions) {
			productionData.removeField("_id");
		}
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		resultMap.put("productions", resultProductions);
		if(pageNumber!=0 && pageSize!=0)
			resultMap.put("pageCount", ((Number )(total/pageSize)).intValue() + (total%pageSize>0?1:0));
		return resultMap;
		
	}

	@RequestMapping(value = "/images")
	@ResponseBody
	public Map<String, Object> images(HttpServletRequest request, HttpServletResponse response, @RequestParam Map<String, Object> paramsMap, @RequestParam(value = "image", required = true) MultipartFile file) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"idx",
				"productionId"
		});
		String productionId = (String )paramsMap.remove("productionId");
		//Integer idx = ((Number )paramsMap.remove("idx")).intValue();
		Integer idx = Integer.parseInt((String )paramsMap.remove("idx"));
		
		if(5<idx || 0>idx)
			throw new ParametersException(String.format("idx[idx=%d] is uncorrect", idx));
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");


		if(!productionService.isProductionWritable(productionId))
			throw new PromissionDenyException("Target production is already locked!");
		
		String fileChildPath = RandomPath.getRelativePath() +"/" +RandomPath.getNewFileName(file);
		try {
			FileUtils.copyInputStreamToFile(file.getInputStream(), new File(CommonParameters.FILE_STORAGE_TOP_DIRECTORY, fileChildPath));
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
		String imagePath = CommonParameters.FILE_DOWNLOAD_PREFIX +fileChildPath;
		
		productionService.addImage(productionId, idx, imagePath);

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/removeImage")
	@ResponseBody
	public Map<String, Object> removeImage(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"idx",
				"productionId"
		});
		String productionId = (String )paramsMap.remove("productionId");
		Integer idx = ((Number )paramsMap.remove("idx")).intValue();
		
		if(5<idx || 0>idx)
			throw new ParametersException(String.format("idx[idx=%d] is uncorrect", idx));
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");

		if(!productionService.isProductionWritable(productionId))
			throw new PromissionDenyException("Target production is already locked!");
		
		productionService.removeImage(productionId, idx);

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

}