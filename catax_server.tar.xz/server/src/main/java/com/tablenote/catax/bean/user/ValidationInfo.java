package com.tablenote.catax.bean.user;

import java.io.Serializable;

/**
 * 验证信息
 * @author jiefzz
 *
 */
public class ValidationInfo implements Serializable {

	private static final long serialVersionUID = -2564123925803413218L;

	private boolean emailState = false;
	
	private String emailCode = null;
	
	private Long emailCodeCreateTime = System.currentTimeMillis();

	public boolean getEmailState() {
		return emailState;
	}

	public void setEmailState(boolean emailState) {
		this.emailState = emailState;
	}

	public String getEmailCode() {
		return emailCode;
	}

	public void setEmailCode(String emailCode) {
		this.emailCode = emailCode;
	}

	public Long getEmailCodeCreateTime() {
		return emailCodeCreateTime;
	}
}
