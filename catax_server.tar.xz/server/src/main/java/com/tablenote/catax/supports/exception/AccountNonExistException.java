package com.tablenote.catax.supports.exception;

public class AccountNonExistException extends NonExistException {

	private static final long serialVersionUID = -5454956551486290612L;

	public AccountNonExistException(String accountIdOrName) {
		super(String.format("Account[%s]", accountIdOrName));
	}

	public AccountNonExistException(String accountIdOrName, Throwable cause) {
		super(String.format("Account[%s]", accountIdOrName), cause);
	}

}
