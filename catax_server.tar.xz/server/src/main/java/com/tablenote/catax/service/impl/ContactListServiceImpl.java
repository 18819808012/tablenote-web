package com.tablenote.catax.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.tablenote.catax.base.TableName;
import com.tablenote.catax.service.IContactListService;

@Service
public class ContactListServiceImpl implements IContactListService {

	@Resource
	MongoTemplate mongoTemplate;
	
	@Override
	public String createContactCompany(String companyId, String department, String contactCompanyName, Map<String, String> extra) {
		ObjectId objectId = new ObjectId();
		BasicDBObject contactCompany = new BasicDBObject("_id", objectId)
				.append("id", objectId.toHexString())
				.append("companyId", companyId)
				.append("department", department)
				.append("name", contactCompanyName);
		if(null==extra || extra.size()==0)
			contactCompany.append("extra", new BasicDBObject());
		else
			contactCompany.append("extra", extra);
		DBCollection collection = mongoTemplate.getCollection(TableName.CONTACTS);
		collection.save(contactCompany);
		return objectId.toHexString();
	}

	@Override
	public String addContactItem(String contactCompanyId, String name, Map<String, String> extra) {
		ObjectId objectId = new ObjectId();
		DBCollection collection = mongoTemplate.getCollection(TableName.CONTACTS);
		BasicDBObject contactCompany = new BasicDBObject("_id", objectId)
				.append("id", objectId.toHexString())
				.append("name", name);
		contactCompany.putAll(extra);
		collection.update(
				new BasicDBObject("_id", new ObjectId(contactCompanyId)),
				new BasicDBObject("$set", new BasicDBObject("contactItems." +objectId.toHexString(), contactCompany))
		);
		return objectId.toHexString();
	}

	@Override
	public List getContacts(String companyId, String department) {
		BasicDBObject contactCondition = new BasicDBObject()
				.append("companyId", companyId)
				.append("department", department);
		DBCollection collection = mongoTemplate.getCollection(TableName.CONTACTS);
		DBCursor result = collection.find(contactCondition);
		return result.toArray();
	}

	@Override
	public void removeContactItem(String contactCompanyId, String contactItemId) {
		BasicDBObject contactCondition = new BasicDBObject("_id", new ObjectId(contactCompanyId));
		DBCollection collection = mongoTemplate.getCollection(TableName.CONTACTS);
		collection.update(
				contactCondition,
				new BasicDBObject("$unset", new BasicDBObject("contactItems." +contactItemId, ""))
		);
	}

	@Override
	public void removeContactCompany(String contactCompanyId) {
		BasicDBObject contactCondition = new BasicDBObject("_id", new ObjectId(contactCompanyId));
		DBCollection collection = mongoTemplate.getCollection(TableName.CONTACTS);
		collection.remove(contactCondition);
	}

	@Override
	public void addResource(String contactCompanyId, String resourceKey, String resourcePath) {
		BasicDBObject contactCondition = new BasicDBObject("_id", new ObjectId(contactCompanyId));
		DBCollection collection = mongoTemplate.getCollection(TableName.CONTACTS);

		DBObject result = collection.findOne(contactCondition);
		if(List.class.isAssignableFrom(result.get("extra").getClass())){
			collection.update(
					new BasicDBObject("_id", new ObjectId(contactCompanyId)),
					new BasicDBObject("$set",
							new BasicDBObject("extra", new BasicDBObject()))
			);
		}
		
		collection.update(
				contactCondition,
				new BasicDBObject("$set",
						new BasicDBObject("extra." +resourceKey, resourcePath))
		);
		
	}

	@Override
	public void removeResource(String contactCompanyId, String resourceKey) {
		DBCollection collection = mongoTemplate.getCollection(TableName.CONTACTS);

		collection.update(
				new BasicDBObject("_id", new ObjectId(contactCompanyId)),
				new BasicDBObject("$unset",
						new BasicDBObject("extra." +resourceKey, false))
		);
	}

}
