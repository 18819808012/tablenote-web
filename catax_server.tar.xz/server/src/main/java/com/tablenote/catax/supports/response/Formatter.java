package com.tablenote.catax.supports.response;

import java.util.HashMap;
import java.util.Map;

public final class Formatter {

	public static Map<String, Object> format(Long returnCode, String message, Object result) {
		Map<String, Object> topResultMap = new HashMap<String, Object>();
		topResultMap.put("code", returnCode);
		topResultMap.put("message", message);
		topResultMap.put("result", result);
		return topResultMap;
	}
	
}
