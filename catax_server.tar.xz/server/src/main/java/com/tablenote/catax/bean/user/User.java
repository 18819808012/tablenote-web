package com.tablenote.catax.bean.user;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.tablenote.catax.base.PasswordUtils;

public class User implements Serializable {

	private static final long serialVersionUID = 975098869182590043L;

	private String id = null;
	
	private String email = null;
	
	private String password = null;
	
	private String user = null;
	
	private Map<String, String> extra = new HashMap<String, String>();
	
	private String settlement = null;
	
	private ValidationInfo valid = null;
	
	private Map<String, LoginDevice> lastLoginInfo = new HashMap<String, LoginDevice>();
	
	/******************业务方法*******************/
	public void generalNewUser(String id, String email, String password, String user){
		this.email = email;
		this.password = PasswordUtils.makePassword(password);
		this.user = user;

		String validCodeForEmail = PasswordUtils.makeSHA1(email +id +password).substring(9, 15);
		valid = new ValidationInfo();
		valid.setEmailCode(validCodeForEmail);
		valid.setEmailState(false);
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getSettlement() {
		return settlement;
	}

	public void setSettlement(String settlement) {
		this.settlement = settlement;
	}
	
	public Map<String, String> getExtra() {
		return extra;
	}
	
	public void addOrUpdateExtra(String key, String value) {
		extra.put(key, value);
	}
}