package com.tablenote.catax.service;

/**
 * 信箱条目状态
 * @author kimffy
 *
 */
public class Status4BoxItem {

	/**
	 * 正常的条目
	 */
	public final static String NORMAL = "normal";

	/**
	 * 草稿
	 */
	public final static String DRAFT = "draft";

	/**
	 * 已删除（显示在已删除的信箱中）
	 */
	public final static String JUNK = "junk";
	
	/**
	 * 逻辑删除标记，对应UI界面上的永久删除选项<br>
	 * 真正意义上的永久删除是数据库物理删除，不是这个。
	 */
	public final static String DROP = "drop";
	
}
