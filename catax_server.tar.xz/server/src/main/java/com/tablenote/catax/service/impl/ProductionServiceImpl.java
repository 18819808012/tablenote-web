package com.tablenote.catax.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.annotation.Resource;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.WriteResult;
import com.tablenote.catax.base.TableName;
import com.tablenote.catax.service.IProductionService;
import com.tablenote.catax.service.IQuotationService;
import com.tablenote.catax.service.ITemplateService;
import com.tablenote.catax.service.Status4Production;
import com.tablenote.catax.service.Status4Quotation;
import com.tablenote.catax.supports.exception.DataStructUncorrectException;
import com.tablenote.catax.supports.exception.NonExistException;
import com.tablenote.catax.supports.exception.PromissionDenyException;
import com.tablenote.catax.supports.helper.ResourceHelper;

@Service
public class ProductionServiceImpl implements IProductionService {

	@Resource
	MongoTemplate mongoTemplate;
	
	@Resource
	ITemplateService templateService;
	
	@Resource
	IQuotationService quotationService;
	
	@Override
	public String createNewProduction(String companyId, String quotationId, String refCompanyId, String refDepartment, Map<String, Object> extra) {
		return createNewProduction(companyId, quotationId, refCompanyId, refDepartment, new ArrayList<String>(), extra);
	}

	@Override
	public String createNewProduction(String companyId, String quotationId, String refCompanyId, String refDepartment, List<String> categories, Map<String, Object> extra) {

		List templates = templateService.getTemplates(refCompanyId, refDepartment, Integer.MAX_VALUE, 1);
		if(null==templates || templates.size()!=1)
			throw new DataStructUncorrectException(String.format("templates of CompanyId: %s, Department: %s", refCompanyId, refDepartment));
		DBObject template = (DBObject )templates.get(0);
		String templateId = (String )template.get("id");
		
		DBCollection collection = mongoTemplate.getCollection(TableName.PRODUCTION);
		ObjectId productionId = new ObjectId();
		BasicDBObject newProduction = new BasicDBObject("_id", productionId).append("id", productionId.toHexString());
		newProduction.append("companyId", companyId);
		newProduction.append("quotationId", quotationId);
		newProduction.append("refCompanyId", refCompanyId);
		newProduction.append("refDepartment", refDepartment);
		newProduction.append("templateId", templateId);
		newProduction.append("extra", (null!=extra?extra:new HashMap<String, Object>()));
		newProduction.append("status", Status4Production.NOTMAL);
		newProduction.append("createTime", System.currentTimeMillis());
		newProduction.append("categories", categories);
		collection.save(newProduction);
		
		whileProductionUpdate(quotationId);
		
		return productionId.toHexString();
	}
	
	@Override
	public void update(String productionId, Map<String, Object> updateExtra) {
		DBCollection collection = mongoTemplate.getCollection(TableName.PRODUCTION);
		BasicDBObject productionCondition = new BasicDBObject("_id", new ObjectId(productionId));
		DBObject prevous = collection.findOne(productionCondition);
		if(null==prevous)
			throw new NonExistException(String.format("Quotation[quotationId=%s]", productionId));
		String quotationId = (String )prevous.get("quotationId");
		if(!quotationService.compareQuotationStatus(quotationId, new String[]{Status4Quotation.NORMAL, Status4Quotation.REQUIRE_UPDATE}))
			throw new PromissionDenyException("Could not update quotation, status is dismatch");
		DBObject extra = (DBObject )prevous.get("extra");
		Set<Entry<String,Object>> entrySet = updateExtra.entrySet();
		for(Entry<String,Object> entry:entrySet)
			extra.put(entry.getKey(), entry.getValue());
		collection.save(prevous);

		whileProductionUpdate(quotationId);
	}

	@Override
	public void updateType(String productionId, String type) {
		DBCollection collection = mongoTemplate.getCollection(TableName.PRODUCTION);
		BasicDBObject productionCondition = new BasicDBObject("_id", new ObjectId(productionId));
		WriteResult update = collection.update(
				productionCondition,
				new BasicDBObject("$set", new BasicDBObject("type", type))
		);

		DBObject prevous = collection.findOne(productionCondition);
		if(null==prevous)
			throw new NonExistException(String.format("Quotation[quotationId=%s]", productionId));
		String quotationId = (String )prevous.get("quotationId");
		whileProductionUpdate(quotationId);
		
	}

	@Override
	public void delete(String productionId) {
		updateType(productionId, Status4Production.DROP);
	}

	@Override
	public Map<String, Object> get(String productionId) {
		DBCollection collection = mongoTemplate.getCollection(TableName.PRODUCTION);
		BasicDBObject productionCondition = new BasicDBObject("_id", new ObjectId(productionId));
		DBObject prevous = collection.findOne(productionCondition);
		if(null==prevous)
			throw new NonExistException(String.format("Quotation[quotationId=%s]", productionId));
		return prevous.toMap();
	}

	@Override
	public List<Map<String, Object>> groupGet(String[] productionIds){
		return groupGet(Arrays.asList(productionIds));
	}

	@Override
	public List<Map<String, Object>> groupGet(List<String> productionIds){
		
		List<ObjectId> productionOids= new ArrayList<ObjectId>();
		for(String productionId:productionIds)
			productionOids.add(new ObjectId(productionId));

		DBCollection collection = mongoTemplate.getCollection(TableName.PRODUCTION);
		BasicDBObject productionCondition = new BasicDBObject("_id", new BasicDBObject("$in", productionOids));
		DBCursor result = collection.find(productionCondition);
		if(!result.hasNext())
			throw new NonExistException(String.format("Productions[quotationId in %s]", productionIds.toString()));
		List<DBObject> resultArray = result.toArray();

		List<Map<String, Object>> productions= new ArrayList<Map<String, Object>>();
		for(DBObject productionData:resultArray)
			productions.add(productionData.toMap());
		return productions;
	}
	
	@Override
	public void addImage(String productionId, int idx, String resourceUri) {
		
		DBCollection collection = mongoTemplate.getCollection(TableName.PRODUCTION);
		BasicDBObject productionCondition = new BasicDBObject("_id", new ObjectId(productionId));
		DBObject prevous = collection.findOne(productionCondition);
		if(null==prevous)
			throw new NonExistException(String.format("Quotation[quotationId=%s]", productionId));
		String quotationId = (String )prevous.get("quotationId");
		if(!quotationService.compareQuotationStatus(quotationId, new String[]{Status4Quotation.NORMAL, Status4Quotation.REQUIRE_UPDATE}))
			throw new PromissionDenyException("Could not update quotation, status is dismatch");
		
		String key = "image" + idx;
		collection.update(
				productionCondition,
				new BasicDBObject("$set", new BasicDBObject(key, resourceUri))
		);
		
		String preResourceUri = (String )prevous.get(key);
		ResourceHelper.deleteFile(preResourceUri);

		whileProductionUpdate(quotationId);
	}

	@Override
	public void removeImage(String productionId, int idx) {

		DBCollection collection = mongoTemplate.getCollection(TableName.PRODUCTION);
		BasicDBObject productionCondition = new BasicDBObject("_id", new ObjectId(productionId));
		DBObject prevous = collection.findOne(productionCondition);
		if(null==prevous)
			throw new NonExistException(String.format("Quotation[quotationId=%s]", productionId));
		String quotationId = (String )prevous.get("quotationId");
		if(!quotationService.compareQuotationStatus(quotationId, new String[]{Status4Quotation.NORMAL, Status4Quotation.REQUIRE_UPDATE}))
			throw new PromissionDenyException("Could not update quotation, status is dismatch");
		
		String key = "image" + idx;
		collection.update(
				productionCondition,
				new BasicDBObject("$unset", key)
		);
		
		String preResourceUri = (String )prevous.get(key);
		ResourceHelper.deleteFile(preResourceUri);
		
		whileProductionUpdate(quotationId);
	}

	@Override
	public Boolean isProductionWritable(String productionId) {
		Map<String, Object> quotationData = get(productionId);
		String quotationId = (String )quotationData.get("quotationId");
		if(null==quotationId || "".equals(quotationId))
			throw new DataStructUncorrectException(String.format("Production[productionId=%s]", productionId));
		return quotationService.isQuotationWritable(quotationId);
	}

	private void whileProductionUpdate(String quotationId){
		quotationService.updateLastEditTime(quotationId);
	}
	
}
