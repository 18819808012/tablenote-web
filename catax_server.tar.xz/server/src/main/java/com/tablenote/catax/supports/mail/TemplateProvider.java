package com.tablenote.catax.supports.mail;

public final class TemplateProvider {

	
	private static String template_en = "_____________________________________________________________________\r\nDear ***.\r\n \r\nThanks for using TableNote.com.\r\n \r\nTo finish verifying your e-mail with TableNote.com, please enter the following security code %s on your registration page. This security code is valid for 15 minutes only.\r\n\r\nAlso you can click the Link to complete your register.\r\n<a href=\"http://www.tablenote.com/auth/validation?code=%s&userId=%s\" >Valid</a>\r\n \r\n If you didn't register on our website, please ignore this email.\r\n \r\n** Why i need to verify my email. **\r\n1, You can start to use service on TableNote.com\r\n2, You can reset your password from this email.\r\n3, Notification from TableNote.com will be sent to this email.\r\n-- Notifications including the service from TableNote.com like update of quotation from your supplier, and important update of TableNote service. We won't disturb you by sending advertising emails.\r\n \r\nwww.tablenote.com\r\n_____________________________________________________________________\r\n \r\n ";
	
	public static String getMailContentEn(String code, String userId) {
		return String.format(template_en, code, code, userId);
	}
}
