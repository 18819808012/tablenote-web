package com.tablenote.catax.service;

import java.util.List;
import java.util.Map;

public interface IBoxService {
	
	/**
	 * 发送填写邀请信件
	 * @param sendCompanyId
	 * @param receivedCompanyId
	 * @return 信箱条目的ID
	 */
	public String sendEntranceItem(String sendCompanyId, String receivedCompanyId);

	/**
	 * 创建一个条目，类型为draft草稿
	 * @param quotationId 引用的报价单
	 * @return 信箱条目的ID
	 */
	public String createNewBoxItem(String quotationId);
	
	/**
	 * 发送报价单项目信件
	 * @param boxItemId 信箱条目id
	 * @return null
	 */
	public String sendBoxItem(String boxItemId);
	
	/**
	 * 发送请求更新的BoxItem
	 * @param quotationId 报价单Id
	 * @param productionId 报价单里面的产品id
	 * @return
	 */
	public String sendUpdateRequest(String quotationId, String productionId);
	
	/**
	 * 发送更新完成的BoxItem
	 * @param quotationId 报价单Id
	 * @return
	 */
	public String sendUpdated(String quotationId);
	
	public boolean fallback(String boxItemId);
	
	/**
	 * 移动到已删除
	 * @param boxItemId 信箱条目的ID
	 */
	public void makeJunk(String boxItemId);
	
	/**
	 * 逻辑删除BoxItem
	 * @param boxItemId
	 */
	public void drop(String boxItemId);
	
	/**
	 * 组合获取
	 * @param boxItemIds
	 * @return
	 */
	public List<Map<String, Object>> groupGet(List<String> boxItemIds);
	
	/**
	 * 获取新发生的boxItemId的列表
	 * @param companyId
	 * @param boxItemId
	 * @return
	 */
	public List<String> getNewBoxItemIds(String companyId, String boxItemId);

	/**
	 * 获取新发生的boxItemId的列表
	 * @param companyId
	 * @param boxItemId
	 * @return
	 */
	public List<String> getNewBoxItemIds(String companyId, Long lastUpdateTime);
	
}
