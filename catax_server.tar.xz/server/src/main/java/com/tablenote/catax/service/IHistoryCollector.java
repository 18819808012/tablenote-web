package com.tablenote.catax.service;

import java.util.Set;

/**
 * 记录部分项目的历史增加项目
 * @deprecated 此功能本应该由搜索引擎或mongo的group功能提供，目前方案作为暂时方案
 * @author kimffy
 *
 */
public interface IHistoryCollector {

	/**
	 * 记录报价单发生过得历史项
	 * @param companyId
	 * @param target
	 * @param key
	 */
	public void addQuotationHistoryMark(String companyId, String target, String key);

	/**
	 * 记录产品发生过得历史项
	 * @param companyId
	 * @param target
	 * @param key
	 */
	public void addProductionHistoryMark(String companyId, String target, String key);
	
	/**
	 * 获取相应得历史项
	 * @param companyId
	 * @param type
	 * @param target
	 */
	public Set<String> getHistoryMark(String companyId, String type, String target);
	
	final static String QUOTATION = "quotation";
	
	final static String PRODUCTION = "production";
	
}
