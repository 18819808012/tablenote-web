package com.tablenote.catax.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.tablenote.catax.base.CommonParameters;
import com.tablenote.catax.base.TableName;
import com.tablenote.catax.controller.base.BaseController;
import com.tablenote.catax.service.IBoxItemStateService;
import com.tablenote.catax.service.IBoxService;
import com.tablenote.catax.service.IQuotationService;
import com.tablenote.catax.service.IUserService;
import com.tablenote.catax.service.Status4BoxItem;
import com.tablenote.catax.supports.exception.PromissionDenyException;
import com.tablenote.catax.supports.helper.RequestEnsure;

@Controller
@RequestMapping(value = "/box")
public class BoxController extends BaseController {

	@Resource
	MongoTemplate mongoTemplate;

	@Resource
	IUserService userService;
	
	@Resource
	IBoxService boxService;
	
	@Resource
	IQuotationService quotationService;
	
	@Resource
	IBoxItemStateService boxItemStateService;
	
	@RequestMapping(value = "/sendInvitation")
	@ResponseBody
	public Map<String, Object> sendInvitation(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"companyId",
		});
		String targetCompanyId = (String )paramsMap.remove("companyId");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		String boxItemId = boxService.sendEntranceItem(companyId, targetCompanyId);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("boxItemId", boxItemId);
		return resultMap;
	}
	
	@RequestMapping(value = "/createDraft")
	@ResponseBody
	public Map<String, Object> createDraft(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"quotationId",
		});
		String quotationId = (String )paramsMap.remove("quotationId");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		String boxItemId = boxService.createNewBoxItem(quotationId);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("boxItemId", boxItemId);
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/send")
	@ResponseBody
	public Map<String, Object> send(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"boxItemId",
		});
		String boxItemId = (String )paramsMap.remove("boxItemId");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		boxService.sendBoxItem(boxItemId);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/sendUpdateRequest")
	@ResponseBody
	public Map<String, Object> sendUpdateRequest(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"quotationId",
				//"productionId"
		});
		String quotationId = (String )paramsMap.remove("quotationId");
		//String productionId = (String )paramsMap.remove("productionId");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");

		//String boxItemId = boxService.sendUpdateRequest(quotationId, productionId);
		String boxItemId = boxService.sendUpdateRequest(quotationId, "");
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("boxItemId", boxItemId);
		return resultMap;
	}

	@RequestMapping(value = "/sendUpdated")
	@ResponseBody
	public Map<String, Object> sendUpdated(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"quotationId",
		});
		String quotationId = (String )paramsMap.remove("quotationId");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		String boxItemId = boxService.sendUpdated(quotationId);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("boxItemId", boxItemId);
		return resultMap;
	}

	@RequestMapping(value = "/fallback")
	@ResponseBody
	public Map<String, Object> fallback(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"boxItemId",
		});
		String boxItemId = (String )paramsMap.remove("boxItemId");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		boxService.fallback(boxItemId);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}
	
	@RequestMapping(value = "/junk")
	@ResponseBody
	public Map<String, Object> junk(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"boxItemId",
		});
		String boxItemId = (String )paramsMap.remove("boxItemId");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		boxService.makeJunk(boxItemId);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}
	
	@RequestMapping(value = "/drop")
	@ResponseBody
	public Map<String, Object> drop(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"boxItemId",
		});
		String boxItemId = (String )paramsMap.remove("boxItemId");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		boxService.drop(boxItemId);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/selfSold")
	@ResponseBody
	public Map<String, Object> selfSold(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {
		
		int pageNumber = CommonParameters.PAGE_NUMBER_DEFAULT;
		int pageSize = CommonParameters.PAGE_SIZE_DEFAULT;
		if(paramsMap.containsKey("pageNumber"))
			pageNumber = ((Number )paramsMap.get("pageNumber")).intValue();
		if(paramsMap.containsKey("pageSize"))
			pageSize = ((Number )paramsMap.get("pageSize")).intValue();
		
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"companyId",
		});
		String companyId = (String )paramsMap.remove("companyId");
		
		BasicDBObject condition = new BasicDBObject("componyId", companyId)
				.append("from", companyId)
				.append("to", companyId)
				.append("status", Status4BoxItem.NORMAL)
		;
		
		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		DBCursor cursor = collection.find(condition)
				.sort(new BasicDBObject("_id", -1));
		int total = cursor.count();
		cursor.skip(pageSize*(pageNumber-1)).limit(pageSize);
		List<DBObject> result = cursor.toArray();
		for(DBObject boxItem:result) {
			boxItem.put("quotation", completeBoxQuotation(boxItem.toMap()));
			boxItem.removeField("quotations");
			boxItem.removeField("_id");
		}

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("pageCount", ((Number )(total/pageSize)).intValue() + (total%pageSize>0?1:0));
		resultMap.put("boxItems", result);
		return resultMap;
	}
	
	@RequestMapping(value = "/inBox")
	@ResponseBody
	public Map<String, Object> inBox(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		int pageNumber = CommonParameters.PAGE_NUMBER_DEFAULT;
		int pageSize = CommonParameters.PAGE_SIZE_DEFAULT;
		if(paramsMap.containsKey("pageNumber"))
			pageNumber = ((Number )paramsMap.get("pageNumber")).intValue();
		if(paramsMap.containsKey("pageSize"))
			pageSize = ((Number )paramsMap.get("pageSize")).intValue();
		RequestEnsure.ensureIsLoginSession(request);

		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");

		BasicDBObject condition = new BasicDBObject("componyId", companyId)
				.append("to", companyId)
				.append("status", Status4BoxItem.NORMAL)
		;
		
		if(paramsMap.containsKey("isRead")) {
			List<String> boxItemIdsHasBeenRead = boxItemStateService.getBoxItemIdsHasBeenRead(userId);
			if((Boolean )paramsMap.get("isRead"))
				condition.append("$in", boxItemIdsHasBeenRead);
			else
				condition.append("$not", new BasicDBObject("$in", boxItemIdsHasBeenRead));
		}
		
		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		DBCursor cursor = collection.find(condition)
				.sort(new BasicDBObject("_id", -1));
		int total = cursor.count();
		cursor.skip(pageSize*(pageNumber-1)).limit(pageSize);
		List<DBObject> result = cursor.toArray();
		for(DBObject boxItem:result) {
			boxItem.put("quotation", completeBoxQuotation(boxItem.toMap()));
			boxItem.removeField("quotations");
			boxItem.removeField("_id");
			String boxItemId = (String )boxItem.get("id");
			boxItem.put("hasRead", boxItemStateService.isRead(userId, boxItemId));
		}

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("pageCount", ((Number )(total/pageSize)).intValue() + (total%pageSize>0?1:0));
		resultMap.put("boxItems", result);
		return resultMap;
	}
	
	@RequestMapping(value = "/outBox")
	@ResponseBody
	public Map<String, Object> outBox(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		int pageNumber = CommonParameters.PAGE_NUMBER_DEFAULT;
		int pageSize = CommonParameters.PAGE_SIZE_DEFAULT;
		if(paramsMap.containsKey("pageNumber"))
			pageNumber = ((Number )paramsMap.get("pageNumber")).intValue();
		if(paramsMap.containsKey("pageSize"))
			pageSize = ((Number )paramsMap.get("pageSize")).intValue();
		RequestEnsure.ensureIsLoginSession(request);

		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");

		BasicDBObject condition = new BasicDBObject("componyId", companyId)
				.append("from", companyId)
				.append("status", Status4BoxItem.NORMAL)
				.append("to", new BasicDBObject("$ne", companyId))
		;
		
		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		DBCursor cursor = collection.find(condition)
				.sort(new BasicDBObject("_id", -1));
		int total = cursor.count();
		cursor.skip(pageSize*(pageNumber-1)).limit(pageSize);
		List<DBObject> result = cursor.toArray();
		for(DBObject boxItem:result) {
			boxItem.put("quotation", completeBoxQuotation(boxItem.toMap()));
			boxItem.removeField("quotations");
			boxItem.removeField("_id");
		}

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("pageCount", ((Number )(total/pageSize)).intValue() + (total%pageSize>0?1:0));
		resultMap.put("boxItems", result);
		return resultMap;
	}
	
	@RequestMapping(value = "/draftBox")
	@ResponseBody
	public Map<String, Object> draftBox(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		int pageNumber = CommonParameters.PAGE_NUMBER_DEFAULT;
		int pageSize = CommonParameters.PAGE_SIZE_DEFAULT;
		if(paramsMap.containsKey("pageNumber"))
			pageNumber = ((Number )paramsMap.get("pageNumber")).intValue();
		if(paramsMap.containsKey("pageSize"))
			pageSize = ((Number )paramsMap.get("pageSize")).intValue();
		RequestEnsure.ensureIsLoginSession(request);

		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");

		BasicDBObject condition = new BasicDBObject("componyId", companyId).append("status", Status4BoxItem.DRAFT);
		
		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		DBCursor cursor = collection.find(condition)
				.sort(new BasicDBObject("_id", -1));
		int total = cursor.count();
		cursor.skip(pageSize*(pageNumber-1)).limit(pageSize);
		List<DBObject> result = cursor.toArray();
		for(DBObject boxItem:result) {
			boxItem.put("quotation", completeBoxQuotation(boxItem.toMap()));
			boxItem.removeField("quotations");
			boxItem.removeField("_id");
		}

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("pageCount", ((Number )(total/pageSize)).intValue() + (total%pageSize>0?1:0));
		resultMap.put("boxItems", result);
		return resultMap;
	}
	
	@RequestMapping(value = "/junkBox")
	@ResponseBody
	public Map<String, Object> junkBox(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		int pageNumber = CommonParameters.PAGE_NUMBER_DEFAULT;
		int pageSize = CommonParameters.PAGE_SIZE_DEFAULT;
		if(paramsMap.containsKey("pageNumber"))
			pageNumber = ((Number )paramsMap.get("pageNumber")).intValue();
		if(paramsMap.containsKey("pageSize"))
			pageSize = ((Number )paramsMap.get("pageSize")).intValue();
		RequestEnsure.ensureIsLoginSession(request);

		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");

		BasicDBObject condition = new BasicDBObject("componyId", companyId).append("status", Status4BoxItem.JUNK);
		
		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		DBCursor cursor = collection.find(condition)
				.sort(new BasicDBObject("_id", -1));
		int total = cursor.count();
		cursor.skip(pageSize*(pageNumber-1)).limit(pageSize);
		List<DBObject> result = cursor.toArray();
		for(DBObject boxItem:result) {
			boxItem.put("quotation", completeBoxQuotation(boxItem.toMap()));
			boxItem.removeField("quotations");
			boxItem.removeField("_id");
		}

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("pageCount", ((Number )(total/pageSize)).intValue() + (total%pageSize>0?1:0));
		resultMap.put("boxItems", result);
		return resultMap;
	}

	@RequestMapping(value = "/inBoxSearch")
	@ResponseBody
	public Map<String, Object> inBoxSearch(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		int pageNumber = CommonParameters.PAGE_NUMBER_DEFAULT;
		int pageSize = CommonParameters.PAGE_SIZE_DEFAULT;
		if(paramsMap.containsKey("pageNumber"))
			pageNumber = ((Number )paramsMap.get("pageNumber")).intValue();
		if(paramsMap.containsKey("pageSize"))
			pageSize = ((Number )paramsMap.get("pageSize")).intValue();
		RequestEnsure.ensureIsLoginSession(request);
		
		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"wantState",
		});
		String wantState = (String )paramsMap.remove("wantState");

		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");

		BasicDBObject condition = new BasicDBObject("componyId", companyId)
				.append("status", Status4BoxItem.NORMAL)
		;
		List<String> boxItemIdsHasBeenRead = boxItemStateService.getBoxItemIdsHasBeenRead(userId);
		if(null!=boxItemIdsHasBeenRead)
			if("read".equals(wantState))
				condition.append("$not", new BasicDBObject("$in", boxItemIdsHasBeenRead));
			else
				condition.append("$in", boxItemIdsHasBeenRead);
		
		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		DBCursor cursor = collection.find(condition)
				.sort(new BasicDBObject("_id", -1));
		int total = cursor.count();
		cursor.skip(pageSize*(pageNumber-1)).limit(pageSize);
		List<DBObject> result = cursor.toArray();
		for(DBObject boxItem:result) {
			boxItem.put("quotation", completeBoxQuotation(boxItem.toMap()));
			boxItem.removeField("quotations");
			boxItem.removeField("_id");
		}

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("pageCount", ((Number )(total/pageSize)).intValue() + (total%pageSize>0?1:0));
		resultMap.put("boxItems", result);
		return resultMap;
	}

	@RequestMapping(value = "/read")
	@ResponseBody
	public Map<String, Object> read(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"boxItemId",
		});
		String boxItemId = (String )paramsMap.remove("boxItemId");
		
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		boxItemStateService.markRead(userId, boxItemId);

		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
		
	}
	
	private Map<String, Object> completeBoxQuotation(Map<String, Object> boxItem) {
//		Map<String, Object> quotations = (Map<String, Object> )boxItem.get("quotations");
//		Set<String> keySet = quotations.keySet();
//		String quotationId = keySet.iterator().next();
		String quotationId = (String )boxItem.get("quotationId");
		Map<String, Object> quotation = quotationService.getQuotation(quotationId);
		quotation.remove("_id");
		return quotation;
		
	}
}
