package com.tablenote.catax.base;

import org.bson.types.ObjectId;

import com.mongodb.BasicDBObject;

public final class TableName {

	/**
	 * 用户数据集合
	 */
	public final static String USER = "User";
	
	/**
	 * 公司数据集合
	 */
	public final static String COMPANY = "Company";
	
	/**
	 * 辅助信息：公司编号计数器
	 */
	public final static String COMPANY_STATE = "CompanyStatus";
	public final static BasicDBObject COMPANY_STATE_KEY= new BasicDBObject("_id", new ObjectId("5823edf161268046fa6d6059"));
	
	/**
	 * 公司统计数据对象集合
	 */
	public final static String COMPANY_STATISTICS = "CompanyStatistics";
	
	/**
	 * 加入公司申请集合
	 */
	public final static String COMPANY_JOIN_APPLICATION = "CompanyJoinApplication";
	/**
	 * 公司邀请集合
	 */
	public final static String COMPANY_INVITAION = "CompanyInvitation";
	
	/**
	 * 公司的联系人记录集合
	 */
	public final static String CONTACTS = "Contacts";
	
	/**
	 * 报价单单品模板
	 */
	public final static String TEMPLATE = "Template";
	
	/**
	 * 报价单单品
	 */
	public final static String PRODUCTION = "Production";
	
	/**
	 * 报价单
	 */
	public final static String QUOTATION = "Quotation";
	
	/**
	 * 信箱
	 */
	public final static String BOX = "Box";
	
	/**
	 * 阅读状态
	 */
	public final static String BOX_MESSAGE_STATUS = "BoxMessageStatus";
	
	/**
	 * 历史记录
	 * @deprecated
	 */
	public final static String HISTORY_MARK = "HistoryMark";
	
	/**
	 * 用户阅读状态
	 */
	public final static String READ_STATUS = "ReadSatus";
}
