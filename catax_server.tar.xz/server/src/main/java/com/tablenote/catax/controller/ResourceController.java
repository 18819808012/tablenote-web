package com.tablenote.catax.controller;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.tablenote.catax.controller.base.BaseController;

@Controller
@RequestMapping(value = "/resource")
public class ResourceController extends BaseController {

	@RequestMapping(value = "/upload")
	@ResponseBody
	public Map<String, Object> upload(HttpServletRequest request, HttpServletResponse response, @RequestParam(value = "activityImage", required = false) MultipartFile file) {

		try {
			FileUtils.copyInputStreamToFile(file.getInputStream(), new File("/server/web/localhost/resources", ""));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
