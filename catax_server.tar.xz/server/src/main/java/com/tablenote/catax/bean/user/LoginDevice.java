package com.tablenote.catax.bean.user;

import java.io.Serializable;

/**
 * 设备信息
 * @author jiefzz
 *
 */
public class LoginDevice implements Serializable {

	private static final long serialVersionUID = -4716853581398270863L;
	
	private String deviceId = null;
	
	private String deviceType = null;
	
	private String deviceName = null;

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
}
