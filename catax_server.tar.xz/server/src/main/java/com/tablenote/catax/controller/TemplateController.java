package com.tablenote.catax.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mongodb.DBObject;
import com.tablenote.catax.base.CommonParameters;
import com.tablenote.catax.controller.base.BaseController;
import com.tablenote.catax.service.ICompanyService;
import com.tablenote.catax.service.ITemplateService;
import com.tablenote.catax.service.IUserService;
import com.tablenote.catax.supports.exception.ParametersException;
import com.tablenote.catax.supports.exception.PromissionDenyException;
import com.tablenote.catax.supports.helper.RequestEnsure;

@Controller
@RequestMapping(value = "/template")
public class TemplateController extends BaseController {

	@Resource
	IUserService userService;

	@Resource
	ICompanyService companyService;
	
	@Resource
	ITemplateService templateService;
	
	@RequestMapping(value = "/create")
	@ResponseBody
	public Map<String, Object> create(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"baseInfo",
				"content",
				"tmpName",
				"tmpInfo",
		});
		List<Object> baseInfo = (List<Object> )paramsMap.remove("baseInfo");
		Map<String, Object> content = (Map<String, Object> )paramsMap.remove("content");
		String tmpName = (String )paramsMap.remove("tmpName");
		String tmpInfo = (String )paramsMap.remove("tmpInfo");

		String department = (String )paramsMap.remove("department");
		if(null==department) department = CommonParameters.DEFAULT_DEPARTMENT;
		List<String> departments = (List<String> )paramsMap.remove("departments");
		if(null==departments || 0==departments.size()) {
			departments = new ArrayList<String>();
			departments.add(department);
		}
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");

		Map<String, Object> companyData = companyService.detail(companyId);
		Map<String, Object> companyDepartmentInfo = (Map<String, Object> )companyData.get("department");
		Set<String> companyDepartments = companyDepartmentInfo.keySet();
		for(String targetDepartment:departments) {
			if(!companyDepartments.contains(targetDepartment))
				throw new ParametersException(String.format("Department[department=%s] is not exist", targetDepartment));
			List templates = templateService.getTemplates(companyId, targetDepartment, Integer.MAX_VALUE, 1);
			if(null!=templates && 1<=templates.size())
				throw new PromissionDenyException(String.format("Department[department=%s] has a template before", targetDepartment));
		}
		
		String templateId = templateService.addNewTemplate(companyId, departments, baseInfo, content, tmpName, tmpInfo);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("templateId", templateId);
		return resultMap;
	}

	@RequestMapping(value = "/checkAvaliable")
	@ResponseBody
	public Map<String, Object> checkIsAvaliable(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"templateId",
		});
		String templateId = (String )paramsMap.remove("templateId");
		boolean isAvaliable = templateService.isTemplateAvaliable(templateId);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("result", isAvaliable);
		return resultMap;
	}

	@RequestMapping(value = "/getAllTemplates")
	@ResponseBody
	public Map<String, Object> getAllTemplates(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"companyId",
		});
		String companyId = (String )paramsMap.remove("companyId");
		
		String department = (String )paramsMap.remove("department");
		if(null==department || "".equals(department))
			department = CommonParameters.DEFAULT_DEPARTMENT;
		
		int pageNumber = CommonParameters.PAGE_NUMBER_DEFAULT;
		int pageSize = CommonParameters.PAGE_SIZE_DEFAULT;
		if(paramsMap.containsKey("pageNumber"))
			pageNumber = ((Number )paramsMap.get("pageNumber")).intValue();
		if(paramsMap.containsKey("pageSize"))
			pageSize = ((Number )paramsMap.get("pageSize")).intValue();
		List<Map<String, Object>> templates = (List<Map<String, Object>> )templateService.getTemplates(companyId, department, pageSize, pageNumber);
		if(null!=templates)
			for(Map<String, Object> template:templates) {
				template.remove("_id");
				template.remove("companyOid");
			}
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("templates", templates);
		return resultMap;
	}

	@RequestMapping(value = "/update")
	@ResponseBody
	public Map<String, Object> update(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"templateId",
				"baseInfo",
				"content"
		});
		String templateId = (String )paramsMap.remove("templateId");
		List<Object> baseInfo = (List<Object> )paramsMap.remove("baseInfo");
		Map<String, Object> content = (Map<String, Object> )paramsMap.remove("content");

		String tmpName = (String )paramsMap.remove("tmpName");
		String tmpInfo = (String )paramsMap.remove("tmpInfo");
		
		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");
		
		templateService.updateTemplate(templateId, baseInfo, content, tmpName, tmpInfo);
		
		List<String> departments = (List<String> )paramsMap.remove("departments");
		if(null!=departments && departments.size()>0) {
			for(String department:departments) {
				List templates = templateService.getTemplates(companyId, department);
				if(templates.size()==0)
					;
				else {
					DBObject templateData = (DBObject )templates.get(0);
					String prevousTemplateId = (String )templateData.get("id");
					if(!prevousTemplateId.equals(templateId))
						throw new PromissionDenyException(String.format("Department[name=%s] has a template before", department));
				}
			}
			templateService.updateTemplateDepartments(templateId, departments);
		}
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}
	
	@RequestMapping(value = "/delete")
	@ResponseBody
	public Map<String, Object> delete(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"templateId",
		});
		String templateId = (String )paramsMap.remove("templateId");
		templateService.deleteTemplates(templateId);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		return resultMap;
	}

	@RequestMapping(value = "/get")
	@ResponseBody
	public Map<String, Object> get(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"templateId",
		});
		String templateId = (String )paramsMap.remove("templateId");
		Map<String, Object> template = templateService.get(templateId);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		resultMap.put("template", template);
		return resultMap;
	}
	
	@RequestMapping(value = "/getAvaliableDepartments")
	@ResponseBody
	public Map<String, Object> getAvaliableDepartments(HttpServletRequest request, HttpServletResponse response) {

		RequestEnsure.ensureIsLoginSession(request);
		HttpSession session = request.getSession();
		String userId = (String )session.getAttribute("userId");
		if(!userService.hasSettlement(userId))
			throw new PromissionDenyException("You must join in a company first");
		String companyId = (String )session.getAttribute("settlement");

		List<String> departments = new ArrayList<String>();
		List<String> hasTemplateDepartments = new ArrayList<String>();
		
		List<DBObject> templates = templateService.getTemplates(companyId);
		for(DBObject template:templates) {
			List<String> templateDepartments = (List<String> )template.get("departments");
			if(null==templateDepartments || 0==templateDepartments.size())
				continue;
			hasTemplateDepartments.addAll(templateDepartments);
		}
		
		Map<String, Object> detail = companyService.detail(companyId);
		Map<String, Object> departmentInfo = (Map<String, Object> )detail.get("department");
		if(null!=departmentInfo && 0<departmentInfo.size()) {
			Set<String> companyDepartments = departmentInfo.keySet();
			departments.addAll(companyDepartments);
		}
		
		departments.removeAll(hasTemplateDepartments);
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", "");
		resultMap.put("departments", departments);
		return resultMap;
	}

	@RequestMapping(value = "/getCompanyTemplates")
	@ResponseBody
	public Map<String, Object> getCompanyTemplates(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramsMap) {

		RequestEnsure.ensureKeysIsProvided(paramsMap, new String[]{
				"companyId",
		});
		String companyId = (String )paramsMap.remove("companyId");

		List<Map<String, Object>> templates = (List<Map<String, Object>> )templateService.getTemplates(companyId);
		if(null!=templates)
			for(Map<String, Object> template:templates) {
				template.remove("_id");
				template.remove("companyOid");
			}
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("templates", templates);
		return resultMap;
	}
	
}
