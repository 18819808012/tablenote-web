package com.tablenote.catax.supports.service.impl;

import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Component;

import com.tablenote.catax.supports.service.IEMailService;

@Component
public class EMailServiceImpl implements IEMailService {
	
	/**
	 * smtp服务器
	 */
	private final static String smtp;

	/**
	 * 发送者真实邮件地址
	 */
	private final static String senderAddress;

	/**
	 * 密码
	 */
	private final static String password;
	
	/**
	 * 邮件发送者
	 */
	private final static String from;
	
	/**
	 * 邮件发送者 昵称
	 */
	private final static String nickName;
	
	/**
	 * 主题
	 */
	private final static String subject;
	
	static {
		smtp = "smtp.exmail.qq.com";
		senderAddress = "account@tablenote.com";
		password = "TBn20150326";
		from = "account@tablenote.com";
		try {
			nickName = javax.mail.internet.MimeUtility.encodeText(from);
			subject = "Please verify your e-mail address for TableNote.com";
		} catch( Exception e ) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	@Override
	public void sendEmail(String receiverAddress, String content) {
		try{
			Authenticator authenticator = new Authenticator(){
				String userName=null;  
				String password=null;  
				public Authenticator bind(String username, String password) {
					this.userName = username;
					this.password = password;
					return this;
				}
			    protected PasswordAuthentication getPasswordAuthentication(){  
			         return new PasswordAuthentication(userName, password);  
			    }  
			}.bind(senderAddress, password);
			Properties properties = new Properties();
			properties.put("mail.smtp.host", smtp);
			properties.put("mail.smtp.port", 25);
			properties.put("mail.smtp.auth", true);
			Session session = Session.getDefaultInstance(properties, authenticator);
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(nickName +"<" +from +">"));
			message.setRecipient(Message.RecipientType.TO, new InternetAddress(receiverAddress));
			message.setSubject(subject);
			message.setSentDate(new Date());
			message.setText(content);
			Transport.send(message);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

}
