package com.tablenote.catax.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.tablenote.catax.base.TableName;
import com.tablenote.catax.service.IBoxService;
import com.tablenote.catax.service.IHistoryCollector;
import com.tablenote.catax.service.IProductionService;
import com.tablenote.catax.service.IQuotationService;
import com.tablenote.catax.service.Status4BoxItem;
import com.tablenote.catax.service.Type4BoxItem;
import com.tablenote.catax.supports.exception.NonExistException;
import com.tablenote.catax.supports.exception.PromissionDenyException;
import com.tablenote.catax.supports.push.IMessagePushProxyService;

@Service
public class BoxServiceImpl implements IBoxService {

	@Resource
	MongoTemplate mongoTemplate;
	
	@Resource
	IQuotationService quotationService;

	@Resource
	IProductionService productionService;
	
	@Resource
	IHistoryCollector historyCollector;
	
	@Resource
	IMessagePushProxyService pushProxyService;
	
	@Override
	public String sendEntranceItem(String sendCompanyId, String receivedCompanyId) {
		ObjectId boxItemId4Sender = new ObjectId();
		BasicDBObject newBoxItem = new BasicDBObject();
		newBoxItem.append("from", sendCompanyId);
		newBoxItem.append("to", receivedCompanyId);
		newBoxItem.append("createTime", System.currentTimeMillis());
		newBoxItem.append("sendTime", System.currentTimeMillis());
		newBoxItem.append("type", Type4BoxItem.ENTRANCE);
		newBoxItem.append("status", Status4BoxItem.NORMAL);
		
		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		
		newBoxItem.append("_id", boxItemId4Sender).append("id", boxItemId4Sender.toHexString());
		newBoxItem.append("componyId", sendCompanyId);
		collection.save(newBoxItem);

		ObjectId boxItemId4Receiver = new ObjectId();
		newBoxItem.append("_id", boxItemId4Receiver).append("id", boxItemId4Receiver.toHexString());
		newBoxItem.append("componyId", receivedCompanyId);
		collection.save(newBoxItem);
		
		return boxItemId4Sender.toHexString();
	}

	@Override
	public String createNewBoxItem(String quotationId) {
		Map<String, Object> quotation = quotationService.getQuotation(quotationId);
		String companyId = (String )quotation.get("companyId");
		String toDepartment = (String )quotation.get("refDepartment");
		String toCompanyId = (String )quotation.get("refCompanyId");
		
		ObjectId boxItemId = new ObjectId();
		BasicDBObject newBoxItem = new BasicDBObject("_id", boxItemId).append("id", boxItemId.toHexString());
		newBoxItem.append("componyId", companyId);
		newBoxItem.append("from", companyId);
		newBoxItem.append("to", toCompanyId);
		newBoxItem.append("toDepartment", toDepartment);
		newBoxItem.append("createTime", System.currentTimeMillis());
		newBoxItem.append("type", Type4BoxItem.NORMAL);
		newBoxItem.append("status", Status4BoxItem.DRAFT);
		//newBoxItem.append("quotations", new BasicDBObject(quotationId, true));
		newBoxItem.append("quotationId", quotationId);
		
		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		collection.save(newBoxItem);
		return boxItemId.toHexString();
	}

	@Override
	public String sendBoxItem(String boxItemId) {
		BasicDBObject boxItemCondition = new BasicDBObject("_id", new ObjectId(boxItemId));
		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		BasicDBObject boxItemData = (BasicDBObject )collection.findOne(boxItemCondition);
		if(null==boxItemData)
			throw new NonExistException(String.format("BoxItem[boxItemId=%s]", boxItemId));
		//boxItemData.append("sendTime", System.currentTimeMillis());
		//boxItemData.append("status", Status4BoxItem.NORMAL);
		//collection.save(boxItemData);
		collection.update(
				boxItemCondition,
				new BasicDBObject()
					.append(
							"$set",
							new BasicDBObject("status", Status4BoxItem.NORMAL)
								.append("sendTime", System.currentTimeMillis())
					)
		);
		
		String quotationId = (String )boxItemData.get("quotationId");
		updateHistoryMark(quotationId);
		
		{
			String receiveCompanyId = (String )boxItemData.get("to");
			String fromCompanyId = (String )boxItemData.get("from");
			if(fromCompanyId.equals(receiveCompanyId))
				return (String )boxItemData.get("id");
			
			// 锁定这个报价单。
			quotationService.lockQuotation(quotationId);
			
			boxItemData.put("status", Status4BoxItem.NORMAL);
			ObjectId revervBoxItemId = new ObjectId();
			boxItemData.put("_id", revervBoxItemId);
			boxItemData.put("id", revervBoxItemId.toHexString());
			boxItemData.put("componyId", receiveCompanyId);
			collection.save(boxItemData);
			
			pushProxyService.notifyTags(receiveCompanyId +"." +(String )boxItemData.get("toDepartment"), "CataX Notafication", "You've got new quotations.", new HashMap<String, String>(), null);
			
			return revervBoxItemId.toHexString();
		}
	}

	@Override
	public String sendUpdateRequest(String quotationId, String productionId) {
		
		Map<String, Object> quotation = quotationService.getQuotation(quotationId);
		String companyId = (String )quotation.get("companyId");
		String toDepartment = (String )quotation.get("refDepartment");
		String toCompanyId = (String )quotation.get("refCompanyId");
		
		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		collection.remove(new BasicDBObject("quotationId", quotationId)
				.append("componyId", companyId)
		);
		
		ObjectId boxItemId = new ObjectId();
		BasicDBObject newBoxItem = new BasicDBObject();
		newBoxItem.append("componyId", companyId);
		newBoxItem.append("from", companyId);
		newBoxItem.append("to", toCompanyId);
		newBoxItem.append("toDepartment", toDepartment);
		newBoxItem.append("createTime", System.currentTimeMillis());
		newBoxItem.append("sendTime", System.currentTimeMillis());
		newBoxItem.append("type", Type4BoxItem.REQUIRE_UPDATE);
		newBoxItem.append("status", Status4BoxItem.NORMAL);
		newBoxItem.append("quotationId", quotationId);
		
		newBoxItem.append("_id", boxItemId)
			.append("id", boxItemId.toHexString());

		collection.save(newBoxItem);
		
		// 解锁报价单
		quotationService.unlockQuotation(quotationId);

		return boxItemId.toHexString();
		
		// 2016-12-30 确认不是使用email模式。。。。
//		ObjectId boxItemId4Sender = new ObjectId();
//		ObjectId boxItemId4Receiver = new ObjectId();
//		
//		BasicDBObject newBoxItem = new BasicDBObject();
//		newBoxItem.append("from", toCompanyId);
//		newBoxItem.append("to", companyId);
//		newBoxItem.append("createTime", System.currentTimeMillis());
//		newBoxItem.append("sendTime", System.currentTimeMillis());
//		newBoxItem.append("type", Type4BoxItem.REQUIRE_UPDATE);
//		newBoxItem.append("status", Status4BoxItem.NORMAL);
//		newBoxItem.append("quotationId", quotationId);
//		newBoxItem.append("productionId", productionId);
//		
//		
//		newBoxItem.append("_id", boxItemId4Sender).append("id", boxItemId4Sender.toHexString());
//		newBoxItem.append("componyId", toCompanyId);
//		collection.save(newBoxItem);
//
//		newBoxItem.append("_id", boxItemId4Receiver).append("id", boxItemId4Receiver.toHexString());
//		newBoxItem.append("componyId", companyId);
//		collection.save(newBoxItem);
//		
//		return boxItemId4Sender.toHexString();
	}

	@Override
	public String sendUpdated(String quotationId) {
		
		Map<String, Object> quotation = quotationService.getQuotation(quotationId);
		String companyId = (String )quotation.get("companyId");
		String toDepartment = (String )quotation.get("refDepartment");
		String toCompanyId = (String )quotation.get("refCompanyId");

		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		collection.remove(new BasicDBObject("quotationId", quotationId)
				.append("componyId", toCompanyId)
		);
		
		ObjectId boxItemId = new ObjectId();
		BasicDBObject newBoxItem = new BasicDBObject();
		newBoxItem.append("componyId", toCompanyId);
		newBoxItem.append("from", companyId);
		newBoxItem.append("to", toCompanyId);
		newBoxItem.append("toDepartment", toDepartment);
		newBoxItem.append("createTime", System.currentTimeMillis());
		newBoxItem.append("sendTime", System.currentTimeMillis());
		newBoxItem.append("type", Type4BoxItem.REQUIRE_UPDATE);
		newBoxItem.append("status", Status4BoxItem.NORMAL);
		newBoxItem.append("quotationId", quotationId);
		
		newBoxItem.append("_id", boxItemId)
			.append("id", boxItemId.toHexString());

		collection.save(newBoxItem);

		// 重新锁定报价单
		quotationService.lockQuotation(quotationId);
		
		// 更新 historyMark
		updateHistoryMark(quotationId);
		
		return boxItemId.toHexString();
		
//		ObjectId boxItemId4Sender = new ObjectId();
//		ObjectId boxItemId4Receiver = new ObjectId();
//		
//		BasicDBObject newBoxItem = new BasicDBObject();
//		newBoxItem.append("from", companyId);
//		newBoxItem.append("to", toCompanyId);
//		newBoxItem.append("toDepartment", toDepartment);
//		newBoxItem.append("createTime", System.currentTimeMillis());
//		newBoxItem.append("sendTime", System.currentTimeMillis());
//		newBoxItem.append("type", Type4BoxItem.UPDATED);
//		newBoxItem.append("status", Status4BoxItem.NORMAL);
//		
//		newBoxItem.append("quotationId", quotationId);
//		
//		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
//		
//		newBoxItem.append("_id", boxItemId4Sender).append("id", boxItemId4Sender.toHexString());
//		newBoxItem.append("componyId", companyId);
//		collection.save(newBoxItem);
//
//		//try { Thread.sleep(3l); } catch (InterruptedException e) { }
//		
//		newBoxItem.append("_id", boxItemId4Receiver).append("id", boxItemId4Receiver.toHexString());
//		newBoxItem.append("componyId", toCompanyId);
//		collection.save(newBoxItem);
//		
//		return boxItemId4Sender.toHexString();
	}

	public boolean fallback(String boxItemId) {
		BasicDBObject boxItemCondition = new BasicDBObject("_id", new ObjectId(boxItemId));
		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		BasicDBObject boxItemData = (BasicDBObject )collection.findOne(boxItemCondition);
		if(null==boxItemData)
			throw new NonExistException(String.format("BoxItem[boxItemId=%s]", boxItemId));

		String receiveCompanyId = (String )boxItemData.get("to");
		String fromCompanyId = (String )boxItemData.get("from");
		if(fromCompanyId.equals(receiveCompanyId)) {
			collection.update(
					boxItemCondition,
					new BasicDBObject()
						.append(
								"$set",
								new BasicDBObject("status", Status4BoxItem.DRAFT)
									.append("sendTime", System.currentTimeMillis())
									.append("createTime", System.currentTimeMillis())
						)
			);
			return true;
		} else
			throw new PromissionDenyException(String.format("BoxItem[boxItemId=%s] can not fallback!!!", boxItemId));
	}
	
	@Override
	public void makeJunk(String boxItemId) {
		BasicDBObject boxItemCondition = new BasicDBObject("_id", new ObjectId(boxItemId));
		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		collection.update(
				boxItemCondition,
				new BasicDBObject("$set", new BasicDBObject("status", Status4BoxItem.JUNK))
		);
	}

	@Override
	public void drop(String boxItemId) {
		BasicDBObject boxItemCondition = new BasicDBObject("_id", new ObjectId(boxItemId));
		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		collection.update(
				boxItemCondition,
				new BasicDBObject("$set", new BasicDBObject("status", Status4BoxItem.DROP))
		);
	}

	@Override
	public List<Map<String, Object>> groupGet(List<String> boxItemIds) {
		
//		List<ObjectId> boxItemOids = new ArrayList<ObjectId>();
//		for(String boxItemId:boxItemIds)
//			boxItemOids.add(new ObjectId(boxItemId));
//		BasicDBObject boxItemCondition = new BasicDBObject("_id", new BasicDBObject("$in", boxItemOids));
//		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
//		DBCursor resultCursor = collection.find(boxItemCondition);
//		List<DBObject> result = resultCursor.toArray();
		return null;
	}

	@Override
	public List<String> getNewBoxItemIds(String companyId, String boxItemId) {
		BasicDBObject boxItemCondition = new BasicDBObject("_id", new BasicDBObject("$gt", new ObjectId(boxItemId)))
				.append("componyId", companyId)
				//.append("status", Status4BoxItem.NORMAL)
		;
		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		DBCursor resultCursor = collection.find(boxItemCondition);
		
		List<String> boxItemIds = new ArrayList<String>();
		while(resultCursor.hasNext()) {
			DBObject boxItem = resultCursor.next();
			String currentBoxItemId = (String )boxItem.get("id");
			boxItemIds.add(currentBoxItemId);
		}
		
		return boxItemIds;
	}

	@Override
	public List<String> getNewBoxItemIds(String companyId, Long lastUpdateTime) {
		
		BasicDBObject boxItemCondition = new BasicDBObject("createTime", new BasicDBObject("$gt", lastUpdateTime))
				.append("componyId", companyId)
				//.append("status", Status4BoxItem.NORMAL)
		;
		DBCollection collection = mongoTemplate.getCollection(TableName.BOX);
		DBCursor resultCursor = collection.find(boxItemCondition);
		
		List<String> boxItemIds = new ArrayList<String>();
		while(resultCursor.hasNext()) {
			DBObject boxItem = resultCursor.next();
			String currentBoxItemId = (String )boxItem.get("id");
			boxItemIds.add(currentBoxItemId);
		}
		
		return boxItemIds;
	}

	private void updateHistoryMark(String quotationId) {
		
		Map<String, Object> quotation = quotationService.getQuotation(quotationId);
		
		String companyId = (String )quotation.get("companyId");
		String refCompanyId = (String )quotation.get("refCompanyId");
		
		Long lastUpdateTime = (Long )quotation.get("lastUpdateTime");
		Map<String, Object> extra = (Map<String, Object> )quotation.get("extra");
		Map<String, Object> quotInfo = (Map<String, Object> )extra.get("quotInfo");
		String subject = (String )quotInfo.get("Subject");
		String supplier = (String )quotInfo.get("Supplier");
		

		historyCollector.addQuotationHistoryMark(companyId, "lastUpdateTime", lastUpdateTime.toString());
		historyCollector.addQuotationHistoryMark(companyId, "Subject", subject);
		historyCollector.addQuotationHistoryMark(companyId, "Supplier", supplier);

		historyCollector.addQuotationHistoryMark(refCompanyId, "lastUpdateTime", lastUpdateTime.toString());
		historyCollector.addQuotationHistoryMark(refCompanyId, "Subject", subject);
		historyCollector.addQuotationHistoryMark(refCompanyId, "Supplier", supplier);
		
		List<String> productionIds = (List<String> )quotation.get("productionIds");
		for(String productionId:productionIds) {
			Map<String, Object> production = productionService.get(productionId);
			String itemNumber = (String )quotInfo.get("Item number");
			String Description = (String )quotInfo.get("Description");

			historyCollector.addProductionHistoryMark(companyId, "Item number", itemNumber);
			historyCollector.addProductionHistoryMark(refCompanyId, "Description", Description);
		}

		historyCollector.addProductionHistoryMark(companyId, "lastUpdateTime", lastUpdateTime.toString());
		historyCollector.addProductionHistoryMark(companyId, "Subject", subject);
		historyCollector.addProductionHistoryMark(companyId, "Supplier", supplier);

		historyCollector.addProductionHistoryMark(refCompanyId, "lastUpdateTime", lastUpdateTime.toString());
		historyCollector.addProductionHistoryMark(refCompanyId, "Subject", subject);
		historyCollector.addProductionHistoryMark(refCompanyId, "Supplier", supplier);
	}
}
